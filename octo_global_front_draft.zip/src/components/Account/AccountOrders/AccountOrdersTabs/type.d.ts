export interface ITabsData {
	title: string;
	link: string;
}
