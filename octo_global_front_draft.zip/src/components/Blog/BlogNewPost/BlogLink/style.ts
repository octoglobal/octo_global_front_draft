import { styled } from '@mui/material';

export const useBlogLinkStyles = () => {

	const LinkContainerMUI = styled('div')(() => ({
	}));

	return {
		LinkContainerMUI
	};
};
