export const useHomeShopsList = () => {
	return {

	};
};
