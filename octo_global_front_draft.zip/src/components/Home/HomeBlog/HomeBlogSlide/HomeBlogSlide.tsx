import React from 'react';

const HomeBlogSlide = () => {
	return (
		<>
			23
		</>
	);
};

export default React.memo(HomeBlogSlide);
