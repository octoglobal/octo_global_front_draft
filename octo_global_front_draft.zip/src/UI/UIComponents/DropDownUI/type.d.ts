export interface IDropItem {
	onClick: (id?: number | undefined) => void;
	title: string;
}
