import {Link, styled} from '@mui/material';

export const useSvgLinkUIStyles = () => {

	const LinkMUI = styled(Link)(() => ({
	}));

	return {
		LinkMUI
	};
};
