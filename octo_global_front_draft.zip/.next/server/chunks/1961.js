"use strict";
exports.id = 1961;
exports.ids = [1961];
exports.modules = {

/***/ 7496:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X9": () => (/* binding */ adminSlice),
/* harmony export */   "Wb": () => (/* binding */ changeUserBalance),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_adminSlice_asyncThunk_adminApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5907);


const initialState = {
    adminSwitchIdToUser: null,
    search: '',
    hints: [],
    adminSwitchUserModel: null
};
const adminSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'adminSlice',
    initialState,
    reducers: {
        changeAdminId: (state, action)=>{
            state.adminSwitchIdToUser = action.payload;
            state.hints = [];
        },
        clearAdminHints: (state)=>{
            state.hints = [];
        },
        resetData: (state)=>{
            state.hints = [];
            state.adminSwitchIdToUser = null;
            state.search = '';
            state.adminSwitchUserModel = null;
        },
        changeUserBalance: (state, action)=>{
            if (state.adminSwitchUserModel) {
                state.adminSwitchUserModel = {
                    ...state.adminSwitchUserModel,
                    balance: state.adminSwitchUserModel.balance + action.payload
                };
            }
        },
        changeEmailAndPhone: (state, action)=>{
            if (state.adminSwitchUserModel) {
                state.adminSwitchUserModel = {
                    ...state.adminSwitchUserModel,
                    phone: action.payload.phone,
                    email: action.payload.email,
                    name: action.payload.name,
                    surname: action.payload.surname
                };
            }
        }
    },
    extraReducers: {
        [_reducers_adminSlice_asyncThunk_adminApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchUsersInAdmin.fulfilled.type */ .s.fulfilled.type]: (state, action)=>{
            state.hints = action.payload;
        },
        [_reducers_adminSlice_asyncThunk_adminApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchUserAdmin.fulfilled.type */ .M.fulfilled.type]: (state, action)=>{
            state.adminSwitchUserModel = action.payload;
        }
    }
});
const { changeUserBalance  } = adminSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (adminSlice.reducer);


/***/ }),

/***/ 5907:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ fetchUsersInAdmin),
/* harmony export */   "M": () => (/* binding */ fetchUserAdmin)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7355);
/* harmony import */ var _services_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4727);



const fetchUsersInAdmin = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('adminSlice/search', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get('/admin/search', {
            params: {
                text: data.text
            }
        });
        return (0,_services_services__WEBPACK_IMPORTED_MODULE_2__/* .generateAdminHintsData */ .yO)(response.data.search_results);
    } catch (e) {
        thunkAPI.rejectWithValue('Error api admin search');
    }
});
const fetchUserAdmin = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('adminSlice/user', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get(`/admin/user/${data.userId}`).then((r)=>r.data.user
        );
        return response;
    } catch (e) {
        thunkAPI.rejectWithValue('error adminSlice/user');
    }
});


/***/ }),

/***/ 1562:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "nm": () => (/* binding */ fetchOrdersSendData),
/* harmony export */   "x6": () => (/* binding */ fetchDeletePackageInSend),
/* harmony export */   "jD": () => (/* binding */ fetchDeleteTrackNumber)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7355);


const fetchOrdersSendData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderSendSlice/data', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get(data.url, {
            params: {
                page: data.page,
                page_limit: data.page_limit,
                userId: data.userId
            }
        });
        return {
            data: response.data.packages,
            sendDataEnd: !(response.data.packages.length === data.page_limit)
        };
    } catch (e) {
        thunkAPI.rejectWithValue('error orderSendSlice/data');
    }
});
const fetchDeletePackageInSend = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderSendSlice/delete', async (data, thunkAPI)=>{
    try {
        const { orderSendReducer: { sendData  }  } = thunkAPI.getState();
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios["delete"] */ .N["delete"]('/admin/package_with_orders', {
            data
        });
        if (response.data.message === 'success') {
            return sendData.filter((item)=>item.id !== data.packageId
            );
        }
        return sendData;
    } catch (e) {
        thunkAPI.rejectWithValue('error orderSendSlice/delete');
    }
});
const fetchDeleteTrackNumber = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderSendSlice/deleteTrackNumber', async (data, thunkAPI)=>{
    try {
        const { orderSendReducer: { sendData  }  } = thunkAPI.getState();
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios["delete"] */ .N["delete"]('/admin/package_track', {
            data
        });
        if (response.data.message === 'success') {
            return sendData.filter((item)=>item.id !== data.packageId
            );
        }
        return sendData;
    } catch (e) {
        thunkAPI.rejectWithValue('error orderSendSlice/deleteTrackNumber');
    }
});


/***/ }),

/***/ 4216:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ orderSendSlice),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_orderSendSlice_asyncThunk_orderSendApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1562);


const initialState = {
    page: 1,
    pageLimit: 50,
    sendData: [],
    updateData: true,
    sendDataEnd: false
};
const orderSendSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'orderSendSlice',
    initialState,
    reducers: {
        resetSlice (state) {
            state.page = 1;
            state.sendData = [];
            state.updateData = true;
            state.sendDataEnd = false;
        },
        updateData (state) {
            state.updateData = true;
        }
    },
    extraReducers: {
        [_reducers_orderSendSlice_asyncThunk_orderSendApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchOrdersSendData.fulfilled.type */ .nm.fulfilled.type]: (state, action)=>{
            state.sendData = [
                ...state.sendData,
                ...action.payload.data
            ];
            state.sendDataEnd = action.payload.sendDataEnd;
            state.page += 1;
            state.updateData = false;
        },
        [_reducers_orderSendSlice_asyncThunk_orderSendApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchDeletePackageInSend.fulfilled.type */ .x6.fulfilled.type]: (state, action)=>{
            state.sendData = action.payload;
        },
        [_reducers_orderSendSlice_asyncThunk_orderSendApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchDeleteTrackNumber.fulfilled.type */ .jD.fulfilled.type]: (state, action)=>{
            state.sendData = action.payload;
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (orderSendSlice.reducer);


/***/ }),

/***/ 7333:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tb": () => (/* binding */ fetchOrderStockData),
/* harmony export */   "I6": () => (/* binding */ fetchPackageStockData),
/* harmony export */   "hq": () => (/* binding */ fetchOrderReturn),
/* harmony export */   "bg": () => (/* binding */ fetchOrderCheck),
/* harmony export */   "DK": () => (/* binding */ fetchMergeOrders),
/* harmony export */   "Pe": () => (/* binding */ fetchUnMergePackage),
/* harmony export */   "Tu": () => (/* binding */ fetchPackageAddAddress),
/* harmony export */   "WR": () => (/* binding */ fetchOrderDelete),
/* harmony export */   "tF": () => (/* binding */ fetchDeleteStockOrders),
/* harmony export */   "ro": () => (/* binding */ fetchPackageRemoveAddress),
/* harmony export */   "F4": () => (/* binding */ fetchChangeStatusPackageToSend),
/* harmony export */   "eH": () => (/* binding */ fetchDeletePackage)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7355);
/* harmony import */ var _services_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4727);
/* harmony import */ var _reducers_orderStockSlice_orderStockSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6448);




const fetchOrderStockData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderStockSlice/data', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get(data.url, {
            params: {
                package: data.package,
                page: data.page,
                page_limit: data.page_limit,
                userId: data.userId
            }
        }).then((r)=>r.data
        );
        return {
            data: response.orders,
            ordersEnd: !(response.orders.length === data.page_limit)
        };
    } catch (e) {
        thunkAPI.rejectWithValue('Error orderStockSlice/data');
    }
});
const fetchPackageStockData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderStockSlice/dataPackage', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get(data.url, {
            params: {
                package: data.package,
                page: data.page,
                page_limit: data.page_limit,
                userId: data.userId
            }
        }).then((r)=>r.data
        );
        return {
            packageData: response.packages,
            packageEnd: !(response.packages.length === data.page_limit)
        };
    } catch (e) {
        thunkAPI.rejectWithValue('Error orderStockSlice/data');
    }
});
const fetchOrderReturn = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderStockSlice/return', async (data, thunkAPI)=>{
    try {
        await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get(`/user/send_message/order_return/${data.orderId}`);
        const { orderStockReducer: { stockData  }  } = thunkAPI.getState();
        return stockData.filter((item)=>item.id !== data.orderId
        );
    } catch (e) {
        thunkAPI.rejectWithValue('Error orderStockSlice/return');
        return 'error';
    }
});
const fetchOrderCheck = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderStockSlice/check', async (data, thunkAPI)=>{
    try {
        await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get(`/user/send_message/order_check/${data.orderId}`);
    } catch (e) {
        thunkAPI.rejectWithValue('Error orderStockSlice/return');
        return 'error';
    }
});
const fetchMergeOrders = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderStockSlice/merge', async (data, thunkAPI)=>{
    try {
        const { orderStockReducer: { stockData  }  } = thunkAPI.getState();
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.post */ .N.post(data.url, data);
        if (response.data.message == 'success') {
            return {
                orderData: (0,_services_services__WEBPACK_IMPORTED_MODULE_3__/* .sortItemArrayInId */ .PJ)(stockData, data.orders),
                packageData: {
                    ...response.data.package,
                    orders: (0,_services_services__WEBPACK_IMPORTED_MODULE_3__/* .findItemInArrayForId */ .Xg)(stockData, data.orders)
                }
            };
        }
    } catch (e) {
        thunkAPI.rejectWithValue('Error orderStockSlice/return');
    }
});
const fetchUnMergePackage = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderStockSlice/unMerge', async (data, thunkAPI)=>{
    try {
        const { orderStockReducer: { packageData  }  } = thunkAPI.getState();
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios["delete"] */ .N["delete"](data.url, {
            data: {
                packageId: data.packageId,
                userId: data.userId
            }
        });
        if (response.data.message == 'success') {
            const ordersData = packageData.find((item)=>item.id === data.packageId
            );
            return {
                orderData: (ordersData === null || ordersData === void 0 ? void 0 : ordersData.orders) ? ordersData.orders : [],
                packageData: packageData.filter((item)=>item.id !== data.packageId
                )
            };
        }
    } catch (e) {
        thunkAPI.rejectWithValue('Error orderStockSlice/return');
    }
});
const fetchPackageAddAddress = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderStockSlice/address', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.post */ .N.post(data.url, {
            'packageId': data.packageId,
            'addressId': data.addressId,
            'userId': data.userId
        });
        if (response.data.message == 'success') {
            thunkAPI.dispatch(_reducers_orderStockSlice_orderStockSlice__WEBPACK_IMPORTED_MODULE_2__/* .orderStockSlice.actions.resetSlice */ .x.actions.resetSlice());
        }
        return 'success';
    } catch (e) {
        thunkAPI.rejectWithValue('Error orderStockSlice/address');
    }
});
const fetchOrderDelete = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderStockSlice/deleteOrder', async (data, thunkAPI)=>{
    const orderItem = data.order;
    try {
        const { orderStockReducer: { stockData  }  } = thunkAPI.getState();
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios["delete"] */ .N["delete"]('/admin/orders', {
            data: {
                userId: orderItem.userId,
                orderId: [
                    orderItem.id
                ]
            }
        }).then((r)=>r.data.message
        );
        if (response === 'success') {
            return stockData.filter((item)=>item.id !== orderItem.id
            );
        }
        return stockData;
    } catch (e) {
        thunkAPI.rejectWithValue('error');
    }
});
const fetchDeleteStockOrders = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderStockSlice/deleteOrders', async (data, { rejectWithValue , getState  })=>{
    try {
        const sendData = {
            'userId': data.userId,
            'orderId': data.orderId
        };
        const { orderStockReducer  } = getState();
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios["delete"] */ .N["delete"]('/admin/orders', {
            data: sendData
        });
        if (response.status === 200) {
            data.successCallback();
            const all = orderStockReducer.stockData;
            const whatDelete = data.orderId;
            const result = [];
            for(let i = 0; i < all.length; i++){
                if (whatDelete.indexOf(all[i].id) == -1) {
                    result.push(all[i]);
                }
            }
            return result;
        }
    } catch (e) {
        return rejectWithValue('Error orderStockSlice/delete');
    }
});
const fetchPackageRemoveAddress = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderStockSlice/deleteAddressToPackage', async (data, thunkAPI)=>{
    try {
        const { orderStockReducer: { packageData  }  } = thunkAPI.getState();
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios["delete"] */ .N["delete"]('/admin/package/address', {
            data: {
                userId: data.userId,
                packageId: data.packageId
            }
        }).then((r)=>{
            if (r.data.message == 'success') {
                return packageData.map((item)=>{
                    if (item.id === data.packageId) {
                        return {
                            ...item,
                            address: null,
                            addressId: null,
                            statusId: 4
                        };
                    }
                    return item;
                });
            }
        }).catch(()=>packageData
        );
        return response;
    } catch (e) {
        thunkAPI.rejectWithValue('error');
    }
});
const fetchChangeStatusPackageToSend = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderStockSlice/changeStatus', async (data, thunkAPI)=>{
    try {
        const { orderStockReducer: { packageData  }  } = thunkAPI.getState();
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.post */ .N.post('/admin/package_track', data);
        return {
            message: response.data.message,
            packageData: packageData.filter((item)=>item.id !== data.packageId
            )
        };
    } catch (e) {
        thunkAPI.rejectWithValue('error orderStockSlice/changeStatus');
    }
});
const fetchDeletePackage = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderStockSlice/deletePackage', async (data, thunkAPI)=>{
    const { orderStockReducer: { packageData  }  } = thunkAPI.getState();
    const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios["delete"] */ .N["delete"]('/admin/package_with_orders', {
        data
    });
    if (response.data.message === 'success') {
        return packageData.filter((item)=>item.id !== data.packageId
        );
    }
    return packageData;
});


/***/ }),

/***/ 6448:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x": () => (/* binding */ orderStockSlice),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7333);


const initialState = {
    page: 1,
    pageLimit: 50,
    stockData: [],
    packageData: [],
    packageEnd: false,
    ordersEnd: false,
    updatePosts: true,
    packageFetch: false
};
const orderStockSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'orderStockSlice',
    initialState,
    reducers: {
        resetSlice (state) {
            state.page = 1;
            state.stockData = [];
            state.packageData = [];
            state.packageEnd = false;
            state.updatePosts = true;
            state.packageFetch = false;
            state.ordersEnd = false;
        },
        filterStockData (state, action) {
            state.stockData = state.stockData.filter((item)=>item.id !== action.payload
            );
        },
        ordersEmptyInDatabase (state) {
            state.updatePosts = true;
            state.ordersEnd = true;
            state.page = 1;
        },
        updatePost (state) {
            state.updatePosts = true;
        }
    },
    extraReducers: {
        [_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchOrderStockData.fulfilled.type */ .Tb.fulfilled.type]: (state, action)=>{
            state.page += 1;
            state.updatePosts = false;
            state.stockData = [
                ...state.stockData,
                ...action.payload.data
            ];
            state.ordersEnd = action.payload.ordersEnd;
        },
        [_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchPackageStockData.fulfilled.type */ .I6.fulfilled.type]: (state, action)=>{
            state.packageData = [
                ...state.packageData,
                ...action.payload.packageData
            ];
            state.packageEnd = action.payload.packageEnd;
            state.updatePosts = false;
            state.page += 1;
        },
        [_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchMergeOrders.fulfilled.type */ .DK.fulfilled.type]: (state, action)=>{
            state.stockData = action.payload.orderData;
            state.packageData = [
                action.payload.packageData,
                ...state.packageData
            ];
        },
        [_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchUnMergePackage.fulfilled.type */ .Pe.fulfilled.type]: (state, action)=>{
            state.packageData = action.payload.packageData;
            state.stockData = [
                ...action.payload.orderData,
                ...state.stockData
            ];
        },
        [_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchOrderDelete.fulfilled.type */ .WR.fulfilled.type]: (state, action)=>{
            state.stockData = action.payload;
        },
        [_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchPackageRemoveAddress.fulfilled.type */ .ro.fulfilled.type]: (state, action)=>{
            state.packageData = action.payload;
        },
        [_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchChangeStatusPackageToSend.fulfilled.type */ .F4.fulfilled.type]: (state, action)=>{
            state.packageData = action.payload.packageData;
        },
        [_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchDeletePackage.fulfilled.type */ .eH.fulfilled.type]: (state, action)=>{
            state.packageData = action.payload;
        },
        [_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchDeleteStockOrders.fulfilled.type */ .tF.fulfilled.type]: (state, action)=>{
            state.stockData = action.payload;
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (orderStockSlice.reducer);


/***/ }),

/***/ 7106:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JS": () => (/* binding */ fetchOrderWaitData),
/* harmony export */   "FG": () => (/* binding */ fetchDeleteOrders),
/* harmony export */   "i9": () => (/* binding */ fetchMiltiChangeStatus)
/* harmony export */ });
/* unused harmony export fetchChangeStatus */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7355);
/* harmony import */ var _services_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4727);



const fetchOrderWaitData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderWaitSlice/data', async (data, thunkAPI)=>{
    try {
        const apiUrl = (data === null || data === void 0 ? void 0 : data.userId) ? '/admin/user/orders/expected' : '/user/orders/expected';
        const params = (data === null || data === void 0 ? void 0 : data.userId) ? {
            page: data.page,
            page_limit: data.pageLimit,
            userId: data.userId
        } : {
            page: data.page,
            page_limit: data.pageLimit
        };
        const response1 = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get(apiUrl, {
            params
        }).then((response)=>response.data
        );
        return {
            data: response1.orders,
            scrollEmpty: !(response1.orders.length === data.pageLimit)
        };
    } catch (e) {
        thunkAPI.rejectWithValue('Error api user/orders/expected');
    }
});
const fetchDeleteOrders = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderWaitSlice/delete', async (data, { rejectWithValue , getState  })=>{
    try {
        const sendData = {
            'userId': data.userId,
            'orderId': data.orderId
        };
        const { orderWaitReducer: { orderWaitData  }  } = getState();
        const response3 = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios["delete"] */ .N["delete"]('/admin/orders', {
            data: sendData
        }).then((response)=>{
            if (response.data.message === 'success') {
                data.successCallback();
                return (0,_services_services__WEBPACK_IMPORTED_MODULE_2__/* .sortItemArrayInId */ .PJ)(orderWaitData, data.orderId);
            } else {
                return [];
            }
        });
        return response3;
    } catch (e) {
        return rejectWithValue('Error orderWaitSlice/delete');
    }
});
const fetchChangeStatus = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderWaitSlice/changeStatus', async (data, thunkAPI)=>{
    try {
        const sendData = {
            'userId': data.userId,
            'orderId': data.orderId
        };
        const response5 = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios["delete"] */ .N["delete"]('/admin/orders', {
            data: sendData
        }).then((response)=>{
            if (response.data.message === 'success') {
                data.successCallback();
                return (0,_services_services__WEBPACK_IMPORTED_MODULE_2__/* .sortItemArrayInId */ .PJ)(data.ordersData, data.orderId);
            } else {
                return [];
            }
        });
        return response5;
    } catch (e) {
        return thunkAPI.rejectWithValue('Error orderWaitSlice/delete');
    }
});
const fetchMiltiChangeStatus = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('orderWaitSlice/changeMiltiStatus', async (data, { rejectWithValue  })=>{
    const all = data.ordersData;
    const whatDelete = data.orderId;
    const resultMove = [];
    const resultStay = [];
    for(let i = 0; i < all.length; i++){
        if (whatDelete.indexOf(all[i].id) !== -1) {
            resultMove.push(all[i]);
        } else {
            resultStay.push(all[i]);
        }
    }
    for(let i1 = 0; i1 < resultMove.length; i1++){
        try {
            _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.post */ .N.post('/admin/orders', {
                userId: resultMove[i1].userId,
                track_number: +resultMove[i1].trackNumber,
                title: resultMove[i1].title,
                comment: resultMove[i1].comment,
                statusId: resultMove[i1].statusId + 1
            });
            if (i1 === resultMove.length - 1) {
                data.successCallback();
                return resultStay;
            }
        } catch (error) {
            return rejectWithValue('error in orderWaitSlice/changeMiltiStatus');
        }
    }
}); // const handleDeleteOrder = (orderId: number) => {
 // 	return () => {
 // 		try {
 // 			const sendData = {
 // 				'userId': adminSwitchIdToUser,
 // 				'orderId': [orderId]
 // 			};
 // 			octoAxios.delete<IDefaultFetchSuccess>('/admin/orders', {
 // 				data: sendData
 // 			}).then(response => {
 // 				if (response.data.message === 'success') {
 // 					handleToggleModal(setIsDeleteModal);
 // 					dispatch(orderWaitSlice.actions.sortOrderData(orderId));
 // 				}
 // 			});
 // 		} catch (e) {
 // 			throw new Error('Error delete order');
 // 		}
 // 	};
 // };


/***/ }),

/***/ 9238:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ orderWaitSlice),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_orderWaitSlice_asyncThunk_orderWaitApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7106);


const initialState = {
    page: 1,
    pageLimit: 50,
    orderWaitData: [],
    scrollEmpty: false,
    updateData: true
};
const orderWaitSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'orderWaitSlice',
    initialState,
    reducers: {
        defaultData (state) {
            state.page = 1;
            state.pageLimit = 50;
            state.orderWaitData = [];
            state.scrollEmpty = false;
            state.updateData = true;
        },
        sortOrderData (state, action) {
            state.orderWaitData = state.orderWaitData.filter((order)=>order.id !== action.payload
            );
        },
        updateData (state) {
            state.updateData = true;
        }
    },
    extraReducers: {
        [_reducers_orderWaitSlice_asyncThunk_orderWaitApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchOrderWaitData.fulfilled.type */ .JS.fulfilled.type]: (state, action)=>{
            state.orderWaitData = [
                ...state.orderWaitData,
                ...action.payload.data
            ];
            state.scrollEmpty = action.payload.scrollEmpty;
            state.page += 1;
            state.updateData = false;
        },
        [_reducers_orderWaitSlice_asyncThunk_orderWaitApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchDeleteOrders.fulfilled.type */ .FG.fulfilled.type]: (state, action)=>{
            state.orderWaitData = action.payload;
        },
        [_reducers_orderWaitSlice_asyncThunk_orderWaitApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchMiltiChangeStatus.fulfilled.type */ .i9.fulfilled.type]: (state, action)=>{
            state.orderWaitData = action.payload;
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (orderWaitSlice.reducer);


/***/ })

};
;