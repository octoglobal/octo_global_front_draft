"use strict";
exports.id = 4219;
exports.ids = [4219];
exports.modules = {

/***/ 1967:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _circle, _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgWhatsappIconColor = function SvgWhatsappIconColor(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 23,
    height: 23,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _circle || (_circle = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 11,
    cy: 11,
    r: 10,
    fill: "#fff"
  })), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M23 11.5C23 17.851 17.851 23 11.5 23S0 17.851 0 11.5 5.149 0 11.5 0 23 5.149 23 11.5ZM5.833 14.388l-.113.409-.583 2.108 2.108-.583.41-.113.365.216a6.786 6.786 0 0 0 3.46.943c3.751 0 6.807-3.054 6.807-6.806 0-3.753-3.056-6.807-6.806-6.807a6.815 6.815 0 0 0-6.807 6.807c0 1.224.326 2.414.943 3.46l.216.366Zm-1.007 3.641-1.124.311.31-1.124.744-2.686a7.795 7.795 0 0 1-1.082-3.968c0-4.306 3.502-7.807 7.807-7.807 4.302 0 7.806 3.501 7.806 7.807 0 4.304-3.504 7.806-7.807 7.806a7.786 7.786 0 0 1-3.969-1.082l-2.685.743Zm5.564-5.42c2.156 2.156 4.52 2.737 4.54 2.724.227-.152.623-.48.908-.908.248-.373.454-.908.454-.908l-2.27-1.362-1.135.681s-.578-.35-1.362-1.135c-.68-.68-1.362-1.588-1.362-1.588l.681-1.135-1.362-2.27c-.151 0-.454 0-1.135.68-.462.464-.68.909-.68.909s.633 2.222 2.723 4.312Z",
    fill: "#23D16A"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgWhatsappIconColor);

/***/ }),

/***/ 1115:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ SvgLinkUI_SvgLinkUI)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/UI/UIComponents/SvgLinkUI/style.ts

const useSvgLinkUIStyles = ()=>{
    const LinkMUI = (0,material_.styled)(material_.Link)(()=>({})
    );
    return {
        LinkMUI
    };
};

;// CONCATENATED MODULE: ./src/UI/UIComponents/SvgLinkUI/SvgLinkUI.tsx



const SvgLinkUI = (props)=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(LinkMUI, {
        ...props,
        target: "_blank",
        rel: "noreferrer",
        children: props.children
    }));
};
const { LinkMUI  } = useSvgLinkUIStyles();
/* harmony default export */ const SvgLinkUI_SvgLinkUI = (/*#__PURE__*/external_react_default().memo(SvgLinkUI));


/***/ })

};
;