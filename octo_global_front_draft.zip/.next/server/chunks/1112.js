"use strict";
exports.id = 1112;
exports.ids = [1112];
exports.modules = {

/***/ 1112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ OrderDeleteModal_OrderDeleteModal)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./src/UI/UIComponents/ButtonUI/ButtonUI.tsx + 1 modules
var ButtonUI = __webpack_require__(2907);
;// CONCATENATED MODULE: ./src/components/AnyPage/OrderItem/OrderDeleteModal/style.ts


const useOrderDeleteModalStyles = ()=>{
    const tablet = 769;
    const DialogMUI = (0,material_.styled)(material_.Dialog)(({ theme  })=>({
            '& .MuiDialog-container': {
                position: 'relative',
                '& .MuiPaper-root': {
                    backgroundColor: '#F1F4F9',
                    boxShadow: '0px 4px 15px rgba(0, 0, 0, 0.15)',
                    borderRadius: '15px',
                    maxWidth: '573px',
                    maxHeight: '232px',
                    width: '100%',
                    height: '100%',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    flexDirection: 'column'
                }
            },
            [theme.breakpoints.down(tablet)]: {
                '& .MuiDialog-container': {
                    '& .MuiPaper-root': {
                        maxHeight: '140px',
                        minWidth: '290px',
                        padding: '20px 5px'
                    }
                }
            }
        })
    );
    const DialogTitleMUI = (0,material_.styled)('p')(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '24px',
            fontWeight: 400,
            textAlign: 'center',
            [theme.breakpoints.down(tablet)]: {
                fontSize: '16px',
                lineHeight: '18px'
            },
            [theme.breakpoints.down(350)]: {
                fontSize: '14px',
                lineHeight: '16px'
            }
        })
    );
    const DialogButtonContainerMUI = (0,material_.styled)('div')(({ theme  })=>({
            marginTop: '39px',
            display: 'flex',
            justifyContent: 'space-between',
            width: '210px',
            [theme.breakpoints.down(tablet)]: {
                marginTop: '27px'
            }
        })
    );
    const DialogButtonYesMUI = (0,material_.styled)(ButtonUI/* default */.Z)(({ theme  })=>({
            marginBottom: 0,
            maxWidth: '65px',
            fontSize: '14px',
            lineHeight: '16px',
            height: '32px',
            fontWeight: 400,
            [theme.breakpoints.down(tablet)]: {
                maxWidth: '93px'
            }
        })
    );
    const DialogButtonNoMUI = (0,material_.styled)(ButtonUI/* default */.Z)(()=>({
            marginBottom: 0,
            maxWidth: '65px',
            backgroundColor: 'transparent',
            color: '#274D82',
            fontSize: '14px',
            height: '32px',
            lineHeight: '16px',
            fontWeight: 400,
            textDecoration: 'underline',
            '&:hover': {
                backgroundColor: 'transparent',
                textDecoration: 'underline'
            }
        })
    );
    const BackDropBlurMUI = (0,material_.styled)(material_.Backdrop, {
        name: 'MuiModal',
        slot: 'Backdrop',
        overridesResolver: (props, styles)=>{
            return styles.backdrop;
        }
    })({
        background: 'rgba(255, 255, 255, 0.5)',
        backdropFilter: 'blur(1px)',
        filter: 'blur(10px)',
        position: 'fixed',
        display: 'flex',
        // -moz-box-align: center,
        alignItems: 'center',
        // -moz-box-pack: 'center',
        justifyContent: 'center',
        inset: '0px',
        zIndex: '-1'
    });
    return {
        DialogMUI,
        DialogTitleMUI,
        BackDropBlurMUI,
        DialogButtonNoMUI,
        DialogButtonYesMUI,
        DialogButtonContainerMUI
    };
};

;// CONCATENATED MODULE: ./src/components/AnyPage/OrderItem/OrderDeleteModal/OrderDeleteModal.tsx



const OrderDeleteModal = ({ dialogProps , title , onClickNo , onClickYes , buttonYesText ='Да' , buttonNoText ='Нет' ,  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(DialogMUI, {
        ...dialogProps,
        disableScrollLock: false,
        BackdropComponent: BackDropBlurMUI,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(DialogTitleMUI, {
                children: title
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DialogButtonContainerMUI, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(DialogButtonYesMUI, {
                        onClick: onClickYes,
                        children: buttonYesText
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(DialogButtonNoMUI, {
                        onClick: onClickNo,
                        children: buttonNoText
                    })
                ]
            })
        ]
    }));
};
const { DialogMUI , DialogTitleMUI , DialogButtonNoMUI , BackDropBlurMUI , DialogButtonYesMUI , DialogButtonContainerMUI ,  } = useOrderDeleteModalStyles();
/* harmony default export */ const OrderDeleteModal_OrderDeleteModal = (/*#__PURE__*/external_react_default().memo(OrderDeleteModal));


/***/ })

};
;