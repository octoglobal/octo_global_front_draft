"use strict";
exports.id = 4711;
exports.ids = [4711];
exports.modules = {

/***/ 4711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path, _path2;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgBusket = function SvgBusket(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    viewBox: "0 0 95 72",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M53.666 26c-2.43 0-4.705.66-6.667 1.811A13.115 13.115 0 0 0 40.333 26C32.968 26 27 32.043 27 39.501 27 46.955 32.968 53 40.333 53c2.43 0 4.705-.661 6.666-1.811A13.137 13.137 0 0 0 53.666 53C61.03 53 67 46.955 67 39.501 67 32.043 61.03 26 53.666 26Zm-7.45 2.308-.031.023.03-.023Zm1.563 22.386c.036-.025.07-.052.105-.077-.035.025-.069.052-.105.077Zm.753-.554.013-.01-.013.01Zm5.135-.508c-1.331 0-2.6-.264-3.762-.742A13.536 13.536 0 0 0 52 46.04a13.577 13.577 0 0 0 1.666-6.538c0-2.373-.605-4.6-1.666-6.538a6.623 6.623 0 0 0-2.91 1.633 10.186 10.186 0 0 1 1.25 4.905c0 5.594-4.48 10.132-10.007 10.132-5.528 0-10.008-4.538-10.008-10.132 0-5.598 4.48-10.133 10.008-10.133 1.33 0 2.6.265 3.76.742A13.519 13.519 0 0 0 42 32.963a13.575 13.575 0 0 0-1.667 6.538c0 2.371.606 4.6 1.667 6.536a6.633 6.633 0 0 0 2.908-1.633 10.18 10.18 0 0 1-1.25-4.903c0-5.598 4.48-10.133 10.008-10.133 5.528 0 10.008 4.535 10.008 10.133 0 5.594-4.48 10.132-10.008 10.132Z",
    fill: "#274D82"
  })), _path2 || (_path2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M0 2.692A2.697 2.697 0 0 1 2.703 0h89.594A2.697 2.697 0 0 1 95 2.692v11.304a2.697 2.697 0 0 1-2.703 2.692h-.54v52.62A2.697 2.697 0 0 1 89.054 72H6.486a2.697 2.697 0 0 1-2.702-2.692v-52.62H2.703A2.697 2.697 0 0 1 0 13.996V2.692Zm6.486 13.996v52.62h82.568v-52.62H6.486ZM2.703 2.692v11.304h89.594V2.692H2.703Z",
    fill: "#274D82"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgBusket);

/***/ })

};
;