"use strict";
exports.id = 4244;
exports.ids = [4244];
exports.modules = {

/***/ 1500:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgArrowBlue = function SvgArrowBlue(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M20.762 10.576 2.468 3.019c-.855-.353-1.69.543-1.277 1.37l2.538 5.094a1 1 0 0 0 .69.533l2.413.505c1.06.222 1.06 1.736 0 1.958l-2.413.505a1 1 0 0 0-.69.533L1.191 18.61c-.413.828.422 1.724 1.277 1.37l18.294-7.556c.825-.34.825-1.508 0-1.848Z",
    fill: "#274D82"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgArrowBlue);

/***/ }),

/***/ 7284:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgBlackArrowDown = function SvgBlackArrowDown(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 22,
    height: 13,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "m1.159 1.446 9.446 9.765 9.447-9.765",
    stroke: "#000",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgBlackArrowDown);

/***/ }),

/***/ 6091:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _UIIcon_CheckboxEmptyV2_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3020);
/* harmony import */ var _UIIcon_CheckBoxFillV2_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9859);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7004);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const CheckboxUIV2 = ({ controller , checkboxProps , callback  })=>{
    const handleChange = (value, onChange)=>{
        return ()=>{
            onChange(!value);
            if (callback) {
                callback();
            }
        };
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
        ...controller,
        defaultValue: false,
        render: ({ field: { value , onChange  }  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyleCheckboxMUI, {
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_CheckboxEmptyV2_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                checkedIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_CheckBoxFillV2_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                checked: value,
                ...checkboxProps,
                onChange: handleChange(value, onChange)
            })
    }));
};
const { StyleCheckboxMUI  } = (0,_style__WEBPACK_IMPORTED_MODULE_5__/* .useCheckboxUIV2Styles */ .Z)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(CheckboxUIV2));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7004:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useCheckboxUIV2Styles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useCheckboxUIV2Styles = ()=>{
    const StyleCheckboxMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Checkbox)(()=>({
            padding: '3px'
        })
    );
    return {
        StyleCheckboxMUI
    };
};


/***/ }),

/***/ 7979:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



const DropDownCollapseItem = ({ title , value , onClick ,  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ItemButton, {
        onClick: ()=>onClick({
                title,
                value
            })
        ,
        children: title
    }));
};
const ItemButton = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button)(()=>({
        fontSize: '20px',
        lineHeight: '23px',
        color: '#000000',
        fontWeight: 300,
        display: 'block',
        textTransform: 'none',
        padding: '0',
        marginBottom: '10px'
    })
);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(DropDownCollapseItem));


/***/ }),

/***/ 4623:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5718);
/* harmony import */ var _UIIcon_BlackArrowDown_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7284);
/* harmony import */ var _useDropDownCollapseUI__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7500);
/* harmony import */ var _DropDownCollapseItem_DropDownCollapseItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7979);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5641);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_useDropDownCollapseUI__WEBPACK_IMPORTED_MODULE_4__, react_hook_form__WEBPACK_IMPORTED_MODULE_6__]);
([_useDropDownCollapseUI__WEBPACK_IMPORTED_MODULE_4__, react_hook_form__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const DropDownCollapseUI = ({ title , collapseItems , required =false ,  })=>{
    const { control ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_6__.useFormContext)();
    const { isOpen , handleToggleOpen , activeArrowStyles , modificationTitle ,  } = (0,_useDropDownCollapseUI__WEBPACK_IMPORTED_MODULE_4__/* .useDropDownCollapseUI */ .G)(title);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContainerMUI, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TitleContainerMUI, {
                onClick: handleToggleOpen,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CollapseTitleMUI, {
                        children: modificationTitle
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CollapseIconMUI, {
                        sx: activeArrowStyles,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_BlackArrowDown_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_6__.Controller, {
                name: "orderStatus",
                control: control,
                defaultValue: undefined,
                render: ({ field: { onChange  } , fieldState: { error  }  })=>{
                    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CollapseListMUI, {
                                in: isOpen,
                                children: collapseItems.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DropDownCollapseItem_DropDownCollapseItem__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        onClick: onChange,
                                        ...item
                                    }, item.name)
                                )
                            }),
                            (error === null || error === void 0 ? void 0 : error.type) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CollapseErrorMUI, {
                                children: "Выберите статус"
                            })
                        ]
                    }));
                },
                rules: {
                    required
                }
            })
        ]
    }));
};
const { ContainerMUI , CollapseTitleMUI , TitleContainerMUI , CollapseIconMUI , CollapseListMUI , CollapseErrorMUI ,  } = (0,_style__WEBPACK_IMPORTED_MODULE_2__/* .useDropDownCollapseUIStyles */ .V)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(DropDownCollapseUI));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5718:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ useDropDownCollapseUIStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useDropDownCollapseUIStyles = ()=>{
    const ContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({})
    );
    const TitleContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button)(()=>({
            display: 'flex',
            alignItems: 'center',
            textTransform: 'none',
            border: 0,
            padding: 0
        })
    );
    const CollapseTitleMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            fontSize: '20px',
            lineHeight: '26px',
            fontWeight: 400,
            color: '#000000'
        })
    );
    const CollapseIconMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            width: '30px',
            height: '20px',
            marginLeft: '8px',
            transition: '.2s all linear'
        })
    );
    const CollapseListMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Collapse)(()=>({
            '& div.MuiCollapse-wrapperInner': {
                marginTop: '15px',
                '& > *:last-child': {
                    marginBottom: '0px'
                }
            }
        })
    );
    const CollapseErrorMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('span')(()=>({
            fontSize: '12px',
            lineHeight: '14pч',
            fontWeight: 400,
            color: 'red'
        })
    );
    return {
        ContainerMUI,
        CollapseListMUI,
        CollapseIconMUI,
        CollapseTitleMUI,
        CollapseErrorMUI,
        TitleContainerMUI
    };
};


/***/ }),

/***/ 7500:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ useDropDownCollapseUI)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5641);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const useDropDownCollapseUI = (title)=>{
    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const orderStatus = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useWatch)({
        name: 'orderStatus'
    });
    const modificationTitle = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return orderStatus ? orderStatus.title : title;
    }, [
        orderStatus,
        title
    ]);
    const activeArrowStyles = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (isOpen) {
            return {
                transform: 'rotate(180deg)'
            };
        }
        return {};
    }, [
        isOpen
    ]);
    const handleToggleOpen = ()=>{
        setIsOpen((prevState)=>!prevState
        );
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (orderStatus === null || orderStatus === void 0 ? void 0 : orderStatus.title) {
            setIsOpen(false);
        }
    }, [
        orderStatus
    ]);
    return {
        isOpen,
        handleToggleOpen,
        modificationTitle,
        activeArrowStyles
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3140:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AccountOrdersPlaceholder_AccountOrdersPlaceholder)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/Account/AccountOrders/AccountOrdersPlaceholder/style.ts

const useAccountOrdersPlaceholderStyles = ()=>{
    const ContainerMUI = (0,material_.styled)('section')(({ theme  })=>({
            textAlign: 'center',
            maxWidth: '681px',
            [theme.breakpoints.down(710)]: {
                width: '100%'
            }
        })
    );
    const BackgroundImageMUI = (0,material_.styled)('div')(({ theme  })=>({
            background: 'url("../../image/OctoConfidence.png") no-repeat',
            backgroundPosition: 'center center',
            minWidth: '681px',
            minHeight: '482px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            [theme.breakpoints.down(710)]: {
                minWidth: 'auto',
                minHeight: 'auto',
                maxWidth: '310px',
                width: '100%',
                height: '205px',
                backgroundSize: '290px 205px',
                margin: '0 auto'
            }
        })
    );
    const BackgroundTextContainerMUI = (0,material_.styled)('div')(({ theme  })=>({
            marginBottom: '100px',
            [theme.breakpoints.down(710)]: {
                marginBottom: '10px'
            }
        })
    );
    const BackgroundTextMUI = (0,material_.styled)('span')(({ theme  })=>({
            fontSize: '96px',
            lineHeight: '127px',
            fontWeight: 900,
            fontFamily: 'Playfair Display',
            color: '#274D82',
            opacity: 0.03,
            userSelect: 'none',
            [theme.breakpoints.down(710)]: {
                fontSize: '32px',
                lineHeight: '43px'
            }
        })
    );
    const TextMUI = (0,material_.styled)('span')(({ theme  })=>({
            fontSize: '24px',
            lineHeight: '28px',
            fontWeight: 400,
            color: '#000000',
            [theme.breakpoints.down(710)]: {
                fontSize: '16px',
                lineHeight: '18px'
            }
        })
    );
    return {
        TextMUI,
        ContainerMUI,
        BackgroundTextMUI,
        BackgroundImageMUI,
        BackgroundTextContainerMUI
    };
};

;// CONCATENATED MODULE: ./src/components/Account/AccountOrders/AccountOrdersPlaceholder/AccountOrdersPlaceholder.tsx



const AccountOrdersPlaceholder = ({ children , text ,  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ContainerMUI, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(BackgroundImageMUI, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(BackgroundTextContainerMUI, {
                    children: text ? /*#__PURE__*/ jsx_runtime_.jsx(TextMUI, {
                        children: text
                    }) : children
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(BackgroundTextMUI, {
                children: "octo global"
            })
        ]
    }));
};
const { TextMUI , ContainerMUI , BackgroundImageMUI , BackgroundTextMUI , BackgroundTextContainerMUI ,  } = useAccountOrdersPlaceholderStyles();
/* harmony default export */ const AccountOrdersPlaceholder_AccountOrdersPlaceholder = (/*#__PURE__*/external_react_default().memo(AccountOrdersPlaceholder));


/***/ }),

/***/ 8786:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_AnyPage_OrderItem_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1286);
/* harmony import */ var _components_AnyPage_OrderItem_OrderItemTitle_OrderItemTitle__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2107);
/* harmony import */ var _components_AnyPage_OrderItem_OrderItemBody_OrderItemBody__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2935);
/* harmony import */ var _components_AnyPage_OrderItem_useOrderItemWait__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9274);
/* harmony import */ var _components_AnyPage_OrderItem_OrderStatusModal_OrderStatusModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3445);
/* harmony import */ var _components_AnyPage_OrderItem_useOrderItemStock__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3470);
/* harmony import */ var _UI_UIComponents_ModalUI_ModalUI__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1705);
/* harmony import */ var _components_AnyPage_OrderItem_useOrderItemSend__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5391);
/* harmony import */ var _components_AnyPage_OrderItem_OrderDeleteModal_OrderDeleteModal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1112);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_AnyPage_OrderItem_OrderItemTitle_OrderItemTitle__WEBPACK_IMPORTED_MODULE_3__, _components_AnyPage_OrderItem_OrderStatusModal_OrderStatusModal__WEBPACK_IMPORTED_MODULE_6__]);
([_components_AnyPage_OrderItem_OrderItemTitle_OrderItemTitle__WEBPACK_IMPORTED_MODULE_3__, _components_AnyPage_OrderItem_OrderStatusModal_OrderStatusModal__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const getCustomHooksData = (component, orderId, orderItem)=>{
    if (component === 'wait') {
        const waitData = (0,_components_AnyPage_OrderItem_useOrderItemWait__WEBPACK_IMPORTED_MODULE_5__/* .useOrderItemWait */ .Z)();
        return waitData;
    }
    if (component === 'stock') {
        const stockData = (0,_components_AnyPage_OrderItem_useOrderItemStock__WEBPACK_IMPORTED_MODULE_7__/* .useOrderItemStock */ .r)(orderId, orderItem);
        return stockData;
    }
    if (component === 'send') {
        const sendData = (0,_components_AnyPage_OrderItem_useOrderItemSend__WEBPACK_IMPORTED_MODULE_10__/* .useOrderItemSend */ .a)(orderId, orderItem);
        return sendData;
    }
};
const OrderItem = ({ visibleCheckbox , visibleDropDown , orderItem , visibleTrackNumber =true , visibleTitle =true , component , isBorderBottom =true ,  })=>{
    const { title , longId , id , tracking_link , trackNumber , comment ,  } = orderItem;
    const { isAdmin , dropDownData , isDeleteModal , isStatusModal , isReturnOrder , setIsDeleteModal , setIsStatusModal , setIsReturnOrder , handleDeleteOrder , handleReturnOrder , handleToggleModal , dialogCheckProps , dialogSuccessReturnProps , handleSuccessChangeStatus ,  } = getCustomHooksData(component, id, orderItem);
    const isContainerStyles = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        const isBorderBottomFalseStyles = isBorderBottom ? {} : {
            borderBottom: '0px solid red !important',
            paddingBottom: '0 !important'
        };
        return {
            ...isBorderBottomFalseStyles
        };
    }, [
        isBorderBottom
    ]);
    const isWait = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>component == 'wait'
    , [
        component
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContainerMUI, {
                sx: isContainerStyles,
                children: [
                    visibleTitle && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_OrderItem_OrderItemTitle_OrderItemTitle__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        id: id,
                        title: title,
                        longId: longId,
                        visibleCheckbox: visibleCheckbox,
                        visibleDropDown: visibleDropDown,
                        dropItems: dropDownData
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_OrderItem_OrderItemBody_OrderItemBody__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        title: title,
                        visibleTrackNumber: visibleTrackNumber,
                        tracking_link: tracking_link,
                        trackNumber: trackNumber,
                        comment: comment
                    })
                ]
            }),
            (component == 'wait' || component == 'stock') && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    isAdmin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_OrderItem_OrderDeleteModal_OrderDeleteModal__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        dialogProps: {
                            open: isDeleteModal,
                            onClose: handleToggleModal(setIsDeleteModal)
                        },
                        title: "Вы точно хотите удалить заказ?",
                        buttonNoText: "Нет",
                        onClickYes: handleDeleteOrder(id),
                        onClickNo: handleToggleModal(setIsDeleteModal)
                    }),
                    isAdmin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_OrderItem_OrderStatusModal_OrderStatusModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        title: isWait ? 'Чтобы продолжить перенесите из ожидаемых на склад ' : 'Чтобы продолжить перенесите из склада в ожидаемые',
                        successCallback: handleSuccessChangeStatus(id),
                        orderItem: orderItem,
                        open: isStatusModal,
                        onClose: ()=>setIsStatusModal(false)
                        ,
                        component: component,
                        visibleDropDown: false,
                        buttonText: isWait ? 'На склад' : 'В ожидаемые',
                        submitStatus: isWait ? 1 : 0
                    })
                ]
            }),
            component == 'stock' && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_OrderItem_OrderDeleteModal_OrderDeleteModal__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        dialogProps: {
                            open: isReturnOrder,
                            onClose: handleToggleModal(setIsDeleteModal)
                        },
                        title: "Вы точно хотите вернуть заказ?",
                        onClickYes: handleReturnOrder(id),
                        onClickNo: handleToggleModal(setIsReturnOrder)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_ModalUI_ModalUI__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        ...dialogSuccessReturnProps
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_ModalUI_ModalUI__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        ...dialogCheckProps
                    })
                ]
            })
        ]
    }));
};
const { ContainerMUI  } = (0,_components_AnyPage_OrderItem_style__WEBPACK_IMPORTED_MODULE_2__/* .useOrderItemStyles */ .x)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(OrderItem));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2935:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ OrderItemBody_OrderItemBody)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/AnyPage/OrderItem/OrderItemBody/style.ts

const useOrderItemBodyStyles = ()=>{
    const ContainerMUI = (0,material_.styled)('div')(({ theme  })=>({
            display: 'flex',
            marginLeft: '55px',
            [theme.breakpoints.down(769)]: {
                marginLeft: 0
            }
        })
    );
    const IconMUI = (0,material_.styled)('div')(({ theme  })=>({
            width: '95px',
            height: '72px',
            marginRight: '43px',
            minWidth: '95px',
            minHeight: '72px',
            [theme.breakpoints.down(769)]: {
                marginRight: '10px'
            },
            [theme.breakpoints.down(501)]: {
                width: '40px',
                height: '40px',
                minWidth: '40px',
                minHeight: '40px'
            }
        })
    );
    const TextMUI = (0,material_.styled)('div')(({ theme  })=>({
            maxWidth: '425px',
            [theme.breakpoints.down(601)]: {
                maxWidth: '80%'
            }
        })
    );
    const TitleMUI = (0,material_.styled)('h5')(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '23px',
            wordWrap: 'break-word',
            fontWeight: 400,
            marginBottom: '15px',
            color: '#000000',
            [theme.breakpoints.down(769)]: {
                fontSize: '16px',
                lineHeight: '18px',
                marginBottom: '5px'
            }
        })
    );
    const LinkContainerMUI = (0,material_.styled)('div')(({ theme  })=>({
            marginBottom: '15px',
            display: 'flex',
            alignItems: 'center',
            [theme.breakpoints.down(769)]: {
                marginBottom: '5px'
            }
        })
    );
    const TrackNumberMUI = (0,material_.styled)('div')(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '23px',
            wordWrap: 'break-word',
            fontWeight: 400,
            maxWidth: '100%',
            color: '#000000',
            marginRight: '15px',
            [theme.breakpoints.down(769)]: {
                fontSize: '16px',
                lineHeight: '18px',
                marginRight: '9px',
                maxWidth: '170px'
            }
        })
    );
    const LinkMUI = (0,material_.styled)(material_.Link)(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '23px',
            fontWeight: 400,
            textDecoration: 'none',
            '& > a': {
                display: 'flex',
                alignItems: 'center',
                '& > svg': {
                    marginLeft: '8px',
                    width: '24px',
                    height: '24px'
                }
            },
            [theme.breakpoints.down(769)]: {
                fontSize: '16px',
                lineHeight: '18px',
                '& > a': {
                    '& > svg': {
                        width: '16px',
                        height: '19px',
                        marginLeft: '3px'
                    }
                }
            }
        })
    );
    const CommentMUI = (0,material_.styled)('p')(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '23px',
            fontWeight: 300,
            wordWrap: 'break-word',
            color: '#000000',
            [theme.breakpoints.down(769)]: {
                fontSize: '16px',
                lineHeight: '18px'
            }
        })
    );
    return {
        IconMUI,
        TextMUI,
        LinkMUI,
        TitleMUI,
        CommentMUI,
        TrackNumberMUI,
        LinkContainerMUI,
        ContainerMUI
    };
};

// EXTERNAL MODULE: ./src/UI/UIIcon/Busket.svg
var Busket = __webpack_require__(4711);
// EXTERNAL MODULE: ./src/UI/UIIcon/Arrow_Blue.svg
var Arrow_Blue = __webpack_require__(1500);
;// CONCATENATED MODULE: ./src/components/AnyPage/OrderItem/OrderItemBody/OrderItemBody.tsx





const OrderItemBody = ({ title , trackNumber , tracking_link , comment , visibleTrackNumber =false ,  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ContainerMUI, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(IconMUI, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Busket/* default */.Z, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(TextMUI, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(TitleMUI, {
                        children: title
                    }),
                    visibleTrackNumber && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(LinkContainerMUI, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(TrackNumberMUI, {
                                children: trackNumber
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(LinkMUI, {
                                href: tracking_link,
                                target: "_blank",
                                rel: "noreferrer",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    children: [
                                        "Отследить",
                                        /*#__PURE__*/ jsx_runtime_.jsx(Arrow_Blue/* default */.Z, {})
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(CommentMUI, {
                        children: comment
                    })
                ]
            })
        ]
    }));
};
const { IconMUI , TextMUI , TitleMUI , LinkMUI , CommentMUI , ContainerMUI , TrackNumberMUI , LinkContainerMUI ,  } = useOrderItemBodyStyles();
/* harmony default export */ const OrderItemBody_OrderItemBody = (/*#__PURE__*/external_react_default().memo(OrderItemBody));


/***/ }),

/***/ 2107:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_AnyPage_OrderItem_OrderItemTitle_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2056);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _UI_UIComponents_CheckboxUIV2_CheckboxUIV2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6091);
/* harmony import */ var _UI_UIComponents_DropDownUI_DropDownUI__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1211);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _UI_UIComponents_CheckboxUIV2_CheckboxUIV2__WEBPACK_IMPORTED_MODULE_4__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _UI_UIComponents_CheckboxUIV2_CheckboxUIV2__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const OrderItemTitle = ({ longId , id , visibleCheckbox =true , dropItems , visibleDropDown  })=>{
    const { control ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useFormContext)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContainerMUI, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(LeftContentMUI, {
                children: [
                    visibleCheckbox ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_CheckboxUIV2_CheckboxUIV2__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        controller: {
                            name: `${id}`,
                            control
                        }
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CheckboxContainerMUI, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TitleMUI, {
                        children: [
                            "Заказ № ",
                            longId
                        ]
                    })
                ]
            }),
            visibleDropDown && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_DropDownUI_DropDownUI__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                dropItems: dropItems
            })
        ]
    }));
};
const { TitleMUI , ContainerMUI , LeftContentMUI , CheckboxContainerMUI ,  } = (0,_components_AnyPage_OrderItem_OrderItemTitle_style__WEBPACK_IMPORTED_MODULE_2__/* .useOrderTitleStyles */ .h)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(OrderItemTitle));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2056:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ useOrderTitleStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useOrderTitleStyles = ()=>{
    const ContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            width: '100%',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '25px',
            [theme.breakpoints.down(1025)]: {
                marginBottom: '15px'
            }
        })
    );
    const CheckboxContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            width: '21px',
            height: '21px'
        })
    );
    const LeftContentMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex',
            alignItems: 'center'
        })
    );
    const TitleMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('h4')(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '24px',
            fontWeight: 400,
            color: '#000000',
            marginLeft: '26px',
            [theme.breakpoints.down(1025)]: {
                marginLeft: '10px',
                fontSize: '16px',
                lineHeight: '18px'
            }
        })
    );
    return {
        TitleMUI,
        ContainerMUI,
        LeftContentMUI,
        CheckboxContainerMUI
    };
};


/***/ }),

/***/ 3445:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _UI_UIComponents_ModalUI_ModalUI__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1705);
/* harmony import */ var _components_AnyPage_OrderItem_OrderStatusModal_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(873);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _components_AnyPage_OrderItem_OrderStatusModal_useOrderStatusModal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7161);
/* harmony import */ var _UI_UIComponents_DropDownCollapseUI_DropDownCollapseUI__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4623);
/* harmony import */ var _UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8595);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _components_AnyPage_OrderItem_OrderStatusModal_useOrderStatusModal__WEBPACK_IMPORTED_MODULE_5__, _UI_UIComponents_DropDownCollapseUI_DropDownCollapseUI__WEBPACK_IMPORTED_MODULE_6__, _UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_7__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _components_AnyPage_OrderItem_OrderStatusModal_useOrderStatusModal__WEBPACK_IMPORTED_MODULE_5__, _UI_UIComponents_DropDownCollapseUI_DropDownCollapseUI__WEBPACK_IMPORTED_MODULE_6__, _UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const OrderStatusModal = ({ open , onClose , title ='' , orderItem , successCallback , component , packageChange =false , visibleDropDown =true , buttonText ='Отлично' , submitStatus =0 ,  })=>{
    const { methods , onSubmit , collapseItems , trackNumberProps  } = (0,_components_AnyPage_OrderItem_OrderStatusModal_useOrderStatusModal__WEBPACK_IMPORTED_MODULE_5__/* .useOrderStatusModal */ .D)(open, orderItem, successCallback, component, packageChange, submitStatus);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_4__.FormProvider, {
        ...methods,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormMUI, {
            onSubmit: methods.handleSubmit(onSubmit),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_ModalUI_ModalUI__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                title: title,
                defaultStylesButton: false,
                dialogProps: {
                    open,
                    onClose,
                    sx: DialogSx
                },
                buttonProps: {
                    type: 'submit',
                    onClick: methods.handleSubmit(onSubmit),
                    sx: {
                        minWidth: '163px',
                        opacity: 1
                    }
                },
                buttonText: buttonText,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContainerMUI, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextFieldContainerMUI, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                ...trackNumberProps
                            })
                        }),
                        visibleDropDown && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DropDownContainerMUI, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_DropDownCollapseUI_DropDownCollapseUI__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                title: "Статус заказа",
                                required: true,
                                collapseItems: collapseItems
                            })
                        })
                    ]
                })
            })
        })
    }));
};
const { FormMUI , DialogSx , ContainerMUI , TextFieldContainerMUI , DropDownContainerMUI  } = (0,_components_AnyPage_OrderItem_OrderStatusModal_style__WEBPACK_IMPORTED_MODULE_3__/* .useOrderStatusModalStyles */ .p)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(OrderStatusModal));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ useOrderStatusModalStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useOrderStatusModalStyles = ()=>{
    const ContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            marginTop: '25px',
            width: '100%',
            maxWidth: '269px',
            margin: '19px auto 30px'
        })
    );
    const FormMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('form')(()=>({})
    );
    const TextFieldContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            width: '100%',
            '& > div': {
                '& > div.MuiFormControl-root': {
                    backgroundColor: '#F1F4F9'
                }
            }
        })
    );
    const DialogSx = {
        '& > div': {
            '& > div': {
                backgroundColor: '#F1F4F9'
            }
        }
    };
    const DropDownContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            paddingLeft: '20px'
        })
    );
    return {
        FormMUI,
        DialogSx,
        ContainerMUI,
        TextFieldContainerMUI,
        DropDownContainerMUI
    };
};


/***/ }),

/***/ 7161:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ useOrderStatusModal)
/* harmony export */ });
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5641);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7355);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4730);
/* harmony import */ var _reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7333);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_0__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const useOrderStatusModal = (isOpen, orderItem, successCallback, component, packageChange, submitStatus)=>{
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_3__/* .useAppDispatch */ .T)();
    const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_0__.useForm)();
    const collapseItems = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (component == 'wait') {
            return [
                {
                    title: 'На складе',
                    name: 'stock',
                    value: 1
                }, 
            ];
        }
        if (component == 'stock') {
            return [
                {
                    title: 'Ожидаемые',
                    name: 'wait',
                    value: 0
                }, 
            ];
        }
        if (component == 'stock2') {
            return [
                {
                    title: 'Отправленные',
                    name: 'send',
                    value: 2
                }, 
            ];
        }
        return [
            {
                title: '',
                name: '',
                value: -1
            }, 
        ];
    }, [
        component
    ]);
    const trackNumberProps = {
        controller: {
            name: 'trackNumber',
            control: methods.control,
            rules: {
                required: true,
                pattern: /^[a-zA-Z0-9]+$/g
            }
        },
        inputProps: {
            placeholder: 'Трек номер',
            disabled: component === 'wait' || component === 'stock'
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (orderItem.trackNumber && isOpen && !packageChange) {
            methods.setValue('trackNumber', orderItem.trackNumber);
        }
    }, [
        orderItem,
        isOpen,
        packageChange
    ]);
    const onSubmit = (data1)=>{
        var ref;
        if ((data1 === null || data1 === void 0 ? void 0 : data1.trackNumber) && ((data1 === null || data1 === void 0 ? void 0 : (ref = data1.orderStatus) === null || ref === void 0 ? void 0 : ref.value) !== undefined || submitStatus !== undefined)) {
            try {
                const trackNumber = methods.getValues('trackNumber');
                if (packageChange) {
                    dispatch((0,_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_4__/* .fetchChangeStatusPackageToSend */ .F4)({
                        userId: orderItem.userId,
                        packageId: orderItem.id,
                        trackNumber: trackNumber
                    })).then((r)=>{
                        if (r.payload) {
                            const data = r.payload;
                            if (data.message == 'success') {
                                successCallback();
                            }
                        }
                    });
                } else {
                    var ref1, ref2;
                    const statusId = (data1 === null || data1 === void 0 ? void 0 : (ref1 = data1.orderStatus) === null || ref1 === void 0 ? void 0 : ref1.value) ? data1 === null || data1 === void 0 ? void 0 : (ref2 = data1.orderStatus) === null || ref2 === void 0 ? void 0 : ref2.value : submitStatus;
                    _lib_http__WEBPACK_IMPORTED_MODULE_2__/* .octoAxios.post */ .N.post('/admin/orders', {
                        userId: orderItem.userId,
                        track_number: trackNumber ? trackNumber : orderItem.trackNumber,
                        title: orderItem.title,
                        comment: orderItem.comment,
                        statusId: statusId
                    }).then((r)=>{
                        if (r.data.message === 'success') {
                            successCallback();
                        }
                    });
                }
            } catch (e) {
                throw new Error('Error change status');
            }
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!isOpen) {
            methods.reset({
                trackNumber: '',
                orderStatus: undefined
            });
        }
    }, [
        isOpen
    ]);
    return {
        methods,
        onSubmit,
        collapseItems,
        trackNumberProps
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1286:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x": () => (/* binding */ useOrderItemStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useOrderItemStyles = ()=>{
    const ContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            width: '100%',
            marginBottom: '30px',
            [theme.breakpoints.down(769)]: {
                marginBottom: '15px',
                borderBottom: '1px solid #C4C4C4',
                paddingBottom: '15px'
            }
        })
    );
    return {
        ContainerMUI
    };
};


/***/ }),

/***/ 5391:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useOrderItemSend)
/* harmony export */ });
const useOrderItemSend = (orderId, orderItem)=>{
    return {
        orderId,
        orderItem
    };
};


/***/ }),

/***/ 3470:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ useOrderItemStock)
/* harmony export */ });
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(257);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4730);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7333);
/* harmony import */ var _reducers_orderStockSlice_orderStockSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6448);
/* harmony import */ var _hooks_useOrdersAccount__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7070);






const useOrderItemStock = (orderId1, orderItem)=>{
    const { isAdmin , user: { id: id1 ,  } ,  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_0__/* .useUserStore */ .L)();
    const { adminSwitchIdToUser ,  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .C)((state)=>state.adminReducer
    );
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppDispatch */ .T)();
    const { handlePushOrdersAddress  } = (0,_hooks_useOrdersAccount__WEBPACK_IMPORTED_MODULE_5__/* .useOrdersAccount */ .s)();
    const { 0: isStatusModal , 1: setIsStatusModal  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: isDeleteModal , 1: setIsDeleteModal  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: isReturnOrder , 1: setIsReturnOrder  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: isReturnSuccess , 1: setIsReturnSuccess  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        state: false,
        text: 'Спасибо за обращение \n' + 'Вам на почту придет письмо с подробной информацией'
    });
    const { 0: isCheckOrder , 1: setIsCheckOrder  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        state: false,
        text: 'Спасибо за обращение \n' + 'Вам на почту придет письмо с подробной информацией'
    });
    const innerId = isAdmin ? adminSwitchIdToUser ? adminSwitchIdToUser : id1 : id1;
    const handleToggleModal = (setState)=>{
        return ()=>{
            setState((prevState)=>!prevState
            );
        };
    };
    const handleSuccessChangeStatus = (id)=>{
        return ()=>{
            handleToggleModal(setIsStatusModal)();
            dispatch(_reducers_orderStockSlice_orderStockSlice__WEBPACK_IMPORTED_MODULE_4__/* .orderStockSlice.actions.filterStockData */ .x.actions.filterStockData(id));
        };
    };
    const handleDeleteOrder = (orderId)=>{
        return ()=>{
            if (innerId || orderId) {
                dispatch((0,_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_3__/* .fetchOrderDelete */ .WR)({
                    order: orderItem
                })).then(()=>setIsDeleteModal(false)
                );
            }
        };
    };
    const handleReturnOrder = (orderId)=>{
        return ()=>{
            if (innerId) {
                dispatch((0,_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_3__/* .fetchOrderReturn */ .hq)({
                    orderId
                })).then((response)=>{
                    const text = (response === null || response === void 0 ? void 0 : response.payload) == 'error' ? 'Что-то пошло не так, попробуйте позже' : 'Спасибо за обращение \n' + 'Вам на почту придет письмо с подробной информацией';
                    setIsReturnOrder(false);
                    setIsReturnSuccess({
                        state: true,
                        text
                    });
                }).catch(()=>{
                    setIsReturnSuccess({
                        state: true,
                        text: 'Спасибо за обращение \n' + 'Вам на почту придет письмо с подробной информацией'
                    });
                });
            }
        };
    };
    const handleCheckOrder = ()=>{
        if (orderId1) {
            dispatch((0,_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_3__/* .fetchOrderCheck */ .bg)({
                orderId: orderId1
            })).then((response)=>{
                const text = (response === null || response === void 0 ? void 0 : response.payload) == 'error' ? 'Что-то пошло не так, попробуйте позже' : 'Спасибо за обращение \n' + 'Вам на почту придет письмо с подробной информацией';
                setIsCheckOrder({
                    state: true,
                    text
                });
            });
        }
    };
    const handleSendOrder = ()=>{
        const url = isAdmin ? '/admin/packages' : '/user/package';
        dispatch((0,_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_3__/* .fetchMergeOrders */ .DK)({
            url: url,
            userId: adminSwitchIdToUser ? adminSwitchIdToUser : id1,
            orders: [
                orderId1
            ]
        })).then((response)=>{
            try {
                const payload = response.payload;
                const packageId = payload.packageData.id;
                if (packageId !== undefined) {
                    handlePushOrdersAddress(packageId);
                }
            } catch (e) {
                throw new Error('Error send order');
            }
        });
    };
    const dropDownData = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (!isAdmin) {
            return [
                {
                    title: 'Возврат',
                    onClick: handleToggleModal(setIsReturnOrder)
                },
                {
                    title: 'Проверка товара',
                    onClick: handleCheckOrder
                },
                {
                    title: 'Оформить',
                    onClick: handleSendOrder
                }, 
            ];
        }
        return [
            {
                title: 'Удалить',
                onClick: handleToggleModal(setIsDeleteModal)
            },
            {
                title: 'В ожидаемое',
                onClick: handleToggleModal(setIsStatusModal)
            },
            {
                title: 'Оформить',
                onClick: handleSendOrder
            }, 
        ];
    }, [
        isAdmin
    ]);
    const dialogSuccessReturnProps = {
        dialogProps: {
            open: isReturnSuccess.state,
            onClose: ()=>setIsReturnSuccess((prevState)=>({
                        state: !prevState.state,
                        text: prevState.text
                    })
                )
        },
        containerStyles: {
        },
        title: isReturnSuccess.text
    };
    const dialogCheckProps = {
        dialogProps: {
            open: isCheckOrder.state,
            onClose: ()=>setIsCheckOrder((prevState)=>({
                        state: !prevState.state,
                        text: prevState.text
                    })
                )
        },
        containerStyles: dialogSuccessReturnProps.containerStyles,
        title: isCheckOrder.text
    };
    return {
        isAdmin,
        isCheckOrder,
        dropDownData,
        isReturnOrder,
        isStatusModal,
        isDeleteModal,
        setIsStatusModal,
        setIsCheckOrder,
        setIsReturnOrder,
        setIsDeleteModal,
        handleReturnOrder,
        handleCheckOrder,
        handleToggleModal,
        handleDeleteOrder,
        dialogCheckProps,
        handleSuccessChangeStatus,
        dialogSuccessReturnProps
    };
};


/***/ }),

/***/ 9274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useOrderItemWait)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4730);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(257);
/* harmony import */ var _reducers_orderWaitSlice_asyncThunk_orderWaitApi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7106);
/* harmony import */ var _reducers_orderWaitSlice_orderWaitSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9238);





const useOrderItemWait = ()=>{
    const { isAdmin , user: { id: id1  }  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_2__/* .useUserStore */ .L)();
    const { adminSwitchIdToUser ,  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .C)((state)=>state.adminReducer
    );
    const { orderWaitData  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .C)((state)=>state.orderWaitReducer
    );
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppDispatch */ .T)();
    const { 0: isStatusModal , 1: setIsStatusModal  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { 0: isDeleteModal , 1: setIsDeleteModal  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const handleToggleModal = (setState)=>{
        return ()=>{
            setState((prevState)=>!prevState
            );
        };
    };
    const handleSuccessChangeStatus = (id)=>{
        return ()=>{
            handleToggleModal(setIsStatusModal)();
            dispatch(_reducers_orderWaitSlice_orderWaitSlice__WEBPACK_IMPORTED_MODULE_4__/* .orderWaitSlice.actions.sortOrderData */ .r.actions.sortOrderData(id));
        };
    };
    const handleDeleteOrder = (orderId)=>{
        return ()=>{
            const innerId = isAdmin ? adminSwitchIdToUser ? adminSwitchIdToUser : id1 : id1;
            if (innerId) {
                dispatch((0,_reducers_orderWaitSlice_asyncThunk_orderWaitApi__WEBPACK_IMPORTED_MODULE_3__/* .fetchDeleteOrders */ .FG)({
                    userId: innerId,
                    orderId: [
                        orderId
                    ],
                    ordersData: orderWaitData,
                    successCallback: handleToggleModal(setIsDeleteModal)
                }));
            }
        };
    };
    const dropDownData = [
        {
            title: 'Удалить',
            onClick: handleToggleModal(setIsDeleteModal)
        },
        {
            title: 'На склад',
            onClick: handleToggleModal(setIsStatusModal)
        }, 
    ];
    return {
        isAdmin,
        isStatusModal,
        isDeleteModal,
        dropDownData,
        setIsStatusModal,
        setIsDeleteModal,
        handleDeleteOrder,
        handleToggleModal,
        handleSuccessChangeStatus
    };
};


/***/ }),

/***/ 7183:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(257);
/* harmony import */ var _components_Login_Login__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6434);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Login_Login__WEBPACK_IMPORTED_MODULE_3__]);
_components_Login_Login__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// import IndexPage from '@/components/Index/Index';

function WithAuth(Component) {
    const Auth = (props)=>{
        const { isAuth  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_2__/* .useUserStore */ .L)();
        if (!isAuth) return(// <IndexPage/>
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Login_Login__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}));
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
            ...props
        }));
    };
    return Auth;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WithAuth);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7070:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ useOrdersAccount)
/* harmony export */ });
/* harmony import */ var _hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4763);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4730);


const useOrdersAccount = ()=>{
    const { router  } = (0,_hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_0__/* .useCustomRouter */ .c)();
    const { adminSwitchIdToUser , adminSwitchUserModel  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .C)((state)=>state.adminReducer
    );
    const handlePushOrdersAddress = (packageId)=>{
        if (adminSwitchIdToUser && adminSwitchUserModel) {
            router.push(`/account/orders/address?packageId=${packageId}&userId=${adminSwitchIdToUser}`);
        } else {
            router.push(`/account/orders/address?packageId=${packageId}`);
        }
    };
    return {
        handlePushOrdersAddress
    };
};


/***/ })

};
;