"use strict";
exports.id = 9601;
exports.ids = [9601];
exports.modules = {

/***/ 2656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



const HeaderMargin = ()=>{
    const HeaderMarginMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)('section')(({ theme  })=>({
            height: '61px',
            width: '100%',
            backgroundColor: '#FFFFFF',
            visibility: 'hidden',
            [theme.breakpoints.down(1181)]: {
                height: '71px'
            },
            [theme.breakpoints.down(1025)]: {
                height: '65px'
            },
            [theme.breakpoints.down(501)]: {
                height: '70px'
            }
        })
    );
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HeaderMarginMUI, {}));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(HeaderMargin));


/***/ }),

/***/ 8248:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Do": () => (/* binding */ fetchSearchShops),
/* harmony export */   "f5": () => (/* binding */ fetchTagShops),
/* harmony export */   "Kv": () => (/* binding */ fetchMoreTagShops),
/* harmony export */   "zo": () => (/* binding */ fetchAllTagsShops),
/* harmony export */   "mn": () => (/* binding */ fetchHintsSearchShops)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7355);



const fetchSearchShops = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('shopsSlice/search', async (data, thunkAPI)=>{
    try {
        const response1 = await _lib_http__WEBPACK_IMPORTED_MODULE_2__/* .octoAxios.get */ .N.get(`/shops?search=${data.search}`).then((response)=>response.data
        );
        return {
            shops: response1.search_results,
            search: data.search
        };
    } catch (e) {
        if (axios__WEBPACK_IMPORTED_MODULE_1___default().isAxiosError(e)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = e.response) === null || ref === void 0 ? void 0 : ref.status);
        }
    }
});
const fetchTagShops = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('shopsSlice/tags', async (data, thunkAPI)=>{
    try {
        const response3 = await _lib_http__WEBPACK_IMPORTED_MODULE_2__/* .octoAxios.get */ .N.get(`/shops?${data.tagsQuery}page=1`).then((response)=>response.data
        );
        return {
            shops: response3.shops,
            shopsEnd: !(response3.shops.length === response3.postsOnPage),
            tags: data.tagsQuery,
            isSearchNotFound: !!data.isSearchNotFound
        };
    } catch (e) {
        if (axios__WEBPACK_IMPORTED_MODULE_1___default().isAxiosError(e)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = e.response) === null || ref === void 0 ? void 0 : ref.status);
        }
    }
});
const fetchMoreTagShops = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('shopsSlice/moreTags', async (data, thunkAPI)=>{
    try {
        const response5 = await _lib_http__WEBPACK_IMPORTED_MODULE_2__/* .octoAxios.get */ .N.get(`/shops?${data.tagsQuery}page=${data.page}`).then((response)=>response.data
        );
        return {
            shops: response5.shops,
            shopsEnd: !(response5.shops.length === response5.postsOnPage),
            tags: data.tagsQuery
        };
    } catch (e) {
        if (axios__WEBPACK_IMPORTED_MODULE_1___default().isAxiosError(e)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = e.response) === null || ref === void 0 ? void 0 : ref.status);
        }
    }
});
const fetchAllTagsShops = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('shopsSlice/allTags', async (_, thunkAPI)=>{
    try {
        const response7 = await _lib_http__WEBPACK_IMPORTED_MODULE_2__/* .octoAxios.get */ .N.get('/shops_tags').then((response)=>response.data
        );
        return response7.shops_tags;
    } catch (e) {
        if (axios__WEBPACK_IMPORTED_MODULE_1___default().isAxiosError(e)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = e.response) === null || ref === void 0 ? void 0 : ref.status);
        }
    }
});
const fetchHintsSearchShops = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('shopsSlice/hintsSearch', async (data, thunkAPI)=>{
    try {
        const response9 = await _lib_http__WEBPACK_IMPORTED_MODULE_2__/* .octoAxios.get */ .N.get(`/shops?search_suggestions=${data.searchValue}`).then((response)=>response.data
        );
        return response9.search_suggestions_results;
    } catch (e) {
        if (axios__WEBPACK_IMPORTED_MODULE_1___default().isAxiosError(e)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = e.response) === null || ref === void 0 ? void 0 : ref.status);
        }
    }
});


/***/ }),

/***/ 5236:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ shopSlice),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_shopsSlice_asyncThunk_asyncThunk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8248);


const initialState = {
    search: '',
    shops: [],
    page: 1,
    tags: '',
    updateShops: true,
    shopsEnd: false,
    error: '',
    allTags: [],
    searchHints: [],
    isNotFoundShops: false
};
const shopSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'shopsSlice/info',
    initialState,
    reducers: {
        changeSearch (state, action) {
            state.search = action.payload;
        },
        updatePost (state) {
            state.updateShops = true;
        },
        changeFoundShops (state, action) {
            state.isNotFoundShops = action.payload;
        },
        changeHintsShops (state, action) {
            state.searchHints = action.payload;
        },
        resetSlice (state) {
            state.search = '';
            state.shops = [];
            state.page = 1;
            state.page = 1;
            state.tags = '';
            state.updateShops = true;
            state.shopsEnd = false;
            state.error = '';
        }
    },
    extraReducers: {
        [_reducers_shopsSlice_asyncThunk_asyncThunk__WEBPACK_IMPORTED_MODULE_1__/* .fetchHintsSearchShops.fulfilled.type */ .mn.fulfilled.type]: (state, action)=>{
            state.searchHints = action.payload;
        },
        [_reducers_shopsSlice_asyncThunk_asyncThunk__WEBPACK_IMPORTED_MODULE_1__/* .fetchSearchShops.fulfilled.type */ .Do.fulfilled.type]: (state, action)=>{
            state.shops = action.payload.shops;
            state.page = 1;
            state.updateShops = false;
            state.search = action.payload.search;
            state.isNotFoundShops = false;
        },
        [_reducers_shopsSlice_asyncThunk_asyncThunk__WEBPACK_IMPORTED_MODULE_1__/* .fetchSearchShops.pending.type */ .Do.pending.type]: (state)=>{
            state.updateShops = true;
        },
        [_reducers_shopsSlice_asyncThunk_asyncThunk__WEBPACK_IMPORTED_MODULE_1__/* .fetchSearchShops.rejected.type */ .Do.rejected.type]: (state)=>{
            state.updateShops = false;
            state.error = 'error';
        },
        [_reducers_shopsSlice_asyncThunk_asyncThunk__WEBPACK_IMPORTED_MODULE_1__/* .fetchTagShops.fulfilled.type */ .f5.fulfilled.type]: (state, action)=>{
            state.shops = action.payload.shops;
            state.shopsEnd = action.payload.shopsEnd;
            state.page = 2;
            state.updateShops = false;
            state.tags = action.payload.tags;
            state.isNotFoundShops = action.payload.isSearchNotFound;
            state.search = '';
        },
        [_reducers_shopsSlice_asyncThunk_asyncThunk__WEBPACK_IMPORTED_MODULE_1__/* .fetchTagShops.pending.type */ .f5.pending.type]: (state)=>{
            state.search = '';
        },
        [_reducers_shopsSlice_asyncThunk_asyncThunk__WEBPACK_IMPORTED_MODULE_1__/* .fetchTagShops.rejected.type */ .f5.rejected.type]: (state)=>{
            state.updateShops = false;
            state.error = 'error';
        },
        [_reducers_shopsSlice_asyncThunk_asyncThunk__WEBPACK_IMPORTED_MODULE_1__/* .fetchMoreTagShops.fulfilled.type */ .Kv.fulfilled.type]: (state, action)=>{
            state.shops = [
                ...state.shops,
                ...action.payload.shops
            ];
            state.updateShops = action.payload.shopsEnd;
            state.page += 1;
            state.shopsEnd = false;
            state.tags = action.payload.tags;
        },
        [_reducers_shopsSlice_asyncThunk_asyncThunk__WEBPACK_IMPORTED_MODULE_1__/* .fetchMoreTagShops.pending.type */ .Kv.pending.type]: (state)=>{
            state.updateShops = true;
            state.search = '';
        },
        [_reducers_shopsSlice_asyncThunk_asyncThunk__WEBPACK_IMPORTED_MODULE_1__/* .fetchMoreTagShops.rejected.type */ .Kv.rejected.type]: (state)=>{
            state.updateShops = false;
            state.error = 'error';
        },
        [_reducers_shopsSlice_asyncThunk_asyncThunk__WEBPACK_IMPORTED_MODULE_1__/* .fetchAllTagsShops.fulfilled.type */ .zo.fulfilled.type]: (state, action)=>{
            state.allTags = action.payload;
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (shopSlice.reducer);


/***/ })

};
;