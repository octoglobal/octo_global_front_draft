"use strict";
exports.id = 3326;
exports.ids = [3326];
exports.modules = {

/***/ 1423:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgArrowClose = function SvgArrowClose(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "m4.976 8.954 6.954 7.188 6.954-7.188",
    stroke: "#C4C4C4",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgArrowClose);

/***/ }),

/***/ 9467:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgArrowOpen = function SvgArrowOpen(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "m4.976 15.046 6.954-7.188 6.954 7.188",
    stroke: "#C7C7C7",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgArrowOpen);

/***/ }),

/***/ 3326:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_AnyPage_PackageItem_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5928);
/* harmony import */ var _components_AnyPage_OrderItem_OrderItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8786);
/* harmony import */ var _UI_UIComponents_DropDownUI_DropDownUI__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1211);
/* harmony import */ var _components_AnyPage_PackageItem_usePackageItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9666);
/* harmony import */ var _components_AnyPage_OrderItem_OrderStatusModal_OrderStatusModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3445);
/* harmony import */ var _UI_UIIcon_Arrow_Blue_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1500);
/* harmony import */ var _components_AnyPage_OrderItem_OrderDeleteModal_OrderDeleteModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1112);
/* harmony import */ var _mui_material_Collapse__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5732);
/* harmony import */ var _mui_material_Collapse__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Collapse__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4192);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_List__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _UIIcon_ArrowClose_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1423);
/* harmony import */ var _UIIcon_ArrowOpen_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9467);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_AnyPage_OrderItem_OrderItem__WEBPACK_IMPORTED_MODULE_3__, _components_AnyPage_OrderItem_OrderStatusModal_OrderStatusModal__WEBPACK_IMPORTED_MODULE_6__]);
([_components_AnyPage_OrderItem_OrderItem__WEBPACK_IMPORTED_MODULE_3__, _components_AnyPage_OrderItem_OrderStatusModal_OrderStatusModal__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









// import { DEFAULT_MIN_VERSION } from 'tls';




const PackageItem = ({ packageData , component , dropItems , isVisibleTrackNumber =false , onDeleteTrackNumber  })=>{
    var ref, ref1, ref2, ref3;
    const { id , orders , longId , isStatus , orderItem , isMobile , isChangeStatus , isVisibleAddress , isDropDownVisible , handleDeletePackage , handleAddTrackNumber , orderContainerStyles , isDeletePackageModal , handleToggleDeleteModal , isDeleteTrackNumberModal , modificationDropItemArray , handleDeleteTrackNumber , handleToggleDeleteTrackNumberModal , handleClick , open  } = (0,_components_AnyPage_PackageItem_usePackageItem__WEBPACK_IMPORTED_MODULE_5__/* .usePackageItem */ .r)(packageData, dropItems, component);
    const isVisibleStatus = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>isStatus.visible && isStatus.visibleText && !isVisibleTrackNumber
    , [
        isStatus,
        isVisibleTrackNumber
    ]);
    const sendPageStyleDropDownUI = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (component == 'send') return {
            width: '200px'
        };
        return {};
    }, [
        component
    ]);
    const handleConfirmDeleteTrackNumber = ()=>{
        handleDeleteTrackNumber();
        if (onDeleteTrackNumber) {
            onDeleteTrackNumber();
        }
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContainerMUI, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TitleMUI, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FlexEndMUI, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TitleTextMUI, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TextMUI, {
                                        children: [
                                            "Посылка № ",
                                            longId
                                        ]
                                    }),
                                    isVisibleStatus && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StatusTextMUI, {
                                        children: isStatus.text
                                    }),
                                    isVisibleTrackNumber && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TrackNumberContainerMUI, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TrackNumberMUI, {
                                                children: packageData.trackNumber
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TrackNumberLinkMUI, {
                                                rel: "noreferrer",
                                                href: packageData.tracking_link,
                                                target: "_blank",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TrackNumberLinkTextMUI, {
                                                        children: "Отследить"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TrackNumberIconMUI, {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIIcon_Arrow_Blue_svg__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ListItemButtonMUI, {
                                disableRipple: true,
                                onClick: handleClick,
                                children: open ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_ArrowOpen_svg__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_ArrowClose_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                            })
                        ]
                    }),
                    isDropDownVisible && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_DropDownUI_DropDownUI__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        itemId: id,
                        containerStyles: sendPageStyleDropDownUI,
                        dropItems: modificationDropItemArray
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(OrdersContainerMUI, {
                sx: orderContainerStyles,
                children: [
                    orders.map((order)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_OrderItem_OrderItem__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                orderItem: order,
                                visibleDropDown: false,
                                visibleCheckbox: false,
                                visibleTrackNumber: false,
                                visibleTitle: false,
                                component: component,
                                isBorderBottom: false
                            }, `${order.id}${order.longId}`)
                        })
                    ),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Collapse__WEBPACK_IMPORTED_MODULE_9___default()), {
                        in: open,
                        timeout: "auto",
                        unmountOnExit: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_List__WEBPACK_IMPORTED_MODULE_10___default()), {
                            component: "div",
                            disablePadding: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OrdersDitailsContainerMUI, {
                                children: orders.map((order)=>{
                                    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(OrdersLineContainerMUI, {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(OrdersLineItemContainerMUI, {
                                                children: [
                                                    'Заказ № ',
                                                    order.longId
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OrdersLineItemContainerMUI, {
                                                children: order.title
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OrdersLineItemTrackContainerMUI, {
                                                children: order.trackNumber
                                            })
                                        ]
                                    }, `${order.id}${order.longId}`));
                                })
                            })
                        })
                    })
                ]
            }),
            isVisibleAddress && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AddressContainerMUI, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AddressRowMUI, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AddressTextMUI, {
                                children: (ref = packageData.address) === null || ref === void 0 ? void 0 : ref.name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AddressTextMUI, {
                                children: (ref1 = packageData.address) === null || ref1 === void 0 ? void 0 : ref1.surname
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AddressTextMUI, {
                                children: (ref2 = packageData.address) === null || ref2 === void 0 ? void 0 : ref2.phone
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AddressTextMUI, {
                        children: (ref3 = packageData.address) === null || ref3 === void 0 ? void 0 : ref3.address_string
                    })
                ]
            }),
            isChangeStatus && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_OrderItem_OrderStatusModal_OrderStatusModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                title: isMobile ? 'Перед оформлением посылки не забудьте указать трек номер' : 'Перед оформлением посылки не забудьте \n' + 'указать трек номер',
                successCallback: handleAddTrackNumber,
                orderItem: orderItem,
                open: isChangeStatus,
                onClose: handleAddTrackNumber,
                component: 'stock2',
                packageChange: true,
                visibleDropDown: false
            }),
            isDeletePackageModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_OrderItem_OrderDeleteModal_OrderDeleteModal__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                dialogProps: {
                    open: isDeletePackageModal,
                    onClose: handleToggleDeleteModal
                },
                title: "Вы точно хотите удалить посылку?",
                onClickYes: handleDeletePackage,
                onClickNo: handleToggleDeleteModal
            }),
            isDeleteTrackNumberModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_OrderItem_OrderDeleteModal_OrderDeleteModal__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                dialogProps: {
                    open: isDeleteTrackNumberModal,
                    onClose: handleToggleDeleteTrackNumberModal
                },
                title: "Вы точно хотите удалить трек номер с этой посылки?",
                onClickYes: handleConfirmDeleteTrackNumber,
                onClickNo: handleToggleDeleteTrackNumberModal
            })
        ]
    }));
};
const { TextMUI , TitleMUI , TitleTextMUI , ContainerMUI , StatusTextMUI , TrackNumberMUI , AddressTextMUI , OrdersContainerMUI , AddressContainerMUI , TrackNumberLinkMUI , TrackNumberLinkTextMUI , TrackNumberContainerMUI , TrackNumberIconMUI , AddressRowMUI , OrdersDitailsContainerMUI , OrdersLineContainerMUI , OrdersLineItemContainerMUI , OrdersLineItemTrackContainerMUI , ListItemButtonMUI , FlexEndMUI ,  } = (0,_components_AnyPage_PackageItem_style__WEBPACK_IMPORTED_MODULE_2__/* .usePackageItemStyles */ .r)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(PackageItem));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5928:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ usePackageItemStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1011);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_1__);


const usePackageItemStyles = ()=>{
    const ContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            [theme.breakpoints.down(769)]: {
                paddingBottom: '5px',
                borderBottom: '1px solid #C4C4C4',
                marginBottom: '15px'
            }
        })
    );
    const TextMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('h2')(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '24px',
            fontWeight: 400,
            color: '#000000',
            [theme.breakpoints.down(769)]: {
                fontSize: '16px',
                lineHeight: '18px',
                marginRight: '10px'
            }
        })
    );
    const TrackNumberContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            display: 'flex',
            alignItems: 'flex-end',
            marginLeft: '20px',
            [theme.breakpoints.down(769)]: {
                marginLeft: '0px'
            }
        })
    );
    const TrackNumberMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('p')(({ theme  })=>({
            fontSize: '18px',
            lineHeight: '24px',
            fontWeight: 400,
            color: '#000000',
            maxWidth: '200px',
            wordWrap: 'break-word',
            [theme.breakpoints.down(769)]: {
                fontSize: '16px',
                lineHeight: '19px',
                marginRight: '10px'
            }
        })
    );
    const TrackNumberLinkMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Link)(()=>({
            display: 'flex',
            textDecoration: 'none'
        })
    );
    const TrackNumberLinkTextMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '23px',
            fontWeight: 400,
            marginLeft: '10px',
            color: '#274D82',
            cursor: 'pointer',
            [theme.breakpoints.down(769)]: {
                fontSize: '16px',
                lineHeight: '19px',
                marginLeft: 0
            }
        })
    );
    const TrackNumberIconMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Link)(({ theme  })=>({
            marginLeft: '10px',
            width: '24px',
            height: '24px',
            [theme.breakpoints.down(769)]: {
                marginLeft: '1px',
                width: '19px',
                height: '19px'
            }
        })
    );
    const TitleMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '25px',
            [theme.breakpoints.down(769)]: {
                marginBottom: '15px',
                marginRight: '10px'
            }
        })
    );
    const TitleTextMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex',
            alignItems: 'center',
            flexWrap: 'wrap'
        })
    );
    const StatusTextMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('p')(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '24px',
            fontWeight: 300,
            color: '#274D82',
            marginLeft: '16px',
            [theme.breakpoints.down(769)]: {
                fontSize: '12px',
                lineHeight: '14px',
                marginLeft: '0px'
            }
        })
    );
    const OrdersContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({})
    );
    const AddressContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            margin: '15px 0px',
            marginLeft: '193px',
            [theme.breakpoints.down(769)]: {
                margin: '10px 0 10px 105px'
            },
            [theme.breakpoints.down(501)]: {
                marginLeft: '50px'
            }
        })
    );
    const AddressRowMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex',
            flexWrap: 'wrap'
        })
    );
    const AddressTextMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('span')(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '24px',
            fontWeight: 300,
            color: '#000000',
            marginRight: '15px',
            [theme.breakpoints.down(769)]: {
                fontSize: '16px',
                lineHeight: '20px'
            }
        })
    );
    const OrdersDitailsContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            marginTop: '30px',
            marginBottom: 20,
            marginLeft: 194,
            display: 'flex',
            flexDirection: 'column',
            borderBottom: '2px solid #C4C4C4',
            [theme.breakpoints.down(750)]: {
                marginLeft: 0,
                borderBottom: 'none'
            },
            [theme.breakpoints.down(500)]: {
                marginTop: '0px',
                marginBottom: 0
            }
        })
    );
    const OrdersLineContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            display: 'flex',
            alignItems: 'center',
            marginBottom: 14,
            [theme.breakpoints.down(500)]: {
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                gridTemplateAreas: `
				"a a"
				"b b"
				`
            }
        })
    );
    const OrdersLineItemContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            fontSize: 20,
            fontWeight: 400,
            marginRight: '32px',
            maxWidth: '220px',
            minWidth: 220,
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            '&:nth-child(2)': {
                [theme.breakpoints.down(500)]: {
                    textAlign: 'end'
                }
            },
            [theme.breakpoints.down(1220)]: {
                maxWidth: '200px',
                minWidth: 200
            },
            // [theme.breakpoints.down(1180)]:{
            // 	maxWidth: '180px',
            // 	minWidth: 180,
            // },
            [theme.breakpoints.down(1180)]: {
                maxWidth: '150px',
                minWidth: 150
            },
            [theme.breakpoints.down(500)]: {
                fontSize: '16px'
            }
        })
    );
    const OrdersLineItemTrackContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            fontSize: 18,
            fontWeight: 500,
            [theme.breakpoints.down(500)]: {
                fontSize: 12,
                color: '#C4C4C4'
            }
        })
    );
    const ListItemButtonMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_1___default()))(({ theme  })=>({
            padding: 0,
            maxWidth: 24,
            marginLeft: 23,
            '&:hover': {
                background: 'none'
            },
            [theme.breakpoints.down(500)]: {
                marginRight: 30
            }
        })
    );
    const FlexEndMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex'
        })
    );
    return {
        TextMUI,
        TitleMUI,
        ContainerMUI,
        TitleTextMUI,
        AddressRowMUI,
        AddressTextMUI,
        StatusTextMUI,
        TrackNumberMUI,
        TrackNumberIconMUI,
        OrdersContainerMUI,
        OrdersDitailsContainerMUI,
        AddressContainerMUI,
        TrackNumberLinkTextMUI,
        TrackNumberContainerMUI,
        TrackNumberLinkMUI,
        OrdersLineContainerMUI,
        OrdersLineItemContainerMUI,
        OrdersLineItemTrackContainerMUI,
        ListItemButtonMUI,
        FlexEndMUI
    };
};


/***/ }),

/***/ 9666:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ usePackageItem)
/* harmony export */ });
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(257);
/* harmony import */ var _hooks_useOrdersAccount__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7070);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4730);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7333);
/* harmony import */ var _reducers_orderSendSlice_asyncThunk_orderSendApi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1562);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_6__);







const usePackageItem = (packageData, dropItems, component)=>{
    const { 0: open , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const handleClick = ()=>{
        setOpen(!open);
    };
    const { longId , orders , id , statusId  } = packageData;
    const { isAdmin  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_0__/* .useUserStore */ .L)();
    const { handlePushOrdersAddress  } = (0,_hooks_useOrdersAccount__WEBPACK_IMPORTED_MODULE_1__/* .useOrdersAccount */ .s)();
    const { adminSwitchIdToUser  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_2__/* .useAppSelector */ .C)((state)=>state.adminReducer
    );
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_2__/* .useAppDispatch */ .T)();
    const isMobile = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.useMediaQuery)('(max-width: 450px)');
    const { 0: isChangeStatus , 1: setIsChangeStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { 0: isDeletePackageModal , 1: setIsDeletePackageModal  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { 0: isDeleteTrackNumberModal , 1: setIsDeleteTrackNumberModal  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const isVisibleAddress = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return !!(packageData === null || packageData === void 0 ? void 0 : packageData.address);
    }, [
        packageData
    ]);
    const orderContainerStyles = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>isVisibleAddress ? {
            '& > *:last-child': {
                marginBottom: 0
            }
        } : {}
    , [
        isVisibleAddress
    ]);
    const orderItem = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return {
            id: packageData.id,
            trackNumber: '',
            statusId: packageData.statusId,
            createdTime: '',
            longId: packageData.longId,
            title: '',
            tracking_link: '',
            userId: adminSwitchIdToUser,
            comment: ''
        };
    }, [
        packageData
    ]);
    const isStatus = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        switch(statusId){
            case 0:
                return {
                    text: 'Объединено пользователем',
                    visible: true,
                    status: 0,
                    visibleText: isAdmin
                };
            case 1:
                return {
                    text: 'Объединено администратором',
                    visible: true,
                    status: 1,
                    visibleText: true
                };
            case 2:
                return {
                    text: 'Готовится к отправлению',
                    visible: true,
                    status: 2,
                    visibleText: true
                };
            case 3:
                return {
                    text: 'Отправлен',
                    visible: true,
                    status: 3,
                    visibleText: true
                };
            case 4:
                return {
                    text: 'Отклонено администратором',
                    visible: true,
                    status: 4,
                    visibleText: true
                };
            default:
                return {
                    text: '',
                    visible: false,
                    status: null
                };
        }
    }, [
        statusId
    ]);
    const isDropDownVisible = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>(isStatus.status === 0 || isStatus.status === 1 || isStatus.status === 2 && isAdmin || isStatus.status === 4 && isAdmin || component == 'send' && isAdmin) && isStatus.visible
    , [
        isStatus
    ]);
    const handleSendPackage = ()=>{
        handlePushOrdersAddress(id);
    };
    const handleDeleteAddress = ()=>{
        if (adminSwitchIdToUser && id) {
            dispatch((0,_reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_4__/* .fetchPackageRemoveAddress */ .ro)({
                packageId: id,
                userId: adminSwitchIdToUser
            }));
        }
    };
    const handleAddTrackNumber = ()=>{
        setIsChangeStatus((prevState)=>!prevState
        );
    };
    const handleToggleDeleteModal = ()=>{
        setIsDeletePackageModal((prevState)=>!prevState
        );
    };
    const handleToggleDeleteTrackNumberModal = ()=>{
        setIsDeleteTrackNumberModal((prevState)=>!prevState
        );
    };
    const handleDeletePackage = ()=>{
        if (id && adminSwitchIdToUser) {
            const fetchDelete = component == 'stock' ? _reducers_orderStockSlice_asynThunk_stockApi__WEBPACK_IMPORTED_MODULE_4__/* .fetchDeletePackage */ .eH : _reducers_orderSendSlice_asyncThunk_orderSendApi__WEBPACK_IMPORTED_MODULE_5__/* .fetchDeletePackageInSend */ .x6;
            dispatch(fetchDelete({
                packageId: id,
                userId: adminSwitchIdToUser
            })).then(()=>{
                handleToggleDeleteModal();
            });
        }
    };
    const handleDeleteTrackNumber = ()=>{
        if (id && adminSwitchIdToUser) {
            dispatch((0,_reducers_orderSendSlice_asyncThunk_orderSendApi__WEBPACK_IMPORTED_MODULE_5__/* .fetchDeleteTrackNumber */ .jD)({
                userId: adminSwitchIdToUser,
                packageId: id
            })).then(()=>{
                handleToggleDeleteTrackNumberModal();
            });
        }
    };
    const modificationDropItemArray = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        let dropItemsArray = [];
        if (statusId === 2 && isAdmin) {
            dropItemsArray = [
                {
                    title: 'Удалить адрес',
                    onClick: handleDeleteAddress
                },
                {
                    title: 'В отправленные',
                    onClick: handleAddTrackNumber
                }
            ];
        } else if (statusId === 1 && !isAdmin) {
            dropItemsArray = [
                {
                    title: 'Оформить',
                    onClick: handleSendPackage
                }
            ];
        } else if (statusId === 4 && isAdmin) {
            dropItemsArray = [
                ...dropItems, 
            ];
        } else if (statusId === 3 && component == 'send') {
            dropItemsArray = [
                {
                    title: 'На склад',
                    onClick: handleToggleDeleteTrackNumberModal
                }
            ];
        } else {
            dropItemsArray = dropItems;
        }
        if (isAdmin) {
            return [
                ...dropItemsArray,
                {
                    title: 'Удалить',
                    onClick: handleToggleDeleteModal
                }
            ];
        }
        return dropItemsArray;
    }, [
        statusId
    ]);
    return {
        id,
        longId,
        orders,
        isStatus,
        orderItem,
        isMobile,
        isChangeStatus,
        isVisibleAddress,
        setIsChangeStatus,
        isDropDownVisible,
        isDeletePackageModal,
        handleDeletePackage,
        handleAddTrackNumber,
        handleToggleDeleteModal,
        isDeleteTrackNumberModal,
        handleDeleteTrackNumber,
        handleToggleDeleteTrackNumberModal,
        orderContainerStyles,
        modificationDropItemArray,
        setIsDeleteTrackNumberModal,
        handleClick,
        open
    };
};


/***/ })

};
;