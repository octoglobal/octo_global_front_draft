"use strict";
exports.id = 4584;
exports.ids = [4584];
exports.modules = {

/***/ 8170:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgShopsTagsListArrow = function SvgShopsTagsListArrow(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    viewBox: "0 0 24 33",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "m4.974 8.954 6.954 7.188 6.954-7.188M4.974 17.954l6.954 7.188 6.954-7.188",
    stroke: "#274D82",
    strokeOpacity: 0.5,
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgShopsTagsListArrow);

/***/ }),

/***/ 4584:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ BlogItem_BlogItem)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/Blog/BlogItem/style.ts

const useBlogItemStyles = ()=>{
    const ItemMUI = (0,material_.styled)('li')(()=>({
            marginBottom: '5px',
            listStyle: 'none',
            borderBottom: '1px solid #C4C4C4'
        })
    );
    const WrapperMUI = (0,material_.styled)('div')(()=>({
            maxWidth: '1072px',
            margin: '0 auto'
        })
    );
    const ItemTitleMUI = (0,material_.styled)('h4')(({ theme  })=>({
            wordWrap: 'break-word',
            fontSize: '24px',
            fontWeight: 400,
            lineHeight: '28px',
            margin: '30px 0 40px',
            color: '#000000',
            [theme.breakpoints.down(769)]: {
                margin: '15px 0'
            }
        })
    );
    const ButtonIconMUI = (0,material_.styled)(material_.Button)(({ theme  })=>({
            display: 'block',
            width: '24px',
            height: '33px',
            padding: '0',
            border: 0,
            backgroundColor: 'transparent',
            minWidth: 'auto',
            margin: '0 auto 6px',
            textAlign: 'center',
            [theme.breakpoints.down(769)]: {
                width: '14px',
                height: '22px'
            }
        })
    );
    const ProductListMUI = (0,material_.styled)('ul')(({ theme  })=>({
            display: 'flex',
            justifyContent: 'space-between',
            marginBottom: '15px',
            minHeight: '330px',
            '& > *:last-child': {
                marginRight: 0
            },
            '& > *:nth-child(3)': {
                marginRight: 25,
                [theme.breakpoints.down(769)]: {
                    marginRight: 0
                }
            },
            [theme.breakpoints.down(769)]: {
                minHeight: 'auto'
            }
        })
    );
    const BtnSectionMUI = (0,material_.styled)('div')(({ theme  })=>({
            [theme.breakpoints.down(1025)]: {
                position: 'absolute',
                right: 0,
                top: 0,
                display: 'flex',
                width: '50px'
            }
        })
    );
    const BtnSectionWrapperMUI = (0,material_.styled)('div')(({ theme  })=>({
            [theme.breakpoints.down(1025)]: {
                position: 'relative'
            }
        })
    );
    const CollapseDescMUI = (0,material_.styled)(material_.Collapse)(()=>({})
    );
    return {
        ItemMUI,
        WrapperMUI,
        ItemTitleMUI,
        ButtonIconMUI,
        ProductListMUI,
        CollapseDescMUI,
        BtnSectionMUI,
        BtnSectionWrapperMUI
    };
};

// EXTERNAL MODULE: ./src/UI/UIIcon/ShopsTagsListArrow.svg
var ShopsTagsListArrow = __webpack_require__(8170);
;// CONCATENATED MODULE: ./src/components/Blog/BlogProduct/style.ts

const useBlogProductStyles = ()=>{
    const ItemMUI = (0,material_.styled)('li')(({ theme  })=>({
            marginRight: '32px',
            listStyle: 'none',
            width: '100%',
            maxWidth: '33.3333%',
            minWidth: '31%',
            textAlign: 'center',
            [theme.breakpoints.down(1025)]: {
                marginRight: '15px'
            },
            [theme.breakpoints.down(769)]: {
                marginRight: '6px'
            }
        })
    );
    const PhotoMUI = (0,material_.styled)('img')(({ theme  })=>({
            width: '100%',
            height: '208px',
            objectFit: 'cover',
            maxHeight: '208px',
            marginBottom: '10px',
            boxShadow: '0 0 10px rgba(0, 0, 0, 0.25)',
            [theme.breakpoints.down(601)]: {
                maxHeight: '114px',
                height: '114px'
            }
        })
    );
    const TitleMUI = (0,material_.styled)('h6')(()=>({
            marginBottom: '10px',
            fontSize: '24px',
            lineHeight: '28px',
            fontWeight: 400,
            wordWrap: 'break-word'
        })
    );
    const DescriptionMUI = (0,material_.styled)('p')(()=>({
            marginBottom: '20px',
            fontSize: '20px',
            lineHeight: '24px',
            wordWrap: 'break-word',
            fontWeight: 300
        })
    );
    const LinkMUI = (0,material_.styled)(material_.Link)(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '23px',
            fontWeight: 400,
            color: '#274D82',
            wordWrap: 'break-word',
            textDecoration: 'none',
            [theme.breakpoints.down(769)]: {
                fontSize: '14px',
                lineHeight: '16px'
            }
        })
    );
    return {
        ItemMUI,
        LinkMUI,
        PhotoMUI,
        TitleMUI,
        DescriptionMUI
    };
};

// EXTERNAL MODULE: ./src/lib/constants/constants.ts
var constants = __webpack_require__(4989);
;// CONCATENATED MODULE: ./src/components/Blog/BlogProduct/useBlogProduct.ts



const useBlogProduct = (newPost, photo, url)=>{
    const isTablet = (0,material_.useMediaQuery)('(max-width: 768px)');
    const photoSrc = (0,external_react_.useMemo)(()=>{
        if (newPost) {
            return photo;
        }
        return `${constants/* HOST */.M5}/image/${photo}`;
    }, [
        photo
    ]);
    const productLink = (0,external_react_.useMemo)(()=>{
        const linkObj = {
            nameLink: url,
            hrefLink: url
        };
        if (url) {
            const urlArray = url.split('/');
            const nameLink = urlArray[0].substring(1);
            const hrefLink = urlArray.slice(1).join('/');
            linkObj.nameLink = nameLink;
            linkObj.hrefLink = hrefLink.substring(0, hrefLink.length - 1);
        }
        return linkObj;
    }, [
        url
    ]);
    return {
        isTablet,
        photoSrc,
        productLink
    };
};

;// CONCATENATED MODULE: ./src/components/Blog/BlogProduct/BlogProduct.tsx




const BlogProduct = ({ title , body , url , photo , newPost  })=>{
    const { isTablet , productLink , photoSrc ,  } = useBlogProduct(!!newPost, photo, url);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ItemMUI, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(PhotoMUI, {
                src: photoSrc,
                alt: title
            }),
            !isTablet && /*#__PURE__*/ jsx_runtime_.jsx(TitleMUI, {
                children: title
            }),
            !isTablet && /*#__PURE__*/ jsx_runtime_.jsx(DescriptionMUI, {
                children: body
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(LinkMUI, {
                target: "_blank",
                rel: "noreferrer",
                href: productLink.hrefLink,
                children: productLink.nameLink
            })
        ]
    }));
};
const { ItemMUI , PhotoMUI , TitleMUI , DescriptionMUI , LinkMUI  } = useBlogProductStyles();
/* harmony default export */ const BlogProduct_BlogProduct = (/*#__PURE__*/external_react_default().memo(BlogProduct));

;// CONCATENATED MODULE: ./src/components/Blog/BlogItem/useBlogItem.ts

const useBlogItem = (title, viewDescription, isTitleSplice)=>{
    const { 0: isOpenDesc , 1: setIsOpenDesc  } = (0,external_react_.useState)(false);
    const handleToggleDesc = ()=>{
        setIsOpenDesc((prevState)=>!prevState
        );
    };
    // const reduceString = (text:string, limit:number):string => {
    // 	text = text.trim();
    // 	if( text.length <= limit) return text;
    // 	text = text.slice( 0, limit);
    // 	const lastSpace = text.lastIndexOf(' ');
    // 	if( lastSpace > 0) {
    // 		text = text.substring(0, lastSpace);
    // 	}
    // 	return text + '...';
    // };
    // const windowInnerWidth = window.innerWidth
    const modifiedTitle = (0,external_react_.useMemo)(()=>{
        if (isTitleSplice) {
            // Вот тут менять!!!!
            return title;
        // return reduceString(title,10);
        }
        return title;
    }, [
        isTitleSplice
    ]);
    const dopItemStyle = (0,external_react_.useMemo)(()=>{
        if (viewDescription) {
            return {
                item: {},
                title: {}
            };
        }
        return {
            item: {
                borderBottom: 0
            },
            title: {
                marginBottom: '31px',
                textAlign: 'center'
            }
        };
    }, [
        viewDescription
    ]);
    return {
        isOpenDesc,
        dopItemStyle,
        modifiedTitle,
        handleToggleDesc
    };
};

;// CONCATENATED MODULE: ./src/components/Blog/BlogItemDescription/style.ts

const useBlogItemDescriptionStyles = ()=>{
    const PreMUI = (0,material_.styled)('pre')(({ theme  })=>({
            wordWrap: 'break-word',
            overflow: 'hidden',
            fontSize: '20px',
            lineHeight: '24px',
            fontWeight: 300,
            fontFamily: 'Roboto',
            maxWidth: '100%',
            whiteSpace: 'break-spaces',
            marginBottom: '30px',
            [theme.breakpoints.down(769)]: {
                fontSize: '16px',
                lineHeight: '18px'
            }
        })
    );
    return {
        PreMUI
    };
};

;// CONCATENATED MODULE: ./src/components/Blog/BlogItemDescription/BlogItemDescription.tsx



const BlogItemDescription = ({ description  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(PreMUI, {
        children: description
    }));
};
const { PreMUI  } = useBlogItemDescriptionStyles();
/* harmony default export */ const BlogItemDescription_BlogItemDescription = (/*#__PURE__*/external_react_default().memo(BlogItemDescription));

// EXTERNAL MODULE: ./src/hooks/useMedia.ts
var useMedia = __webpack_require__(2447);
;// CONCATENATED MODULE: ./src/components/Blog/BlogItem/BtnSection/style.tsx

const useBtnSectionStyles = ()=>{
    const ButtonIconMUI = (0,material_.styled)(material_.Button)(({ theme  })=>({
            display: 'block',
            // width: '24px',
            // height: '33px',
            padding: '0',
            border: 0,
            backgroundColor: 'transparent',
            minWidth: 'auto',
            margin: '0 auto 6px',
            textAlign: 'center',
            [theme.breakpoints.down(769)]: {
            }
        })
    );
    const BtnSectionMUI = (0,material_.styled)('div')(({ theme  })=>({
            [theme.breakpoints.down(1025)]: {
                position: 'absolute',
                right: 0,
                top: 0,
                display: 'flex',
                width: '50px'
            }
        })
    );
    return {
        ButtonIconMUI,
        BtnSectionMUI
    };
};

// EXTERNAL MODULE: ./src/UI/UIIcon/Basket.svg
var Basket = __webpack_require__(7794);
;// CONCATENATED MODULE: ./src/UI/UIIcon/EditPencilBlue.svg
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgEditPencilBlue = function SvgEditPencilBlue(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 20,
    height: 20,
    viewBox: "0 0 24 24",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M20.298 3.838 16.84.38l-1.73 1.729-.864.864L1.28 15.941l-.865 4.322 4.323-.864.865-.865.864-.864L20.298 3.838ZM6.466 17.67l-3.458-3.458-.864.864 3.458 3.458.864-.864Zm7.78-14.697 3.458 3.458.865-.864-3.458-3.458-.865.864Z",
    fill: "#274D82"
  })));
};

/* harmony default export */ const EditPencilBlue = (SvgEditPencilBlue);
// EXTERNAL MODULE: ./src/hooks/useReduxHooks.ts
var useReduxHooks = __webpack_require__(4730);
// EXTERNAL MODULE: ./src/store/reducers/blogSlice/asyncThunk/blogApi.ts
var blogApi = __webpack_require__(7779);
// EXTERNAL MODULE: ./src/store/reducers/blogSlice/blogSlice.ts
var blogSlice = __webpack_require__(6559);
// EXTERNAL MODULE: ./src/hooks/useUserStore.ts
var useUserStore = __webpack_require__(257);
;// CONCATENATED MODULE: ./src/components/Blog/BlogItem/BtnSection/useBtnSection.tsx





const useBtnSection = (id1)=>{
    const { 0: openConfirmDialog , 1: setOpenConfirmDialog  } = (0,external_react_.useState)(false);
    const dispatch = (0,useReduxHooks/* useAppDispatch */.T)();
    const { isAdmin  } = (0,useUserStore/* useUserStore */.L)();
    const canRender = isAdmin && window.location.pathname !== '/' ? true : false;
    const handlerDialogOpen = ()=>{
        setOpenConfirmDialog(true);
    };
    const handlerFetchDelete = (id)=>{
        return ()=>{
            dispatch((0,blogApi/* fetchDeleteBlogItem */.FM)({
                id: id
            }));
            setOpenConfirmDialog(false);
        };
    };
    const handlerCancel = ()=>{
        setOpenConfirmDialog(false);
    };
    const handleEditMode = ()=>{
        dispatch((0,blogSlice/* updateEditMode */.eY)({
            open: true,
            id: id1
        }));
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };
    return {
        openConfirmDialog,
        canRender,
        handlerDialogOpen,
        handlerFetchDelete,
        handlerCancel,
        handleEditMode
    };
};

// EXTERNAL MODULE: ./src/components/AnyPage/OrderItem/OrderDeleteModal/OrderDeleteModal.tsx + 1 modules
var OrderDeleteModal = __webpack_require__(1112);
;// CONCATENATED MODULE: ./src/components/Blog/BlogItem/BtnSection/BtnSection.tsx







const BtnSection = ({ id  })=>{
    const { openConfirmDialog , canRender , handlerDialogOpen , handlerFetchDelete , handlerCancel , handleEditMode ,  } = useBtnSection(id);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            canRender ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(BtnSectionMUI, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ButtonIconMUI, {
                        onClick: handlerDialogOpen,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Basket/* default */.Z, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ButtonIconMUI, {
                        onClick: handleEditMode,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(EditPencilBlue, {})
                    })
                ]
            }) : null,
            /*#__PURE__*/ jsx_runtime_.jsx(OrderDeleteModal/* default */.Z, {
                dialogProps: {
                    open: openConfirmDialog
                },
                buttonNoText: "Нет",
                title: "Вы уверены что хотите удалить пост?",
                onClickYes: handlerFetchDelete(id),
                onClickNo: handlerCancel
            })
        ]
    }));
};
const { ButtonIconMUI , BtnSectionMUI ,  } = useBtnSectionStyles();
/* harmony default export */ const BtnSection_BtnSection = (/*#__PURE__*/external_react_default().memo(BtnSection));

;// CONCATENATED MODULE: ./src/components/Blog/BlogItem/BlogItem.tsx









const BlogItem = ({ title , products , body , newPost , viewDescription =true , isTitleSplice =false , id ,  })=>{
    const { isOpenDesc , modifiedTitle , dopItemStyle , handleToggleDesc ,  } = useBlogItem(title, viewDescription, isTitleSplice);
    const { isCustomSize  } = (0,useMedia/* useCustomSize */.ZB)(1025);
    return(/*#__PURE__*/ jsx_runtime_.jsx(BlogItem_ItemMUI, {
        sx: dopItemStyle.item,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(WrapperMUI, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(ItemTitleMUI, {
                    sx: dopItemStyle.title,
                    children: modifiedTitle
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ProductListMUI, {
                    children: [
                        products.map((product, index)=>/*#__PURE__*/ jsx_runtime_.jsx(BlogProduct_BlogProduct, {
                                newPost: newPost,
                                ...product
                            }, `${product.title}${product.url}${index}`)
                        ),
                        isCustomSize ? null : /*#__PURE__*/ jsx_runtime_.jsx(BtnSection_BtnSection, {
                            id: id
                        })
                    ]
                }),
                viewDescription && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(BtnSectionWrapperMUI, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(BlogItem_ButtonIconMUI, {
                            onClick: handleToggleDesc,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ShopsTagsListArrow/* default */.Z, {})
                        }),
                        isCustomSize ? /*#__PURE__*/ jsx_runtime_.jsx(BtnSection_BtnSection, {
                            id: id
                        }) : null,
                        /*#__PURE__*/ jsx_runtime_.jsx(CollapseDescMUI, {
                            in: isOpenDesc,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(BlogItemDescription_BlogItemDescription, {
                                description: body
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
const { ItemMUI: BlogItem_ItemMUI , WrapperMUI , ItemTitleMUI , ButtonIconMUI: BlogItem_ButtonIconMUI , ProductListMUI , CollapseDescMUI , BtnSectionWrapperMUI ,  } = useBlogItemStyles();
/* harmony default export */ const BlogItem_BlogItem = (/*#__PURE__*/external_react_default().memo(BlogItem));


/***/ })

};
;