"use strict";
exports.id = 2483;
exports.ids = [2483];
exports.modules = {

/***/ 5475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _circle, _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgLightningInsideCircleTransp = function SvgLightningInsideCircleTransp(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    viewBox: "0 0 30 30",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _circle || (_circle = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 15,
    cy: 15,
    r: 14.5,
    stroke: "#F35151"
  })), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M15 29c7.732 0 14-6.268 14-14S22.732 1 15 1 1 7.268 1 15s6.268 14 14 14Zm-.101-24.814h4.636l-3.292 8.372h3.292L11.27 26.162l3.09-11.119h-3.896l4.434-10.857Z",
    fill: "#fff"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgLightningInsideCircleTransp);

/***/ }),

/***/ 2483:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _AnyPage_Tabs_Tabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7679);
/* harmony import */ var _AccountTabsData_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9737);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7922);
/* harmony import */ var _components_Account_useAccount__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2531);
/* harmony import */ var _components_Account_AccountSearch_AccountSearch__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5639);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_AnyPage_Tabs_Tabs__WEBPACK_IMPORTED_MODULE_2__, _components_Account_AccountSearch_AccountSearch__WEBPACK_IMPORTED_MODULE_6__]);
([_AnyPage_Tabs_Tabs__WEBPACK_IMPORTED_MODULE_2__, _components_Account_AccountSearch_AccountSearch__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const AccountPage = ({ renderTabs =true , children , allWaitPage =false  })=>{
    const { isAdmin , adminSwitchIdToUser , adminSwitchUserModel ,  } = (0,_components_Account_useAccount__WEBPACK_IMPORTED_MODULE_5__/* .useAccount */ .m)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AccountWrapperUI, {
        children: [
            isAdmin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SearchContainerMUI, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Account_AccountSearch_AccountSearch__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
            }),
            !!(isAdmin && (adminSwitchIdToUser && adminSwitchUserModel || allWaitPage)) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    renderTabs && (allWaitPage ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AnyPage_Tabs_Tabs__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        data: _AccountTabsData_json__WEBPACK_IMPORTED_MODULE_3__
                    })),
                    children
                ]
            }),
            !isAdmin && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    renderTabs && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AnyPage_Tabs_Tabs__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        data: _AccountTabsData_json__WEBPACK_IMPORTED_MODULE_3__
                    }),
                    children
                ]
            })
        ]
    }));
};
const { AccountWrapperUI , SearchContainerMUI ,  } = (0,_style__WEBPACK_IMPORTED_MODULE_4__/* .useAccountPageStyle */ .y)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(AccountPage));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5639:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _components_AnyPage_CategorySearch_CategorySearch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(35);
/* harmony import */ var _components_Account_AccountSearch_useAccountSearch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4376);
/* harmony import */ var _components_Account_AccountSearch_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4662);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _components_AnyPage_CategorySearch_CategorySearch__WEBPACK_IMPORTED_MODULE_3__, _components_Account_AccountSearch_useAccountSearch__WEBPACK_IMPORTED_MODULE_4__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _components_AnyPage_CategorySearch_CategorySearch__WEBPACK_IMPORTED_MODULE_3__, _components_Account_AccountSearch_useAccountSearch__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const AccountSearch = ()=>{
    const { hints , methods , onSubmit , handleChangeInputValue , handleClearInputValue  } = (0,_components_Account_AccountSearch_useAccountSearch__WEBPACK_IMPORTED_MODULE_4__/* .useAccountSearch */ .C)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.FormProvider, {
        ...methods,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SearchContainerMUI, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_CategorySearch_CategorySearch__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                component: "account",
                handleKeyDownEnter: ()=>handleClearInputValue()
                ,
                searchHints: hints,
                onSubmit: onSubmit,
                handleChangeSearchValue: handleChangeInputValue
            })
        })
    }));
};
const { SearchContainerMUI  } = (0,_components_Account_AccountSearch_style__WEBPACK_IMPORTED_MODULE_5__/* .useAccountSearchStyles */ .o)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(AccountSearch));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4662:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ useAccountSearchStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useAccountSearchStyles = ()=>{
    const SearchContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            maxWidth: '976px',
            margin: '0 auto 42px',
            [theme.breakpoints.down(600)]: {
                margin: '0px 0 20px 0'
            }
        })
    );
    return {
        SearchContainerMUI
    };
};


/***/ }),

/***/ 4376:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ useAccountSearch)
/* harmony export */ });
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5641);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4730);
/* harmony import */ var _reducers_adminSlice_asyncThunk_adminApi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5907);
/* harmony import */ var _reducers_adminSlice_adminSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7496);
/* harmony import */ var _reducers_orderWaitSlice_orderWaitSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9238);
/* harmony import */ var _hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4763);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _reducers_orderStockSlice_orderStockSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6448);
/* harmony import */ var _reducers_orderSendSlice_orderSendSlice__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4216);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_0__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const useAccountSearch = ()=>{
    const { hints , adminSwitchUserModel , adminSwitchIdToUser ,  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .C)((state)=>state.adminReducer
    );
    const { router  } = (0,_hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_5__/* .useCustomRouter */ .c)();
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppDispatch */ .T)();
    const methods = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_0__.useForm)();
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (adminSwitchUserModel) {
            const search = methods.getValues('search');
            if (search !== adminSwitchUserModel.email) {
                methods.setValue('search', adminSwitchUserModel.email);
            }
        }
    }, [
        adminSwitchUserModel
    ]);
    const onSubmit = async (data)=>{
        if (Array.isArray(hints)) {
            const innerData = data;
            const item = hints[innerData.suggestionIndex - 1];
            if ((item === null || item === void 0 ? void 0 : item.id) && (item === null || item === void 0 ? void 0 : item.id) !== adminSwitchIdToUser) {
                await dispatch(_reducers_adminSlice_adminSlice__WEBPACK_IMPORTED_MODULE_3__/* .adminSlice.actions.changeAdminId */ .X9.actions.changeAdminId(item.id));
                await dispatch(_reducers_orderStockSlice_orderStockSlice__WEBPACK_IMPORTED_MODULE_7__/* .orderStockSlice.actions.resetSlice */ .x.actions.resetSlice());
                await dispatch(_reducers_orderWaitSlice_orderWaitSlice__WEBPACK_IMPORTED_MODULE_4__/* .orderWaitSlice.actions.defaultData */ .r.actions.defaultData());
                await dispatch(_reducers_orderSendSlice_orderSendSlice__WEBPACK_IMPORTED_MODULE_8__/* .orderSendSlice.actions.resetSlice */ .m.actions.resetSlice());
                const allWaitPage = router.pathname.match('all-wait');
                if (!allWaitPage) {
                    router.push(router.pathname, {
                        query: {
                            userId: item.id
                        }
                    });
                } else {
                    router.push(`/account/orders/wait?userId=${item.id}`);
                }
            }
        }
    };
    const handleChangeInputValue = (text)=>{
        dispatch((0,_reducers_adminSlice_asyncThunk_adminApi__WEBPACK_IMPORTED_MODULE_2__/* .fetchUsersInAdmin */ .s)({
            text
        }));
    };
    const handleClearInputValue = ()=>{
        dispatch(_reducers_adminSlice_adminSlice__WEBPACK_IMPORTED_MODULE_3__/* .adminSlice.actions.clearAdminHints */ .X9.actions.clearAdminHints());
    };
    return {
        hints,
        methods,
        onSubmit,
        handleChangeInputValue,
        handleClearInputValue
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3676:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AccountTabOrderMobile_AccountTabOrderMobile)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/Account/AccountTabOrderMobile/style.ts

const useAccountTabOrderMobileStyles = ()=>{
    const ContainerMUI = (0,material_.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            position: 'relative'
        })
    );
    const TextMUI = (0,material_.styled)('button', {
        shouldForwardProp: (prop)=>prop !== 'active'
    })(({ active , theme  })=>({
            fontSize: '24px',
            border: 0,
            lineHeight: '28px',
            color: '#000000',
            fontWeight: active ? 400 : 300,
            backgroundColor: 'transparent',
            cursor: 'pointer',
            margin: '0 !important',
            [theme.breakpoints.down(500)]: {
                fontSize: '16px',
                lineHeight: '19px'
            }
        })
    );
    const DropDownWrapperMUI = (0,material_.styled)('div')(()=>({
            '& > div': {
                '& > button': {
                    padding: 0,
                    margin: '0 0 0 5px !important'
                },
                '& > div': {
                    '& > button': {
                        margin: '0 !important'
                    }
                }
            }
        })
    );
    return {
        TextMUI,
        ContainerMUI,
        DropDownWrapperMUI
    };
};

// EXTERNAL MODULE: ./src/UI/UIComponents/DropDownUI/DropDownUI.tsx + 6 modules
var DropDownUI = __webpack_require__(1211);
// EXTERNAL MODULE: ./src/hooks/useCustomRouter.ts
var useCustomRouter = __webpack_require__(4763);
// EXTERNAL MODULE: ./src/hooks/useUserStore.ts
var useUserStore = __webpack_require__(257);
// EXTERNAL MODULE: ./src/hooks/useReduxHooks.ts
var useReduxHooks = __webpack_require__(4730);
;// CONCATENATED MODULE: ./src/components/Account/AccountTabOrderMobile/AccountTabOrderMobile.tsx







const AccountTabOrderMobile = ({ active =false  })=>{
    const { router ,  } = (0,useCustomRouter/* useCustomRouter */.c)();
    const { isAdmin  } = (0,useUserStore/* useUserStore */.L)();
    const { adminSwitchIdToUser  } = (0,useReduxHooks/* useAppSelector */.C)((state)=>state.adminReducer
    );
    const { 0: dropDownOpen , 1: setDropDownOpen  } = (0,external_react_.useState)(false);
    const handlePush = (url)=>{
        const query = isAdmin ? `?userId=${adminSwitchIdToUser}` : '';
        router.push(`${url}${query}`);
    };
    const dropItems = [
        {
            title: 'Ожидаемые',
            onClick: ()=>handlePush('/account/orders/wait')
        },
        {
            title: 'На складе',
            onClick: ()=>handlePush('/account/orders/stock')
        },
        {
            title: 'Отправленые',
            onClick: ()=>handlePush('/account/orders/send')
        },
        {
            title: '+ Добавить',
            onClick: ()=>handlePush('/account/orders/add')
        }, 
    ];
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ContainerMUI, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(TextMUI, {
                active: active,
                onClick: ()=>setDropDownOpen(true)
                ,
                children: "Заказы"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(DropDownWrapperMUI, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(DropDownUI/* default */.Z, {
                    itemId: 0,
                    externalOpen: dropDownOpen,
                    setExternalOpen: setDropDownOpen,
                    dropItems: dropItems
                })
            })
        ]
    }));
};
const { TextMUI , ContainerMUI , DropDownWrapperMUI ,  } = useAccountTabOrderMobileStyles();
/* harmony default export */ const AccountTabOrderMobile_AccountTabOrderMobile = (/*#__PURE__*/external_react_default().memo(AccountTabOrderMobile));


/***/ }),

/***/ 7922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ useAccountPageStyle)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useAccountPageStyle = ()=>{
    const AccountWrapperUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            width: '100%',
            height: '100%',
            margin: '120px 0px 0px',
            '& .TabsUnstyled-root': {
                width: '100%'
            },
            '& .TabsListUnstyled-root button': {
                margin: '0 27.5px',
                flexWrap: 'wrap'
            },
            [theme.breakpoints.down(750)]: {
                marginTop: '80px',
                '& .TabsUnstyled-root': {
                    width: '100%'
                },
                '& .TabsListUnstyled-root': {
                    justifyContent: 'space-evenly',
                    minWidth: '0'
                },
                '& .TabsListUnstyled-root button': {
                    margin: '0 10px 0 0'
                }
            }
        })
    );
    const SearchContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            maxWidth: '976px',
            margin: '0 auto',
            height: '100%'
        })
    );
    return {
        AccountWrapperUI,
        SearchContainerMUI
    };
};


/***/ }),

/***/ 2531:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ useAccount)
/* harmony export */ });
/* harmony import */ var _hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4763);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(257);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4730);
/* harmony import */ var _reducers_adminSlice_adminSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7496);
/* harmony import */ var _reducers_orderWaitSlice_orderWaitSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9238);
/* harmony import */ var _services_services__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4727);
/* harmony import */ var _reducers_adminSlice_asyncThunk_adminApi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5907);








const useAccount = ()=>{
    const { router  } = (0,_hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_0__/* .useCustomRouter */ .c)();
    const { getUser , isAdmin ,  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_1__/* .useUserStore */ .L)();
    const { adminSwitchIdToUser , adminSwitchUserModel ,  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_3__/* .useAppSelector */ .C)((state)=>state.adminReducer
    );
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_3__/* .useAppDispatch */ .T)();
    // // TODO: исправить - пока что захардкожено
    // useEffect(() => {
    // 	if(router.asPath.includes('info') && !router.asPath.includes('location')) {
    // 		pushTo(router.asPath, {location: 'ger'});
    // 	}
    // }, [router.asPath]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (isAdmin) {
            const data = {
                userId: router.query.userId ? router.query.userId : (0,_services_services__WEBPACK_IMPORTED_MODULE_7__/* .getLocationWindow */ .I5)('userId='),
                email: router.query.email
            };
            if ((data === null || data === void 0 ? void 0 : data.userId) !== undefined) {
                if (+data.userId === adminSwitchIdToUser) return;
                dispatch(_reducers_adminSlice_adminSlice__WEBPACK_IMPORTED_MODULE_4__/* .adminSlice.actions.changeAdminId */ .X9.actions.changeAdminId(+data.userId));
                dispatch(_reducers_orderWaitSlice_orderWaitSlice__WEBPACK_IMPORTED_MODULE_5__/* .orderWaitSlice.actions.defaultData */ .r.actions.defaultData());
            }
        }
    }, [
        router,
        isAdmin
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (adminSwitchIdToUser) {
            dispatch((0,_reducers_adminSlice_asyncThunk_adminApi__WEBPACK_IMPORTED_MODULE_6__/* .fetchUserAdmin */ .M)({
                userId: adminSwitchIdToUser
            }));
        }
    }, [
        adminSwitchIdToUser
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        getUser();
    }, []);
    return {
        isAdmin,
        adminSwitchIdToUser,
        adminSwitchUserModel
    };
};


/***/ }),

/***/ 7679:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_base_Tabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(888);
/* harmony import */ var _mui_base_Tabs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_base_Tabs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_services__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4727);
/* harmony import */ var _hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4763);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(588);
/* harmony import */ var _hooks_useMedia__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2447);
/* harmony import */ var _UI_UIIcon_LightningInsideCircleTransp_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5475);
/* harmony import */ var _components_Account_AccountTabOrderMobile_AccountTabOrderMobile__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3676);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(257);
/* harmony import */ var _components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(239);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_10__]);
_components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// import Link from 'next/link';




// import LightningInsideCircle from '../../../UI/UIIcon/LightningInsideCircle.svg';




// import EuroExchange from '../EuroExchange/EuroExchange';

const Tabs = ({ data  })=>{
    const { isMobile  } = (0,_hooks_useMedia__WEBPACK_IMPORTED_MODULE_5__/* .useMobile */ .XA)();
    const isTouchDevice = (0,_mui_material__WEBPACK_IMPORTED_MODULE_8__.useMediaQuery)('(max-width: 1024px)');
    const { isAdmin , adminSwitchIdToUser ,  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_9__/* .useUserStore */ .L)();
    const { router , pushTo  } = (0,_hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_3__/* .useCustomRouter */ .c)();
    const handlerPushToTab = (url)=>{
        let urlTo = router.pathname;
        if (url) urlTo = `/account/${url}`;
        if (!isAdmin) {
            pushTo(urlTo);
        } else {
            // const pathname = router.asPath;
            // const userId = pathname?.split('userId=')[1]?.split('&')[0];
            pushTo(urlTo, {
                userId: adminSwitchIdToUser
            });
        }
    };
    const checkActiveClass = (url, query, baseUrl = '')=>{
        const location = (0,_services_services__WEBPACK_IMPORTED_MODULE_11__/* .ObjectHasOwnProperty */ .W7)(query, 'location') ? query.location : '';
        if (url) {
            if (router.asPath.includes(url)) {
                // return 'Mui-selected';
                return true;
            }
            if (baseUrl && router.asPath.includes(baseUrl)) return true;
        }
        if (location) {
            var ref;
            if ((router === null || router === void 0 ? void 0 : (ref = router.query) === null || ref === void 0 ? void 0 : ref.location) === location) {
                // return 'Mui-selected';
                return true;
            }
        }
        return false;
    };
    const checkShowingTab = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((flag)=>{
        return isMobile ? isMobile && flag : true;
    }, [
        isMobile
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TabWrapperUI, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_base_Tabs__WEBPACK_IMPORTED_MODULE_2___default()), {
            className: "TabsUnstyled-root TabsUnstyled-horizontal",
            defaultValue: router.asPath,
            children: [
                isMobile ? isAdmin ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}) : null,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TabsListUI, {
                    className: "TabsListUnstyled-root TabsListUnstyled-horizontal",
                    children: [
                        isMobile ? null : isAdmin ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
                        data.map((item)=>{
                            /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
                                children: checkShowingTab(item.showMobile) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TabUI, {
                                    // key={i}
                                    active: checkActiveClass(item.url, item.query, item === null || item === void 0 ? void 0 : item.baseUrl),
                                    onClick: ()=>{
                                        if (item.title === 'Заказы' && isTouchDevice) return;
                                        handlerPushToTab(item.url);
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: item.title === 'Заказы' && isTouchDevice ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Account_AccountTabOrderMobile_AccountTabOrderMobile__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                            active: checkActiveClass(item.url, item.query, item === null || item === void 0 ? void 0 : item.baseUrl)
                                        }) : item.title == 'Выкуп товара' && isAdmin ? null : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                item.title,
                                                item.title === 'Выкуп товара' ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TabsMarginLeft, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BgMUI, {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIIcon_LightningInsideCircleTransp_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                                                    })
                                                }) : ''
                                            ]
                                        })
                                    })
                                }) : null
                            }, item.title);
                        })
                    ]
                })
            ]
        })
    }));
};
const { TabWrapperUI , TabUI , TabsListUI , TabsMarginLeft , BgMUI ,  } = (0,_style__WEBPACK_IMPORTED_MODULE_4__/* .useTabsStyle */ .P)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(Tabs));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 588:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ useTabsStyle)
/* harmony export */ });
/* harmony import */ var _mui_base_TabsList__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9465);
/* harmony import */ var _mui_base_TabsList__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_base_TabsList__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);



const useTabsStyle = ()=>{
    const AnimationName = _mui_system__WEBPACK_IMPORTED_MODULE_2__.keyframes`
	 	
		 0%{background-position:0% 50%}
		 100%{background-position:100% 50%}
	
		 `;
    const BgMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)('div')(({ theme  })=>({
            position: 'relative',
            width: 30,
            height: 30,
            borderRadius: 50,
            animation: `${AnimationName} 2s linear infinite`,
            background: 'linear-gradient(210deg, #F35151 0%, #F35151 45%, #FFCD 50%, #F35151 55%, #F35151 100% )',
            backgroundSize: '1000% 100%',
            [theme.breakpoints.down(600)]: {
                width: 20,
                height: 20,
                marginBottom: '5px'
            }
        })
    );
    const TabWrapperUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)('div')(()=>({
            width: '100%',
            display: 'flex',
            justifyContent: 'center'
        })
    );
    const TabUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)('div', {
        shouldForwardProp: (prop)=>prop !== 'active'
    })(({ active , theme  })=>({
            fontStyle: 'normal',
            fontWeight: active ? '400' : '300',
            fontSize: '24px',
            lineHeight: '28px',
            alignItems: 'center',
            color: '#000000',
            // backgroundColor: '#fff',
            backgroundColor: 'transparent',
            cursor: 'pointer',
            border: 'none',
            width: 'auto',
            margin: '0 27.5px',
            padding: '5px 0px 0px',
            display: 'flex',
            justifyContent: 'center',
            fontFamily: 'Roboto',
            // '&.Mui-selected': {
            // 	// fontWeight: '400',
            //
            // 	[theme.breakpoints.down(781)]: {
            // 		fontFamily: 'Roboto',
            // 		fontSize: '20px',
            // 		lineHeight: '21px',
            // 	},
            // 	[theme.breakpoints.down(404)]: {
            // 		fontFamily: 'Roboto',
            // 		fontSize: '16px',
            // 		lineHeight: '19px',
            // 	},
            // },
            [theme.breakpoints.down(870)]: {
                margin: '0 10px !important'
            },
            [theme.breakpoints.down(781)]: {
                fontSize: '20px',
                lineHeight: '21px'
            },
            [theme.breakpoints.down(500)]: {
                fontSize: '16px',
                lineHeight: '19px',
                margin: '0 4px !important'
            },
            [theme.breakpoints.down(370)]: {
                fontSize: '14px'
            }
        })
    );
    const TabsListUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)((_mui_base_TabsList__WEBPACK_IMPORTED_MODULE_0___default()))(({ theme  })=>({
            minWidth: '320px',
            paddingBottom: '5px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            alignContent: 'space-between',
            borderBottom: '2px solid #C4C4C4',
            [theme.breakpoints.down(800)]: {
                flexWrap: 'wrap',
                borderBottom: '1px solid #C4C4C4',
                minWidth: '0px'
            }
        })
    );
    const TabsMarginLeft = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)((_mui_base_TabsList__WEBPACK_IMPORTED_MODULE_0___default()))(()=>({
            margin: '0px 0px -6px 6px',
            alignItems: 'baseline'
        })
    );
    const TabLineMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)('div')(()=>({
            width: '100%',
            display: 'flex',
            justifyContent: 'center'
        })
    );
    return {
        TabWrapperUI,
        TabUI,
        TabsListUI,
        TabsMarginLeft,
        BgMUI,
        TabLineMUI
    };
};


/***/ }),

/***/ 9737:
/***/ ((module) => {

module.exports = JSON.parse('[{"title":"Личные данные","url":"info","query":{},"showMobile":true},{"title":"Заказы","url":"orders/wait","baseUrl":"orders","query":{},"showMobile":true},{"title":"Выкуп товара","url":"instruction","query":{},"showMobile":true}]');

/***/ })

};
;