"use strict";
exports.id = 528;
exports.ids = [528];
exports.modules = {

/***/ 829:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Bt": () => (/* binding */ fetchReviews),
/* harmony export */   "_r": () => (/* binding */ fetchAddReviews),
/* harmony export */   "mP": () => (/* binding */ fetchAddReviewsMobile),
/* harmony export */   "rG": () => (/* binding */ fetchMoreReviews),
/* harmony export */   "Ig": () => (/* binding */ fetchDeleteReview)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7355);
/* harmony import */ var _reviewsSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7541);




const fetchReviews = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('reviews/get', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_2__/* .octoAxios.get */ .N.get('/reviews', {
            params: data
        });
        return response.data;
    } catch (e) {
        if (axios__WEBPACK_IMPORTED_MODULE_1___default().isAxiosError(e)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = e.response) === null || ref === void 0 ? void 0 : ref.status);
        }
    }
});
const fetchAddReviews = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('reviews/add_review', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_2__/* .octoAxios.post */ .N.post('/add_review', data);
        return response.data;
    } catch (e) {
        if (axios__WEBPACK_IMPORTED_MODULE_1___default().isAxiosError(e)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = e.response) === null || ref === void 0 ? void 0 : ref.status);
        }
    }
});
const fetchAddReviewsMobile = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('reviews/add_review_mobile', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_2__/* .octoAxios.post */ .N.post('/add_review', data);
        if (response.data.message === 'success') {
            return {
                createdTime: new Date().toString(),
                id: data.userId,
                text: data.text,
                userName: data.userName
            };
        }
    } catch (e) {
        if (axios__WEBPACK_IMPORTED_MODULE_1___default().isAxiosError(e)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = e.response) === null || ref === void 0 ? void 0 : ref.status);
        }
    }
});
const fetchMoreReviews = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('reviews/getMobile', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_2__/* .octoAxios.get */ .N.get('/reviews', {
            params: data
        });
        return {
            reviews: response.data.reviews,
            reviewsEnd: !(response.data.reviews.length === data.page_limit)
        };
    } catch (e) {
        if (axios__WEBPACK_IMPORTED_MODULE_1___default().isAxiosError(e)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = e.response) === null || ref === void 0 ? void 0 : ref.status);
        }
    }
});
const fetchDeleteReview = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('reviews/delete', async (data, { dispatch , rejectWithValue  })=>{
    try {
        const res = await _lib_http__WEBPACK_IMPORTED_MODULE_2__/* .octoAxios["delete"] */ .N["delete"]('/admin/review', {
            data: {
                reviewId: data.id
            }
        });
        if (res.status === 200) {
            dispatch((0,_reviewsSlice__WEBPACK_IMPORTED_MODULE_3__/* .deleteReview */ .i0)(data.id));
        }
        throw new Error('Не удалось удалить удалить отзыв');
    // return data.id;
    } catch (e) {
        return rejectWithValue('ошибка удаления отзыва');
    }
});


/***/ }),

/***/ 7541:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NW": () => (/* binding */ reviewsSlice),
/* harmony export */   "tF": () => (/* binding */ reviewsReset),
/* harmony export */   "D4": () => (/* binding */ setCurrentPage),
/* harmony export */   "i0": () => (/* binding */ deleteReview),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_reviewsSlice_asyncActions_reviewsApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(829);


const initialState = {
    reviews: [],
    pagesGet: 1,
    pagesCount: 1,
    pagesCountFront: 1,
    limitShow: 6,
    currentPage: 1,
    updateReviews: false,
    reviewsEnd: false,
    isNewReviewsMobile: false
};
const reviewsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'reviews',
    initialState,
    reducers: {
        setCurrentPage: (state, action)=>{
            state.currentPage = action.payload;
        },
        reviewsReset: (state)=>{
            state.reviews = [];
            state.pagesGet = 1;
            state.pagesCount = 1;
            state.pagesCountFront = 1;
            state.limitShow = 6;
            state.currentPage = 1;
        },
        updateReviews: (state)=>{
            state.updateReviews = true;
        },
        changeNewReviewsMobile: (state)=>{
            state.isNewReviewsMobile = false;
        },
        deleteReview: (state, action)=>{
            state.reviews = state.reviews.filter((item)=>{
                return item.id !== action.payload;
            });
        }
    },
    extraReducers: {
        [_reducers_reviewsSlice_asyncActions_reviewsApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchReviews.fulfilled.type */ .Bt.fulfilled.type]: (state, data)=>{
            if (state.pagesGet) {
                if (data.payload.pages_count) {
                    state.pagesCount = data.payload.pages_count;
                    state.pagesCountFront = data.payload.pages_count;
                    if (data.payload.reviews.length === 6) state.pagesGet += 1;
                }
            }
            state.reviews = [
                ...data.payload.reviews
            ];
        },
        [_reducers_reviewsSlice_asyncActions_reviewsApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchMoreReviews.fulfilled.type */ .rG.fulfilled.type]: (state, data)=>{
            state.currentPage += 1;
            state.reviews = [
                ...state.reviews,
                ...data.payload.reviews
            ];
            state.updateReviews = false;
            state.reviewsEnd = data.payload.reviewsEnd;
            state.isNewReviewsMobile = false;
        },
        [_reducers_reviewsSlice_asyncActions_reviewsApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchAddReviewsMobile.fulfilled.type */ .mP.fulfilled.type]: (state, data)=>{
            state.updateReviews = false;
            state.isNewReviewsMobile = true;
            state.reviews = [
                data.payload,
                ...state.reviews
            ];
        }
    }
});
const { reviewsReset , setCurrentPage , deleteReview  } = reviewsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (reviewsSlice.reducer);


/***/ })

};
;