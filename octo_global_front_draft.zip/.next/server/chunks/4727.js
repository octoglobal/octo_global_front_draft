"use strict";
exports.id = 4727;
exports.ids = [4727];
exports.modules = {

/***/ 4727:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "wm": () => (/* binding */ checkValidArray),
/* harmony export */   "W7": () => (/* binding */ ObjectHasOwnProperty),
/* harmony export */   "my": () => (/* binding */ getFulfilledInString),
/* harmony export */   "bD": () => (/* binding */ ToDefaultDate),
/* harmony export */   "z$": () => (/* binding */ ToDefaultTime),
/* harmony export */   "ZP": () => (/* binding */ PhoneMask),
/* harmony export */   "zf": () => (/* binding */ ucFirst),
/* harmony export */   "bY": () => (/* binding */ translit),
/* harmony export */   "rF": () => (/* binding */ ToRusDate),
/* harmony export */   "PJ": () => (/* binding */ sortItemArrayInId),
/* harmony export */   "yO": () => (/* binding */ generateAdminHintsData),
/* harmony export */   "I5": () => (/* binding */ getLocationWindow),
/* harmony export */   "$G": () => (/* binding */ getSelectArray),
/* harmony export */   "Xg": () => (/* binding */ findItemInArrayForId),
/* harmony export */   "gw": () => (/* binding */ onScroll),
/* harmony export */   "Q2": () => (/* binding */ WHATSAPP),
/* harmony export */   "mQ": () => (/* binding */ validateUrl)
/* harmony export */ });
/* unused harmony exports summ, isObjectEmpty, checkMedia, ellipsis, addZero */
const checkValidArray = (arr)=>{
    return Array.isArray(arr) && !!(arr === null || arr === void 0 ? void 0 : arr.length);
};
const summ = (a, b)=>a + b
;
const isObjectEmpty = (obj = {})=>{
    return Object.keys(obj).length == 0;
};
const ObjectHasOwnProperty = (object = {}, property)=>{
    return Object.prototype.hasOwnProperty.call(object, property);
};
const getFulfilledInString = (str)=>{
    return str.includes('fulfilled');
};
// export const getTrueItemInObj = (obj = {}) => {
// 	const trueArr = [];
// 	for (const [, value] of Object.entries(obj)) {
// 		if (value) trueArr.push(value);
// 	}
// 	return trueArr;
// };
function ToDefaultDate(date) {
    const adDate = new Date(date), options = {
        month: 'numeric',
        day: 'numeric',
        year: 'numeric'
    };
    const dateArray = adDate.toLocaleString('ru', options).split('.');
    const day = dateArray[0];
    const mount = dateArray[1];
    const year = dateArray[2].substring(2);
    return `${day}.${mount}.${year}`;
}
function ToDefaultTime(date) {
    const adDate = new Date(date), options = {
        hour: 'numeric',
        minute: 'numeric'
    };
    return adDate.toLocaleString('ru', options);
}
//
// export function formatDate(date) {
// 	return date.getFullYear() + '/' +
// 		(date.getMonth() + 1) + '/' +
// 		date.getDate() + ' ' +
// 		date.getHours() + ':' +
// 		date.getMinutes();
// }
function PhoneMask(e, value, setValue) {
    let inputOnlyNumber = e.target.value.replace(/\D/g, '');
    let formattedInputValue = '';
    if (!inputOnlyNumber) {
        setValue('');
        return;
    }
    if (inputOnlyNumber[0] === '9') inputOnlyNumber = '7' + inputOnlyNumber;
    formattedInputValue = '+7 ';
    if (inputOnlyNumber.length > 1) {
        formattedInputValue += '(' + inputOnlyNumber.substring(1, 4);
    }
    if (inputOnlyNumber.length >= 5) {
        formattedInputValue += ') ' + inputOnlyNumber.substring(4, 7);
    }
    if (inputOnlyNumber.length >= 8) {
        formattedInputValue += '-' + inputOnlyNumber.substring(7, 9);
    }
    if (inputOnlyNumber.length >= 10) {
        formattedInputValue += '-' + inputOnlyNumber.substring(9, 11);
    }
    if (e.target.value.length >= 0 && e.target.value.length <= 18) {
        setValue(formattedInputValue);
    }
    return inputOnlyNumber;
};
const ucFirst = (str)=>{
    if (!str) return str;
    return str[0].toUpperCase() + str.slice(1);
};
const translit = (word)=>{
    const converter = {
        'а': 'a',
        'б': 'b',
        'в': 'v',
        'г': 'g',
        'д': 'd',
        'е': 'e',
        'ё': 'e',
        'ж': 'zh',
        'з': 'z',
        'и': 'i',
        'й': 'y',
        'к': 'k',
        'л': 'l',
        'м': 'm',
        'н': 'n',
        'о': 'o',
        'п': 'p',
        'р': 'r',
        'с': 's',
        'т': 't',
        'у': 'u',
        'ф': 'f',
        'х': 'h',
        'ц': 'c',
        'ч': 'ch',
        'ш': 'sh',
        'щ': 'sch',
        'ь': '',
        'ы': 'y',
        'ъ': '',
        'э': 'e',
        'ю': 'yu',
        'я': 'ya'
    };
    word = word.toLowerCase();
    let answer = '';
    for(let i = 0; i < word.length; ++i){
        if (converter[word[i]] == undefined) {
            answer += word[i];
        } else {
            answer += converter[word[i]];
        }
    }
    answer = answer.replace(/[^-0-9a-z]/g, '-');
    answer = answer.replace(/[-]+/g, '-');
    answer = answer.replace(/^\\-|-$/g, '');
    return ucFirst(answer);
};
const checkMedia = (screen, type = 'innerWidth')=>{
    if (false) {}
    return false;
};
const ellipsis = (string, count)=>{
    if ((string === null || string === void 0 ? void 0 : string.length) > count) {
        return `${string.substr(0, count - 1)}..`;
    } else {
        return string;
    }
};
const addZero = (n)=>{
    if (n < 10) {
        return `0${n}`;
    } else {
        return n;
    }
};
const MonthArray = [
    'Января',
    'Февраля',
    'Марта',
    'Апреля',
    'Мая',
    'Июня',
    'Июля',
    'Августа',
    'Сентября',
    'Ноября',
    'Декабря', 
];
const ToRusDate = (date)=>{
    const expaireData = new Date(date);
    const time = expaireData.getTime();
    const grinvic = new Date(time);
    // const diff = grinvic.getTimezoneOffset();
    // const local = new Date(time - (diff * 60 * 1000));
    // const options = {
    // 	month: 'long',
    // };
    const h = addZero(grinvic.getHours());
    const mi = addZero(grinvic.getMinutes());
    const d = addZero(grinvic.getDate());
    const m = grinvic.getMonth();
    const y = grinvic.getFullYear();
    // const month = local.toLocaleString('ru', options);
    const month = MonthArray[m];
    // const wordEnd = wordAutoEnding(month, )
    const timeLocal = `${h}:${mi}`;
    const dateLocal = `${d} ${month} ${y}`;
    return `${timeLocal} ${dateLocal}`;
};
const sortItemArrayInId = (array, arrayId)=>{
    let filterArray = array;
    for(let i = 0; i < arrayId.length; i++){
        filterArray = filterArray.filter((item)=>item.id !== arrayId[i]
        );
    }
    return filterArray;
};
const generateAdminHintsData = (data)=>{
    const modificationArray = [];
    for (const [, value] of Object.entries(data)){
        value.forEach((item1, index)=>{
            const innerObj = {
                userAreaId: null,
                email: null,
                orderNumber: null,
                trackNumber: null,
                name: '',
                type: null,
                url: '',
                title: 'test',
                id: null
            };
            const type = (item1 === null || item1 === void 0 ? void 0 : item1.trackNumber) || (item1 === null || item1 === void 0 ? void 0 : item1.trackNumber) ? 'order' : 'user';
            if (type == 'order') {
                innerObj.userAreaId = item1 === null || item1 === void 0 ? void 0 : item1.userAreaId;
                innerObj.name = item1 === null || item1 === void 0 ? void 0 : item1.userName;
                innerObj.email = item1 === null || item1 === void 0 ? void 0 : item1.userEmail;
                innerObj.id = item1.userId;
                innerObj.orderNumber = item1 === null || item1 === void 0 ? void 0 : item1.longId;
                innerObj.trackNumber = item1 === null || item1 === void 0 ? void 0 : item1.trackNumber;
                innerObj.title = item1.userEmail;
                innerObj.url = `${item1 === null || item1 === void 0 ? void 0 : item1.userEmail}${item1 === null || item1 === void 0 ? void 0 : item1.userName}${item1 === null || item1 === void 0 ? void 0 : item1.userAreaId}${item1.trackNumber}${item1.longId}`;
            }
            if (type == 'user') {
                innerObj.userAreaId = item1 === null || item1 === void 0 ? void 0 : item1.personalAreaId;
                innerObj.name = item1 === null || item1 === void 0 ? void 0 : item1.name;
                innerObj.email = item1 === null || item1 === void 0 ? void 0 : item1.email;
                innerObj.orderNumber = null;
                innerObj.id = item1.id;
                innerObj.trackNumber = null;
                innerObj.title = item1.email;
                innerObj.url = `${item1 === null || item1 === void 0 ? void 0 : item1.email}${item1 === null || item1 === void 0 ? void 0 : item1.name}${item1 === null || item1 === void 0 ? void 0 : item1.personalAreaId}${index}`;
            }
            innerObj.type = type;
            const findItem = modificationArray.find((item)=>item.id == innerObj.id
            );
            if (!findItem) {
                modificationArray.push(innerObj);
            }
        });
    }
    return modificationArray.splice(0, 5);
};
const getLocationWindow = (search)=>{
    if (true) {
        var ref, ref1;
        return (ref1 = (ref = window.location.search) === null || ref === void 0 ? void 0 : ref.split(search)[1]) === null || ref1 === void 0 ? void 0 : ref1.split('&')[0].replace('%40', '@');
    }
};
const getSelectArray = (obj)=>{
    const trueArray = [];
    for (const [key, value] of Object.entries(obj)){
        if (value) trueArray.push(+key);
    }
    return trueArray;
};
const findItemInArrayForId = (array, arrayId)=>{
    const innerArray = [];
    if (Array.isArray(array)) {
        for(let i = 0; i < arrayId.length; i++){
            const findItem = array.find((item)=>item.id == arrayId[i]
            );
            if (findItem) {
                innerArray.push(findItem);
            }
        }
    }
    return innerArray;
};
const onScroll = (event, callback)=>{
    const window = event.currentTarget;
    if (window) {
        const bodyHeight = document.body.offsetHeight / 100 * 70;
        const offsetTop = window.scrollY + window.innerHeight;
        if (offsetTop > bodyHeight) {
            callback();
        }
    }
};
const WHATSAPP = (phone)=>`https://api.whatsapp.com/send?phone=${phone}&text=Здравствуйте!`
;
const validateUrl = (value)=>{
    return /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i.test(value);
};


/***/ })

};
;