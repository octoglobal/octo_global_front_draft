"use strict";
exports.id = 2655;
exports.ids = [2655];
exports.modules = {

/***/ 2655:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ useSwipeableDrawerStore)
/* harmony export */ });
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4730);
/* harmony import */ var _store_reducers_swipeableDrawerSlice_swipeableDrawerSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4359);


const useSwipeableDrawerStore = ()=>{
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppDispatch */ .T)();
    const { open , openTab  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppSelector */ .C)((state)=>state.swipeableDrawerSliceReducer
    );
    const toggleSwipeableDrawer = (state)=>{
        dispatch((0,_store_reducers_swipeableDrawerSlice_swipeableDrawerSlice__WEBPACK_IMPORTED_MODULE_1__/* .toggleDrawer */ .wb)(state));
    };
    const toggleTabSwipeableDrawer = (state)=>{
        dispatch((0,_store_reducers_swipeableDrawerSlice_swipeableDrawerSlice__WEBPACK_IMPORTED_MODULE_1__/* .toggleTab */ .SM)(state));
    };
    return {
        open,
        openTab,
        toggleDrawer: toggleSwipeableDrawer,
        toggleTab: toggleTabSwipeableDrawer
    };
};


/***/ }),

/***/ 4359:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "wb": () => (/* binding */ toggleDrawer),
/* harmony export */   "SM": () => (/* binding */ toggleTab),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export swipeableDrawerSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    open: false,
    openTab: ''
};
const swipeableDrawerSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'swipebleableDrawer',
    initialState,
    reducers: {
        toggleDrawer: (state, action)=>{
            if (action.payload) {
                state.open = action.payload;
            } else {
                state.open = !state.open;
            }
        },
        toggleTab: (state, action)=>{
            state.openTab = action.payload;
        }
    }
});
const { toggleDrawer , toggleTab  } = swipeableDrawerSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (swipeableDrawerSlice.reducer);


/***/ })

};
;