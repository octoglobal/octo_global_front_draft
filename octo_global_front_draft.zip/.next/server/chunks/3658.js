"use strict";
exports.id = 3658;
exports.ids = [3658];
exports.modules = {

/***/ 4730:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ useAppDispatch),
/* harmony export */   "C": () => (/* binding */ useAppSelector)
/* harmony export */ });
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);

const useAppDispatch = ()=>(0,react_redux__WEBPACK_IMPORTED_MODULE_0__.useDispatch)()
;
const useAppSelector = react_redux__WEBPACK_IMPORTED_MODULE_0__.useSelector;


/***/ }),

/***/ 4989:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M5": () => (/* binding */ HOST),
/* harmony export */   "ch": () => (/* binding */ SUPPORT_PHONE_RU),
/* harmony export */   "rt": () => (/* binding */ SUPPORT_PHONE_DE)
/* harmony export */ });
/* unused harmony export SECRET_KEY */
const SECRET_KEY = (/* unused pure expression or super */ null && ("qwe"));
const HOST = "https://octo.global/api";
const SUPPORT_PHONE_RU = "+79215780788";
const SUPPORT_PHONE_DE = "+79119595955";


/***/ }),

/***/ 7355:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ octoAxios)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4989);


const octoAxios = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
    withCredentials: true,
    baseURL: _constants_constants__WEBPACK_IMPORTED_MODULE_1__/* .HOST */ .M5
});



/***/ }),

/***/ 6213:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o_": () => (/* binding */ fetchUserRefresh),
/* harmony export */   "as": () => (/* binding */ fetchVerificMessage),
/* harmony export */   "z3": () => (/* binding */ fetchUserRegistration),
/* harmony export */   "rZ": () => (/* binding */ fetchUserLogout),
/* harmony export */   "u3": () => (/* binding */ fetchUserAutoLogin),
/* harmony export */   "zd": () => (/* binding */ fetchUserLogin),
/* harmony export */   "AY": () => (/* binding */ fetchChangeUser),
/* harmony export */   "Y3": () => (/* binding */ fetchChangePassword),
/* harmony export */   "Yp": () => (/* binding */ fetchRecoveryPassword),
/* harmony export */   "mR": () => (/* binding */ fetchRecoveryMessage),
/* harmony export */   "qC": () => (/* binding */ fetchAddAddress),
/* harmony export */   "pG": () => (/* binding */ fetchDeleteAddress),
/* harmony export */   "o8": () => (/* binding */ fetchDeleteAddressAdmin),
/* harmony export */   "bq": () => (/* binding */ fetchAddAddressAdminForUser)
/* harmony export */ });
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7355);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);



const fetchUserRefresh = async ()=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.get */ .N.get('/refresh');
        return response.data;
    } catch (err) {
        if (axios__WEBPACK_IMPORTED_MODULE_2___default().isAxiosError(err)) {
            var ref;
            return (ref = err.response) === null || ref === void 0 ? void 0 : ref.status;
        }
        return 400;
    }
};
const fetchVerificMessage = async ()=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.get */ .N.get('/send_verification_message');
        return response.data;
    } catch (err) {
        if (axios__WEBPACK_IMPORTED_MODULE_2___default().isAxiosError(err)) {
            var ref;
            // throw err;
            return (ref = err.response) === null || ref === void 0 ? void 0 : ref.status;
        }
        return 400;
    }
};
const fetchUserRegistration = async (data)=>{
    return await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.post */ .N.post('/registration', data).then((r)=>r.data.message
    ).catch((e)=>e.response
    );
};
const fetchUserLogout = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)('user/logout', async (__, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.get */ .N.get('/logout');
        return response.data;
    } catch (e) {
        return thunkAPI.rejectWithValue('Ошибка api user/logout');
    }
});
const fetchUserAutoLogin = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)('user/autologin', async (__, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.get */ .N.get('/user');
        return response.data;
    } catch (err) {
        if (axios__WEBPACK_IMPORTED_MODULE_2___default().isAxiosError(err)) {
            var ref;
            return {
                message: thunkAPI.rejectWithValue(`${(ref = err.response) === null || ref === void 0 ? void 0 : ref.status}`)
            };
        }
        return thunkAPI.rejectWithValue('422');
    }
});
const fetchUserLogin = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)('user/login', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.get */ .N.get('/login', {
            headers: {
                'Access-Control-Allow-Origin': '*',
                Authorization: `Basic ${window.btoa(`${data.email}:${data.password}`)}`
            }
        });
        return response.data;
    } catch (err) {
        if (axios__WEBPACK_IMPORTED_MODULE_2___default().isAxiosError(err)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = err.response) === null || ref === void 0 ? void 0 : ref.status);
        }
        return thunkAPI.rejectWithValue(422);
    }
});
const fetchChangeUser = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)('user/change', async (data, thunkAPI)=>{
    try {
        return await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.patch */ .N.patch(data.url, data.data);
    } catch (err) {
        if (axios__WEBPACK_IMPORTED_MODULE_2___default().isAxiosError(err)) {
            return thunkAPI.rejectWithValue(err.response);
        }
        return thunkAPI.rejectWithValue(400);
    }
});
const fetchChangePassword = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)('password/chang', async (data, thunkAPI)=>{
    try {
        if (data.isAdmin) {
            return await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.patch */ .N.patch(data.url, data.data);
        } else {
            return await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.post */ .N.post(data.url, data.data);
        }
    } catch (err) {
        if (axios__WEBPACK_IMPORTED_MODULE_2___default().isAxiosError(err)) {
            return thunkAPI.rejectWithValue(err.response);
        }
        return thunkAPI.rejectWithValue(400);
    }
});
const fetchRecoveryPassword = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)('password/recovery', async (data, thunkAPI)=>{
    try {
        const dataSend = {
            password: data.password
        };
        return await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.post */ .N.post('/password_recovery', dataSend, {
            headers: {
                Authorization: `Bearer ${data.token}`
            }
        });
    } catch (err) {
        if (axios__WEBPACK_IMPORTED_MODULE_2___default().isAxiosError(err)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = err.response) === null || ref === void 0 ? void 0 : ref.status);
        }
        return thunkAPI.rejectWithValue(400);
    }
});
const fetchRecoveryMessage = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)('user/send_recovery_message', async (data, thunkAPI)=>{
    try {
        const res = await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.post */ .N.post('/send_recovery_message', data);
        if (res.status === 200) {
            return res.status;
        }
    } catch (err) {
        if (axios__WEBPACK_IMPORTED_MODULE_2___default().isAxiosError(err)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = err.response) === null || ref === void 0 ? void 0 : ref.status);
        }
        return thunkAPI.rejectWithValue(422);
    }
});
const fetchAddAddress = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)('address/add', async (data, { rejectWithValue  })=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.post */ .N.post('/user/address', data);
        return response;
    } catch (err) {
        if (axios__WEBPACK_IMPORTED_MODULE_2___default().isAxiosError(err)) {
            var ref;
            return rejectWithValue((ref = err.response) === null || ref === void 0 ? void 0 : ref.status);
        }
    }
});
const fetchDeleteAddress = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)('/address/delete', // TODO: добавитьтип адресса к удалению адреса
async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios["delete"] */ .N["delete"]('/user/address', {
            data
        });
        // const response
        return response;
    } catch (e) {
        return thunkAPI.rejectWithValue('Ошибка apu address/delete');
    }
});
const fetchDeleteAddressAdmin = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)('/address/AdminDeleteUser', // TODO: добавитьтип адресса к удалению адреса
async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios["delete"] */ .N["delete"]('/admin/user/address', {
            data
        });
        // const response
        return response;
    } catch (e) {
        return thunkAPI.rejectWithValue('Ошибка apu address/delete');
    }
});
const fetchAddAddressAdminForUser = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)('/address/AdminDeleteUser', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.post */ .N.post('/admin/user/address', data);
        return response;
    } catch (e) {
        return thunkAPI.rejectWithValue('Ошибка api /admin/user/address');
    }
});


/***/ })

};
;