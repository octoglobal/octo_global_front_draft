"use strict";
exports.id = 6521;
exports.ids = [6521];
exports.modules = {

/***/ 6521:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ReviewItem_ReviewItem)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./src/lib/services/services.ts
var services = __webpack_require__(4727);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/Review/ReviewItem/style.ts

const useReviewItemStyle = ()=>{
    const ReviewItemWrapperMUI = (0,material_.styled)('div')(({ theme  })=>({
            padding: '10px 20px',
            border: '1px solid #E4EAF3',
            boxSizing: 'border-box',
            borderRadius: '8px',
            // border: '1px solid black',
            // minWidth: '546px',
            // maxWidth: '546px',
            width: '546px',
            maxHeight: '540px',
            height: 'fit-content',
            // marginBottom: '32px',
            // marginRight: '56px',
            [theme.breakpoints.down(591)]: {
                width: '100%',
                // maxHeight: '360px',
                // width: '100%',
                // margin: '15px 0'
                marginBottom: '0px',
                padding: '10px 12px',
                borderRadius: '5px',
                marginRight: '0'
            }
        })
    );
    const CollapseMUI = (0,material_.styled)(material_.Collapse)(({ theme  })=>({
            [theme.breakpoints.down(501)]: {
                marginBottom: '8px'
            }
        })
    );
    const ReviewHeaderMUI = (0,material_.styled)('div')(({ theme  })=>({
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginBottom: '5px',
            [theme.breakpoints.down(501)]: {
                marginBottom: '6px'
            }
        })
    );
    const ReviewNameMUI = (0,material_.styled)('div')(({ theme  })=>({
            fontFamily: 'Roboto',
            fontStyle: 'normal',
            fontWeight: '400',
            fontSize: '20px',
            lineHeight: '23px',
            color: '#000000',
            wordBreak: 'break-word',
            [theme.breakpoints.down(501)]: {
                fontSize: '16px',
                lineHeight: '19px'
            },
            [theme.breakpoints.down(361)]: {
                fontSize: '14px',
                lineHeight: '17px',
                marginRight: '10px'
            }
        })
    );
    const ReviewDateMUI = (0,material_.styled)('div')(({ theme  })=>({
            fontFamily: 'Roboto',
            fontStyle: 'normal',
            fontWeight: '400',
            fontSize: '14px',
            lineHeight: '16px',
            color: '#C4C4C4',
            wordBreak: 'break-word',
            minWidth: '150px',
            [theme.breakpoints.down(501)]: {
                fontSize: '12px',
                lineHeight: '14.5px',
                textAlign: 'right',
                minWidth: '100px'
            }
        })
    );
    const ReviewTextMUI = (0,material_.styled)('div')(({ theme  })=>({
            fontFamily: 'Roboto',
            fontStyle: 'normal',
            fontWeight: '300',
            fontSize: '20px',
            lineHeight: '130%',
            color: '#000000',
            [theme.breakpoints.down(501)]: {
                fontSize: '16px',
                lineHeight: '19px'
            }
        })
    );
    const ShowMoreMUI = (0,material_.styled)('div')(()=>({
            fontFamily: 'Roboto',
            fontStyle: 'normal',
            fontWeight: '400',
            fontSize: '14px',
            lineHeight: '16px',
            color: '#274D82',
            cursor: 'pointer',
            marginTop: '5px',
            textAlign: 'end'
        })
    );
    return {
        CollapseMUI,
        ReviewItemWrapperMUI,
        ReviewHeaderMUI,
        ReviewNameMUI,
        ReviewDateMUI,
        ReviewTextMUI,
        ShowMoreMUI
    };
};

// EXTERNAL MODULE: ./src/hooks/useUserStore.ts
var useUserStore = __webpack_require__(257);
// EXTERNAL MODULE: ./src/hooks/useReduxHooks.ts
var useReduxHooks = __webpack_require__(4730);
// EXTERNAL MODULE: ./src/store/reducers/reviewsSlice/asyncActions/reviewsApi.ts
var reviewsApi = __webpack_require__(829);
// EXTERNAL MODULE: ./src/components/AnyPage/OrderItem/OrderDeleteModal/OrderDeleteModal.tsx + 1 modules
var OrderDeleteModal = __webpack_require__(1112);
// EXTERNAL MODULE: ./src/UI/UIComponents/ButtonUI/ButtonUI.tsx + 1 modules
var ButtonUI = __webpack_require__(2907);
;// CONCATENATED MODULE: ./src/components/Review/ReviewItem/ReviewItem.tsx









const ReviewItem = ({ text , createdTime , userName , id  })=>{
    const { 0: openMore , 1: setOpenMore  } = (0,external_react_.useState)(false);
    const triggerShowMore = ()=>{
        setOpenMore((prevState)=>!prevState
        );
    };
    const { 0: openConfirmDialog , 1: setOpenConfirmDialog  } = (0,external_react_.useState)(false);
    const handlerCancel = ()=>{
        setOpenConfirmDialog(false);
    };
    const { isAdmin ,  } = (0,useUserStore/* useUserStore */.L)();
    const dispatch = (0,useReduxHooks/* useAppDispatch */.T)();
    const handleDeleteReview = ()=>{
        dispatch((0,reviewsApi/* fetchDeleteReview */.Ig)({
            id: id
        }));
        setOpenConfirmDialog(false);
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ReviewItemWrapperMUI, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ReviewHeaderMUI, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ReviewNameMUI, {
                                children: userName
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ReviewDateMUI, {
                                children: (0,services/* ToRusDate */.rF)(createdTime)
                            })
                        ]
                    }),
                    text.length > 145 ? /*#__PURE__*/ jsx_runtime_.jsx(CollapseMUI, {
                        in: openMore,
                        collapsedSize: "74px",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ReviewTextMUI, {
                            children: text
                        })
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(ReviewTextMUI, {
                        children: text
                    }),
                    text.length >= 145 && /*#__PURE__*/ jsx_runtime_.jsx(ShowMoreMUI, {
                        onClick: triggerShowMore,
                        children: openMore ? 'Скрыть' : 'Показать полностью'
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(OrderDeleteModal/* default */.Z, {
                title: "Вы уверены что хотите удалить отзыв?",
                buttonNoText: "Нет",
                onClickYes: handleDeleteReview,
                onClickNo: handlerCancel,
                dialogProps: {
                    open: openConfirmDialog,
                    onClose: handlerCancel
                }
            }),
            isAdmin ? /*#__PURE__*/ jsx_runtime_.jsx(ButtonUI/* default */.Z, {
                style: {
                    width: '100px',
                    height: '30px',
                    backgroundColor: '#274D82',
                    opacity: '0.8'
                },
                onClick: ()=>setOpenConfirmDialog(true)
                ,
                children: "delete"
            }) : null
        ]
    }));
};
/* harmony default export */ const ReviewItem_ReviewItem = (/*#__PURE__*/external_react_default().memo(ReviewItem));
const { CollapseMUI , ReviewItemWrapperMUI , ReviewHeaderMUI , ReviewNameMUI , ReviewDateMUI , ReviewTextMUI , ShowMoreMUI  } = useReviewItemStyle();


/***/ })

};
;