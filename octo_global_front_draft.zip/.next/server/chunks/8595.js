"use strict";
exports.id = 8595;
exports.ids = [8595];
exports.modules = {

/***/ 7282:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgEditPencil = function SvgEditPencil(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M20.677 5.828 17.85 3l-1.414 1.414 2.828 2.829 1.414-1.415Zm-2.12 2.122-2.83-2.829-9.192 9.193 2.829 2.828 9.192-9.192ZM5.12 15.728l.707-.707 2.829 2.828-.707.707-3.536.707.707-3.535Z",
    fill: "#C7C7C7"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgEditPencil);

/***/ }),

/***/ 8595:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _hooks_useMedia__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2447);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5621);
/* harmony import */ var _UIIcon_EditPencil_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7282);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const TextFieldUI = ({ controller , inputProps , iconProps , regexProps  })=>{
    const { isMobile  } = (0,_hooks_useMedia__WEBPACK_IMPORTED_MODULE_4__/* .useMobile */ .XA)();
    const hasIconProps = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>typeof iconProps !== 'undefined'
    , [
        iconProps
    ]);
    const { 0: iconActive , 1: setIconActive  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const IconComponentActive = iconProps === null || iconProps === void 0 ? void 0 : iconProps.activeIcon;
    const IconComponent = iconProps === null || iconProps === void 0 ? void 0 : iconProps.defaultIcon;
    const handlerIconClick = ()=>{
        if (hasIconProps && (iconProps === null || iconProps === void 0 ? void 0 : iconProps.onClick)) {
            iconProps === null || iconProps === void 0 ? void 0 : iconProps.onClick();
            setIconActive((prevState)=>!prevState
            );
        }
    };
    const handlerChange = (onChange)=>{
        return (e)=>{
            let value = e.target.value;
            if (regexProps === null || regexProps === void 0 ? void 0 : regexProps.regex) value = e.target.value.replace(regexProps.regex, '');
            if (regexProps === null || regexProps === void 0 ? void 0 : regexProps.ucFirst) {
                value = e.target.value.replace(regexProps.regex, (u)=>u.toUpperCase()
                );
            }
            onChange(value);
        };
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextFieldContainerUI, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
            name: controller.name,
            control: controller.control,
            defaultValue: controller.defaultValue,
            rules: controller.rules,
            render: ({ field: { value , onChange  } , fieldState: { error  }  })=>{
                /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                    // sx={TextFieldStyle}
                    sx: isMobile ? TextFieldMobileStyle : TextFieldStyle,
                    value: value,
                    ...inputProps,
                    onChange: handlerChange(onChange),
                    // onChange={onChange}
                    helperText: error ? error.message ? error.message : inputProps === null || inputProps === void 0 ? void 0 : inputProps.helperText : '',
                    // helperText={error ? error : ( inputProps?.helperText || '' )}
                    // helperText={inputProps?.helperText || error ? error.message ? error.message : inputProps?.helperText : ''}
                    error: !!error,
                    InputProps: {
                        endAdornment: (iconProps === null || iconProps === void 0 ? void 0 : iconProps.visibleIcon) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputAdornment, {
                            onClick: handlerIconClick,
                            position: "start",
                            disablePointerEvents: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_EditPencil_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                        }) : ''
                    }
                });
            }
        })
    }));
};
const { TextFieldUI: TextFieldContainerUI , TextFieldStyle , TextFieldMobileStyle ,  } = (0,_style__WEBPACK_IMPORTED_MODULE_5__/* .useTextFieldUIStyle */ .d)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(TextFieldUI));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5621:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ useTextFieldUIStyle)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useTextFieldUIStyle = ()=>{
    const TextFieldUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            width: '100%',
            position: 'relative',
            zIndex: '1',
            '& .MuiFormControl-root': {
                width: '100%',
                '& .MuiInputBase-root': {
                    fontSize: '20px'
                }
            },
            '& .MuiFormHelperText-root': {
                fontFamily: 'Roboto',
                fontStyle: 'normal',
                fontWeight: '400',
                fontSize: '14px !important',
                lineHeight: '16px',
                color: '#F35151',
                textAlign: 'end',
                // marginTop: '5px',
                marginRight: '0px'
            },
            '& .MuiOutlinedInput-root': {
                paddingRight: '0px'
            },
            '& .MuiIconButton:hover': {
                backgroundColor: 'transparent !important'
            },
            '& .MuiButtonBase:hover': {
                backgroundColor: 'transparent !important'
            },
            [theme.breakpoints.down(500)]: {
                '& .MuiFormHelperText-root': {
                    fontSize: '12px !important',
                    lineHeight: '14px'
                }
            }
        })
    );
    const TextFieldStyle = {
        width: '100%',
        height: '49px',
        background: '#FFFFFF',
        border: '0',
        boxSizing: 'border-box',
        boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.03)',
        '& .MuiOutlinedInput-root, .MuiFormControl-root': {
            width: '100%',
            height: '49px',
            borderRadius: '5px',
            paddingRight: '0px'
        },
        '& .MuiInputLabel-root': {
            top: '-8px'
        },
        '& input': {
            width: '100%',
            boxSizing: 'border-box',
            height: '39px',
            '&::placeholder': {
                fontStyle: 'normal',
                fontWeight: '300',
                fontSize: '20px',
                lineHeight: '23px',
                color: '#C4C4C4'
            }
        }
    };
    const TextFieldMobileStyle = {
        width: '100%',
        height: '49px',
        background: '#FFFFFF',
        border: '0',
        boxSizing: 'border-box',
        boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.03)',
        '& .MuiOutlinedInput-root, .MuiFormControl-root': {
            width: '100%',
            height: '49px',
            borderRadius: '5px',
            paddingRight: '0px'
        },
        '& .MuiInputLabel-root': {
            top: '-8px'
        },
        '& input': {
            width: '100%',
            boxSizing: 'border-box',
            '&::placeholder': {
                fontStyle: 'normal',
                fontWeight: '300',
                fontSize: '16px',
                lineHeight: '40px',
                color: '#C4C4C4'
            }
        }
    };
    const IconUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('span')(()=>({
            width: '25px',
            height: '25px',
            '& svg': {
                width: 'auto',
                height: 'auto'
            },
            position: 'absolute',
            top: '22%',
            right: '7px',
            zIndex: '2'
        })
    );
    return {
        TextFieldUI,
        TextFieldStyle,
        TextFieldMobileStyle,
        IconUI
    };
};


/***/ })

};
;