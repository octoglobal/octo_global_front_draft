"use strict";
exports.id = 5854;
exports.ids = [5854];
exports.modules = {

/***/ 1169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ BackgroundWrapper_BackgroundWrapper)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/AnyPage/BackgroundWrapper/style.ts

const useBackgroundWrapperStyle = ()=>{
    const BackgroundWrapperMUI = (0,material_.styled)('div')(({ theme  })=>({
            position: 'relative',
            height: '100%',
            background: 'url("./image/OctoConfidence.png")',
            backgroundRepeat: 'no-repeat',
            backgroundPosition: 'right 0px top 210px',
            backgroundSize: '681px 482px',
            [theme.breakpoints.down(1360)]: {
                backgroundPosition: 'right 0 top 150px'
            },
            [theme.breakpoints.down(1220)]: {
                backgroundSize: '500px 354px',
                backgroundPosition: 'right 0 top 180px'
            },
            [theme.breakpoints.down(720)]: {
                backgroundSize: '290px 205px',
                backgroundPosition: 'left 50% top 180px'
            },
            [theme.breakpoints.down(391)]: {
                backgroundSize: '290px 205px',
                backgroundPosition: 'left 50% top 180px'
            }
        })
    );
    const BackgroundTitleMUI = (0,material_.styled)('h2')(({ theme  })=>({
            fontFamily: 'Playfair Display',
            fontSize: '96px',
            fontWeight: 900,
            lineHeight: '128px',
            opacity: '7%',
            color: '#274D82',
            position: 'absolute',
            left: '-135px',
            top: '390px',
            transform: 'rotate(270deg)',
            [theme.breakpoints.down(1360)]: {
                top: '343px'
            },
            [theme.breakpoints.down(720)]: {
                fontSize: '32px',
                left: '32%',
                transform: 'rotate(0)',
                top: '343px'
            },
            [theme.breakpoints.down(391)]: {
                fontSize: '32px',
                left: '25%',
                transform: 'rotate(0)',
                top: '343px'
            }
        })
    );
    return {
        BackgroundWrapperMUI,
        BackgroundTitleMUI
    };
};

;// CONCATENATED MODULE: ./src/components/AnyPage/BackgroundWrapper/BackgroundWrapper.tsx



const BackgroundWrapper = ({ children  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(BackgroundWrapperMUI, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(BackgroundTitleMUI, {
                children: "octo global"
            }),
            children
        ]
    }));
};
const { BackgroundWrapperMUI , BackgroundTitleMUI  } = useBackgroundWrapperStyle();
/* harmony default export */ const BackgroundWrapper_BackgroundWrapper = (/*#__PURE__*/external_react_default().memo(BackgroundWrapper));


/***/ }),

/***/ 2656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



const HeaderMargin = ()=>{
    const HeaderMarginMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)('section')(({ theme  })=>({
            height: '61px',
            width: '100%',
            backgroundColor: '#FFFFFF',
            visibility: 'hidden',
            [theme.breakpoints.down(1181)]: {
                height: '71px'
            },
            [theme.breakpoints.down(1025)]: {
                height: '65px'
            },
            [theme.breakpoints.down(501)]: {
                height: '70px'
            }
        })
    );
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HeaderMarginMUI, {}));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(HeaderMargin));


/***/ })

};
;