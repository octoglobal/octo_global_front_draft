"use strict";
exports.id = 1737;
exports.ids = [1737];
exports.modules = {

/***/ 8667:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _UIIcon_EditPencil_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7282);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5621);
/* harmony import */ var _lib_services_services__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4727);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





// import InputMask from 'react-input-mask';


// TODO: вынести типы пропсов в отдельный файл
const TextFieldPhoneUI = ({ controller , inputProps , iconProps  })=>{
    const { TextFieldUI , TextFieldStyle , IconUI  } = (0,_style__WEBPACK_IMPORTED_MODULE_5__/* .useTextFieldUIStyle */ .d)();
    const hasIconProps = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>typeof iconProps !== 'undefined'
    , [
        iconProps
    ]);
    const handlerIconClick = ()=>{
        if (hasIconProps) {
            iconProps === null || iconProps === void 0 ? void 0 : iconProps.onClick();
            setIconActive((prevState)=>!prevState
            );
        }
    };
    const { 0: iconActive , 1: setIconActive  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const IconComponent = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return iconActive ? iconProps === null || iconProps === void 0 ? void 0 : iconProps.defaultIcon : iconProps === null || iconProps === void 0 ? void 0 : iconProps.activeIcon;
    }, [
        iconProps
    ]);
    // const focusTextInput = useCallback(() => {
    // 	if(inputRef?.current) inputRef.current.focus();
    // }, [inputRef])
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextFieldUI, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
            name: controller.name,
            control: controller.control,
            defaultValue: controller.defaultValue,
            rules: controller.rules,
            render: ({ field: { value , onChange  } , fieldState: { error  }  })=>{
                // <InputMask
                // 	mask="+7 999 999 99 99"
                // 	// eslint-disable-next-line @typescript-eslint/ban-ts-comment
                // 	// @ts-ignore:next-line
                // 	maskChar=" "
                // 	value={value}
                // 	onChange={onChange}
                // >
                // 	{ () => (
                /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField, {
                    sx: TextFieldStyle,
                    ...inputProps,
                    value: value,
                    // onChange={(e) => onChange(e.target.value)}
                    onChange: (e)=>{
                        (0,_lib_services_services__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP)(e, value, onChange);
                    },
                    onKeyDown: (e)=>{
                        if (e.key === 'Backspace' && value.length === 3) {
                            onChange('');
                        }
                    },
                    helperText: error ? error.message ? error.message : inputProps === null || inputProps === void 0 ? void 0 : inputProps.helperText : '',
                    // helperText={inputProps?.helperText || error ? error.message ? error.message : inputProps?.helperText : ''}
                    error: !!error,
                    InputLabelProps: {
                        shrink: true
                    },
                    InputProps: {
                        endAdornment: (iconProps === null || iconProps === void 0 ? void 0 : iconProps.editIcon) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.InputAdornment, {
                            onClick: handlerIconClick,
                            position: "start",
                            disablePointerEvents: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_EditPencil_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                        }) : ''
                    }
                });
            }
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(TextFieldPhoneUI));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1737:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _hooks_useMedia__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2447);
/* harmony import */ var _useAddLocation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1256);
/* harmony import */ var _UI_UIComponents_TextFIeldUI_TextFieldPhoneUI_TextFieldPhoneUI__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8667);
/* harmony import */ var UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8595);
/* harmony import */ var UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2907);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7059);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(257);
/* harmony import */ var _lib_services_services__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4727);
/* harmony import */ var UI_UIComponents_ModalUI_ModalUI__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1705);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _UI_UIComponents_TextFIeldUI_TextFieldPhoneUI_TextFieldPhoneUI__WEBPACK_IMPORTED_MODULE_5__, UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_6__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _UI_UIComponents_TextFIeldUI_TextFieldPhoneUI_TextFieldPhoneUI__WEBPACK_IMPORTED_MODULE_5__, UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const AddLocationForm = ({ setOpenForm , isVisibleCancel =true , isAddressProperty =false , buttonStyles ={} , buttonSend ='' , textFieldStyles ={} ,  })=>{
    const { FormUI , FormWrapper , FormRowTitle , FormRowTextField , FormTextFieldUI , ButtonSubmitUI , ButtonCancelUI , FormRowButtonUI ,  } = (0,_style__WEBPACK_IMPORTED_MODULE_8__/* .useAddLocationFormStyle */ .J)();
    const { handleSubmit , control , setError , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)();
    const { // user: {
    // 	name, surname,
    // 	phone
    // },
    isAdmin , userPhone , userName , userSurname , adminSwitchUserModel  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_9__/* .useUserStore */ .L)();
    const { onSubmit , errAdd , setErrAdd  } = (0,_useAddLocation__WEBPACK_IMPORTED_MODULE_4__/* .useAddLocation */ .m)();
    const { isMobile  } = (0,_hooks_useMedia__WEBPACK_IMPORTED_MODULE_3__/* .useMobile */ .XA)();
    // const handlerCancelButton = () => {
    // 	setOpenForm(prevState => !prevState);
    // };
    const wrapperSubmit = (formData)=>{
        if (isAdmin && adminSwitchUserModel) {
            const r = onSubmit(formData, isAdmin, adminSwitchUserModel.id);
            r.then((err)=>{
                if (!err) {
                    setOpenForm(false);
                    reset({});
                }
            });
        } else {
            const r = onSubmit(formData);
            r.then((err)=>{
                if (!err) {
                    setOpenForm(false);
                    reset({});
                }
            });
        }
    // setOpenForm(prevState => !prevState);
    // reset({});
    };
    const addressRegex = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>new RegExp(/[^A-Za-z0-9#?!:;,.-_+= ]/gi)
    , []);
    const TextFieldStyles = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>({
            ...FormTextFieldUI,
            ...textFieldStyles
        })
    , [
        textFieldStyles
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setError('address', {
            type: 'string',
            message: ''
        });
    }, []);
    // смена пользователя, чистим поля
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        reset({});
    }, [
        userName
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FormUI, {
        onSubmit: handleSubmit(wrapperSubmit),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FormWrapper, {
                increaseFormField: isAddressProperty,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormRowTitle, {
                        children: "Имя"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormRowTextField, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            controller: {
                                name: 'name',
                                control,
                                defaultValue: (0,_lib_services_services__WEBPACK_IMPORTED_MODULE_11__/* .translit */ .bY)(userName),
                                rules: {
                                    required: true
                                }
                            },
                            inputProps: {
                                placeholder: isMobile ? 'Имя' : '',
                                name: 'name',
                                type: 'text',
                                required: true,
                                // helperText: 'Заполните поле "Почта"',
                                sx: TextFieldStyles
                            },
                            regexProps: {
                                regex: addressRegex
                            }
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormRowTitle, {
                        children: "Фамилия"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormRowTextField, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            controller: {
                                name: 'surname',
                                control,
                                defaultValue: (0,_lib_services_services__WEBPACK_IMPORTED_MODULE_11__/* .translit */ .bY)(userSurname),
                                rules: {
                                    required: true
                                }
                            },
                            inputProps: {
                                placeholder: isMobile ? 'Фамилия' : '',
                                name: 'surname',
                                type: 'text',
                                required: true,
                                sx: TextFieldStyles
                            },
                            regexProps: {
                                regex: addressRegex
                            }
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormRowTitle, {
                        children: "Телефон"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormRowTextField, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_TextFIeldUI_TextFieldPhoneUI_TextFieldPhoneUI__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            controller: {
                                name: 'phone',
                                control,
                                defaultValue: userPhone,
                                rules: {
                                    required: true
                                }
                            },
                            inputProps: {
                                placeholder: isMobile ? 'Телефон' : '',
                                name: 'phone',
                                type: 'text',
                                required: true,
                                sx: TextFieldStyles
                            }
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormRowTitle, {
                        children: "Адрес"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormRowTextField, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            controller: {
                                name: 'address',
                                control,
                                defaultValue: '',
                                rules: {
                                    required: true
                                }
                            },
                            inputProps: {
                                placeholder: isMobile ? 'Адрес' : '',
                                name: 'address',
                                type: 'text',
                                required: true,
                                sx: TextFieldStyles,
                                helperText: isAddressProperty ? '' : 'Только латинские буквы и цифры'
                            },
                            regexProps: {
                                regex: addressRegex
                            }
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormRowTitle, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FormRowButtonUI, {
                        children: [
                            isVisibleCancel && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                style: ButtonCancelUI,
                                variant: "text",
                                onClick: ()=>setOpenForm(false)
                                ,
                                children: "Отмена"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                type: "submit",
                                style: ButtonSubmitUI,
                                sx: buttonStyles,
                                children: buttonSend ? buttonSend : 'Сохранить'
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_ModalUI_ModalUI__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                dialogProps: {
                    open: errAdd,
                    onClose: ()=>setErrAdd(false)
                },
                title: 'Произошла ошибка'
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(AddLocationForm));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7059:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ useAddLocationFormStyle)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);


const useAddLocationFormStyle = ()=>{
    const FormUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)('form')(({ theme  })=>({
            display: 'flex',
            margin: '5px 0 0',
            [theme.breakpoints.down(500)]: {
                marginTop: '24px'
            }
        })
    );
    const FormWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)('div', {
        shouldForwardProp: (prop)=>prop !== 'increaseFormField'
    })(({ theme , increaseFormField =false  })=>({
            width: '100%',
            height: '100%',
            display: 'grid',
            gridTemplateColumns: `87px ${increaseFormField ? 501 : 471}px`,
            gridTemplateRows: 'auto auto auto auto auto',
            gridColumnGap: `${increaseFormField ? 39 : 39}px`,
            gridRowGap: `${increaseFormField ? 15 : 10}px`,
            [theme.breakpoints.down(660)]: {
                gridTemplateColumns: '87px auto'
            },
            [theme.breakpoints.down(501)]: {
                gridTemplateColumns: 'auto',
                gridTemplateRows: 'auto auto auto auto',
                gridRowGap: `${increaseFormField ? 10 : 15}px`,
                '& > div:last-child': {
                    marginTop: '10px'
                }
            }
        })
    );
    const FormRowTitle = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)('div')(({ theme  })=>({
            fontFamily: 'Roboto',
            fontStyle: 'normal',
            fontWeight: '400',
            fontSize: '20px',
            lineHeight: '23px',
            color: '#000000',
            paddingTop: '13px',
            [theme.breakpoints.down(501)]: {
                fontSize: '16px',
                lineHeight: '19px',
                display: 'none'
            }
        })
    );
    const FormTextFieldUI = {
        width: '50%',
        height: '49px !important',
        textAlign: 'start',
        borderRadius: '5px',
        // border: '1px solid #DFE4EC',
        // boxSizing: 'border-box',
        // boxShadow:' 0px 4px 4px rgba(0, 0, 0, 0.03)',
        '& label': {
            transform: 'translate(14px, 2px) scale(1)'
        },
        '& .MuiOutlinedInput-root': {
            '& input': {
                padding: '0px 14px',
                height: '49px !important',
                color: 'black',
                fontFamily: 'Roboto',
                fontStyle: 'normal',
                fontWeight: '300',
                fontSize: '20px',
                lineHeight: '18px',
                '-webkit-text-fill-color': 'black'
            },
            '& fieldset': {
                border: 'none !important',
                boxShadow: 'none !important'
            },
            '&:hover fieldset': {
                border: 'none !important',
                boxShadow: 'none !important'
            },
            '&.Mui-focused fieldset': {
                border: 'none !important',
                boxShadow: 'none !important'
            }
        }
    };
    const FormRowTextField = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)('div')(({ theme  })=>({
            // width: '501px',
            '&:last-child': {
                justifySelf: 'end',
                marginTop: '11px'
            },
            '& .MuiFormControl-root': {
                // border: 'none',
                // boxShadow: 'none',
                border: '1px solid #DFE4EC',
                boxSizing: 'border-box',
                boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.03)',
                height: 'auto'
            },
            '& .MuiFormControl-root input:focus ': {
            },
            [theme.breakpoints.down(500)]: {
                '& input': {
                    fontWeight: '300 !important',
                    fontSize: '16px !important',
                    lineHeight: '19px !important'
                }
            }
        })
    );
    const FormRowButtonUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'flex-end',
            alignItems: 'center',
            marginTop: '20px'
        })
    );
    const ButtonSubmitUI = {
        width: '135px',
        height: '32px',
        marginBottom: '0'
    };
    const ButtonCancelUI = {
        background: '#fff',
        fontFamily: 'Roboto',
        fontStyle: 'normal',
        fontWeight: '400',
        fontSize: '14px',
        lineHeight: '16px',
        textAlign: 'center',
        color: '#274D82',
        margin: '0 15px 0 0',
        width: '49px',
        height: '16px',
        alignSelf: 'center'
    };
    const FormIconUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)('span')(()=>({
            height: 'fit-content',
            '& svg': {
                cursor: 'pointer'
            }
        })
    );
    return {
        FormUI,
        FormWrapper,
        FormRowTitle,
        FormRowTextField,
        FormRowButtonUI,
        FormTextFieldUI,
        ButtonSubmitUI,
        ButtonCancelUI,
        FormIconUI
    };
};


/***/ }),

/***/ 1256:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ useAddLocation)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_adminSlice_asyncThunk_adminApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5907);
/* harmony import */ var _store_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6213);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4730);
/* harmony import */ var _lib_services_services__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4727);







const useAddLocation = ()=>{
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_3__/* .useAppDispatch */ .T)();
    const { 0: errAdd , 1: setErrAdd  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    //
    // const setErrorFields = (fieldName: keyof IUserAddresReq, message: string) => {
    // 	setError(fieldName, {
    // 		type: 'string',
    // 		message: message
    // 	});
    // };
    //
    // const handleBadResponse = () => {
    // 	setErrorFields('');
    // 	setErrorFields('');
    // 	setErrorFields('');
    // 	setErrorFields('');
    // };
    const onSubmit = async (data, isAdmin, userId)=>{
        const formData = data;
        // TODO: добавить проверки и всякие дополнения к данным формы
        if (formData.name && formData.surname && formData.phone && formData.address) {
            if (isAdmin && userId) {
                let err = null;
                const sendObject = {
                    userId: userId,
                    name: (0,_lib_services_services__WEBPACK_IMPORTED_MODULE_4__/* .translit */ .bY)(formData.name),
                    surname: (0,_lib_services_services__WEBPACK_IMPORTED_MODULE_4__/* .translit */ .bY)(formData.surname),
                    address_string: formData.address,
                    phone: formData.phone,
                    latitude: '',
                    longitude: ''
                };
                await dispatch((0,_store_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_2__/* .fetchAddAddressAdminForUser */ .bq)(sendObject)).then((e)=>{
                    const statusCode = e.payload;
                    if (statusCode.status !== 200) {
                        err = true;
                        setErrAdd(true);
                    }
                    dispatch((0,_reducers_adminSlice_asyncThunk_adminApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchUserAdmin */ .M)({
                        userId: userId
                    }));
                });
                return err;
            } else {
                const sendObject = {
                    name: (0,_lib_services_services__WEBPACK_IMPORTED_MODULE_4__/* .translit */ .bY)(formData.name),
                    surname: (0,_lib_services_services__WEBPACK_IMPORTED_MODULE_4__/* .translit */ .bY)(formData.surname),
                    address_string: formData.address,
                    phone: formData.phone,
                    latitude: '4.5321',
                    longitude: '98.7456'
                };
                dispatch((0,_store_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_2__/* .fetchAddAddress */ .qC)(sendObject)).then(()=>{
                    dispatch((0,_store_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_2__/* .fetchUserAutoLogin */ .u3)());
                });
            }
        }
    };
    return {
        onSubmit,
        setErrAdd,
        errAdd
    };
};


/***/ })

};
;