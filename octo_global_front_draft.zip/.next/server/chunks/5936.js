"use strict";
exports.id = 5936;
exports.ids = [5936];
exports.modules = {

/***/ 1839:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ FormComponent_FormComponent)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/AnyPage/FormComponent/style.ts

const useFormComponentStyle = ()=>{
    const FormComponentContent = (0,material_.styled)('div', {
        shouldForwardProp: (prop)=>prop !== 'background'
    })(({ background , theme  })=>({
            maxWidth: '426px',
            width: 'auto',
            height: 'auto',
            padding: '25px 50px',
            // background: background ? 'rgba(223, 228, 236, 0.5)' : 'inherit',
            background: 'inherit',
            border: background ? '1px solid #AABCBF' : 'none',
            borderRadius: '8px',
            [theme.breakpoints.down(500)]: {
                padding: '0'
            }
        })
    );
    const FormComponentTitle = (0,material_.styled)('h4')(({ theme  })=>({
            fontStyle: 'normal',
            fontWeight: '400',
            fontSize: '36px',
            lineHeight: '42px',
            textAlign: 'center',
            color: '#000000',
            [theme.breakpoints.down(600)]: {
                paddingTop: 20
            },
            [theme.breakpoints.down(500)]: {
                fontWeight: '500',
                fontSize: '20px',
                lineHeight: '23px'
            }
        })
    );
    return {
        FormComponentContent,
        FormComponentTitle
    };
};

;// CONCATENATED MODULE: ./src/components/AnyPage/FormComponent/FormComponent.tsx



const FormComponent = ({ title , background =true , children  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(FormComponentContent, {
        background: background,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(FormComponentTitle, {
                children: title
            }),
            children
        ]
    }));
};
/* harmony default export */ const FormComponent_FormComponent = (/*#__PURE__*/external_react_default().memo(FormComponent));
const { FormComponentContent , FormComponentTitle  } = useFormComponentStyle();


/***/ }),

/***/ 8844:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ useFormsStyle)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useFormsStyle = ()=>{
    const FormsWrapperBox = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            display: 'flex',
            flexDirection: 'column',
            padding: '20px 0px 0px',
            [theme.breakpoints.down(600)]: {
                padding: '15px'
            },
            [theme.breakpoints.down(500)]: {
            }
        })
    );
    const FormCheckboxItemMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            fontWeight: 300,
            lineHeight: '16px',
            fontSize: '14px'
        })
    );
    const FormsFooterInfoBox = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'column',
            marginBottom: '15px',
            fontStyle: 'normal',
            fontWeight: '300',
            fontSize: '12px',
            lineHeight: '14px',
            color: '#000000'
        })
    );
    const FormsLink = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('span')(()=>({
            fontWeight: '300',
            fontSize: '14px',
            lineHeight: '16px',
            color: '#234A82',
            textDecoration: 'underline',
            // display: 'inline-block',
            cursor: 'pointer'
        })
    );
    const FormsInput = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            marginBottom: '20px',
            '& .MuiFormHelperText-root': {
                marginTop: '5px'
            },
            [theme.breakpoints.down(500)]: {
                marginBottom: '15px'
            }
        })
    );
    const FormsButton = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            // marginBottom: '15px',
            '& .Mui-disabled': {
                opacity: '0.8'
            }
        })
    );
    const FormsDescription = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            marginBottom: '15px',
            '& p': {
                fontStyle: 'normal',
                fontWeight: '300',
                fontSize: '14px',
                lineHeight: '16px',
                color: '#000000'
            }
        })
    );
    const FormsCheckBoxWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            display: 'flex',
            alignItems: 'center',
            marginBottom: '21px',
            position: 'relative',
            '& p': {
                fontStyle: 'normal',
                fontWeight: '300',
                fontSize: '12px',
                lineHeight: '14px',
                color: '#C4C4C4'
            },
            '& span': {
                // width: '20px',
                // height: '20px',
                padding: '0',
                margin: '0 15px 0 0'
            },
            [theme.breakpoints.down(500)]: {
                marginBottom: '15px'
            }
        })
    );
    const FormHelperErrorUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.FormHelperText)(()=>({
            position: 'absolute',
            top: '22px',
            right: '0',
            '& span': {
                fontFamily: 'Roboto',
                fontStyle: 'normal',
                fontWeight: '400',
                fontSize: '10px',
                lineHeight: '12px',
                color: 'red !important'
            }
        })
    );
    const TextAreaUI = {
        // height: '183px',
        maxHeight: '183px',
        // minHeight: '183px',
        '& .MuiOutlinedInput-root, .MuiFormControl-root, .MuiOutlinedInput-input': {
            // minHeight: '183px',
            maxHeight: '183px !important'
        },
        '& textarea::placeholder': {
            color: '#C4C4C4'
        }
    };
    const TextFieldSx = {
        height: '40px'
    };
    const checkboxItemModificationWrapper = {
        alignItems: 'flex-start'
    };
    return {
        FormsWrapperBox,
        FormsFooterInfoBox,
        FormsLink,
        FormsInput,
        FormsButton,
        FormCheckboxItemMUI,
        FormsCheckBoxWrapper,
        FormsDescription,
        FormHelperErrorUI,
        checkboxItemModificationWrapper,
        TextAreaUI,
        TextFieldSx
    };
};


/***/ })

};
;