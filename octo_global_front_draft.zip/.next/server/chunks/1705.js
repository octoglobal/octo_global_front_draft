"use strict";
exports.id = 1705;
exports.ids = [1705];
exports.modules = {

/***/ 1705:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ModalUI_ModalUI)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./src/UI/UIComponents/ButtonUI/ButtonUI.tsx + 1 modules
var ButtonUI = __webpack_require__(2907);
;// CONCATENATED MODULE: ./src/UI/UIComponents/ModalUI/style.ts


const useModalUIStyles = ()=>{
    const DialogMUI = (0,material_.styled)(material_.Dialog)(({ theme  })=>({
            '& .MuiDialog-container': {
                position: 'relative',
                '& .MuiPaper-root': {
                    backgroundColor: '#F1F4F9',
                    boxShadow: '0px 4px 15px rgba(0, 0, 0, 0.15)',
                    borderRadius: '15px',
                    padding: '5px',
                    maxWidth: '573px',
                    maxHeight: '232px',
                    width: '100%',
                    height: '100%',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    flexDirection: 'column',
                    [theme.breakpoints.down(769)]: {
                        minWidth: '319px',
                        minHeight: '140px',
                        height: 'auto',
                        padding: '20px 30px'
                    },
                    [theme.breakpoints.down(350)]: {
                        minWidth: '290px'
                    }
                }
            }
        })
    );
    const DialogTitleMUI = (0,material_.styled)('h5')(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '23px',
            fontWeight: 400,
            whiteSpace: 'pre-line',
            textAlign: 'center',
            color: '#000000',
            [theme.breakpoints.down(1025)]: {
                fontSize: '16px',
                lineHeight: '18px'
            }
        })
    );
    const DialogBodyMUI = (0,material_.styled)('div')(()=>({
            width: '100%'
        })
    );
    const ButtonContainerMUI = (0,material_.styled)('div')(({ theme  })=>({
            maxWidth: '135px',
            margin: '48px auto 0',
            [theme.breakpoints.down(769)]: {
                marginTop: '27px'
            }
        })
    );
    const ButtonMUI = (0,material_.styled)(ButtonUI/* default */.Z)(()=>({
            opacity: 0.8,
            fontWeight: 400,
            minWidth: '135px',
            maxWidth: '135px',
            height: '32px',
            marginBottom: 0
        })
    );
    const BackDropBlurMUI = (0,material_.styled)(material_.Backdrop, {
        name: 'MuiModal',
        slot: 'Backdrop',
        overridesResolver: (props, styles)=>{
            return styles.backdrop;
        }
    })({
        background: 'rgba(255, 255, 255, 0.5)',
        backdropFilter: 'blur(1px)',
        filter: 'blur(10px)',
        position: 'fixed',
        display: 'flex',
        // -moz-box-align: center,
        alignItems: 'center',
        // -moz-box-pack: 'center',
        justifyContent: 'center',
        inset: '0px',
        zIndex: '-1'
    });
    const CircularProgressMUI = (0,material_.styled)(material_.CircularProgress)(()=>({
            width: '60px !important',
            height: '60px !important'
        })
    );
    return {
        DialogMUI,
        ButtonMUI,
        DialogBodyMUI,
        DialogTitleMUI,
        BackDropBlurMUI,
        ButtonContainerMUI,
        CircularProgressMUI
    };
};

;// CONCATENATED MODULE: ./src/UI/UIComponents/ModalUI/ModalUI.tsx



const ModalUI = ({ dialogProps , children , title , defaultStylesButton =true , buttonProps ={} , titleStyle ={} , containerStyles ={} , closeTime =0 , DialogContainerMUI =DialogMUI , buttonText ='Отлично' , buttonClick , loading =false ,  })=>{
    const handleCloseDialog = ()=>{
        if (dialogProps === null || dialogProps === void 0 ? void 0 : dialogProps.onClose) {
            if (buttonClick) {
                buttonClick();
            } else {
                dialogProps.onClose('', 'escapeKeyDown');
            }
        }
    };
    const handleClickButton = ()=>{
        handleCloseDialog();
    };
    const ButtonContainer = (0,external_react_.useMemo)(()=>{
        if (defaultStylesButton) return ButtonContainerMUI;
        return (external_react_default()).Fragment;
    }, [
        defaultStylesButton
    ]);
    (0,external_react_.useEffect)(()=>{
        if (closeTime && (dialogProps === null || dialogProps === void 0 ? void 0 : dialogProps.open) && !loading) {
            const handleTimeoutClose = setTimeout(()=>{
                handleCloseDialog();
            }, closeTime * 1000);
            return ()=>{
                clearTimeout(handleTimeoutClose);
            };
        }
    }, [
        closeTime,
        dialogProps.open,
        loading
    ]);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(DialogContainerMUI, {
        ...dialogProps,
        disableScrollLock: false,
        BackdropComponent: BackDropBlurMUI,
        children: [
            !loading && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(DialogTitleMUI, {
                        sx: titleStyle,
                        children: title
                    }),
                    children && /*#__PURE__*/ jsx_runtime_.jsx(DialogBodyMUI, {
                        children: children
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ButtonContainer, {
                        sx: containerStyles,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ButtonMUI, {
                            onClick: handleClickButton,
                            ...buttonProps,
                            children: buttonText
                        })
                    })
                ]
            }),
            loading && /*#__PURE__*/ jsx_runtime_.jsx(CircularProgressMUI, {})
        ]
    }));
};
const { ButtonMUI , DialogMUI , DialogBodyMUI , DialogTitleMUI , BackDropBlurMUI , ButtonContainerMUI , CircularProgressMUI ,  } = useModalUIStyles();
/* harmony default export */ const ModalUI_ModalUI = (/*#__PURE__*/external_react_default().memo(ModalUI));


/***/ })

};
;