"use strict";
exports.id = 8124;
exports.ids = [8124];
exports.modules = {

/***/ 9702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path, _path2;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgAdminMenuCheckbox = function SvgAdminMenuCheckbox(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 15,
    height: 15,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M9.792 8.421C8.259 10.101 6.354 13 6.354 13s-1.35-2.223-2.182-3.403C3.34 8.417 2.419 7.569 2 7.246c0 0 .316-.554.37-.928.083-.567 0-1.124 0-1.124s1.277 1.054 2.018 1.804c.741.751 1.811 2.166 1.811 2.166s1.968-2.11 3.078-3.073C11.727 3.967 13 3 13 3s-.103.255-.368 1.296c-.23.908-.267 1.527-.267 1.527s-.917.783-2.573 2.598Z",
    fill: "#DFE4EC"
  })), _path2 || (_path2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    stroke: "#DFE4EC",
    d: "M.5.5h14v14H.5z"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgAdminMenuCheckbox);

/***/ }),

/***/ 5551:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgAdminMenuCheckboxEmpty = function SvgAdminMenuCheckboxEmpty(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 15,
    height: 15,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    stroke: "#DFE4EC",
    d: "M.5.5h14v14H.5z"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgAdminMenuCheckboxEmpty);

/***/ }),

/***/ 2131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgWhiteCloseIcon = function SvgWhiteCloseIcon(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    viewBox: "0 0 29 29",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M7.023 7.023 21.07 21.07M7.023 21.068 21.07 7.023",
    stroke: "#fff",
    strokeWidth: 4,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgWhiteCloseIcon);

/***/ }),

/***/ 8124:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Account_AdminBottomMenu_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7577);
/* harmony import */ var _UIIcon_AdminMenuCheckbox_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9702);
/* harmony import */ var _UIIcon_AdminMenuCheckboxEmpty_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5551);
/* harmony import */ var _components_Account_AdminBottomMenu_useAdminBottomMenu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4201);
/* harmony import */ var _UIIcon_WhiteCloseIcon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2131);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_AnyPage_OrderItem_OrderDeleteModal_OrderDeleteModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1112);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Account_AdminBottomMenu_useAdminBottomMenu__WEBPACK_IMPORTED_MODULE_5__]);
_components_Account_AdminBottomMenu_useAdminBottomMenu__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const AdminBottomMenu = ({ buttons , text , isVisibleMenu =true , isVisibleComponents =true ,  })=>{
    const { isChecked , isHideText , handleClickText , handleToggleChecked  } = (0,_components_Account_AdminBottomMenu_useAdminBottomMenu__WEBPACK_IMPORTED_MODULE_5__/* .useAdminBottomMenu */ .R)();
    const animation = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (isVisibleMenu) return animationSx;
        return {};
    }, [
        isVisibleMenu
    ]);
    return isVisibleComponents ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContainerMUI, {
        sx: animation,
        children: [
            text && !isHideText && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TextWrapperMUI, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextMUI, {
                        children: text
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextIconMUI, {
                        onClick: handleClickText,
                        disableTouchRipple: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_WhiteCloseIcon_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(WrapperMUI, {
                sx: isVisibleMenu ? {
                    display: 'flex'
                } : {
                    display: 'none'
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Checkbox, {
                        onClick: handleToggleChecked,
                        checked: isChecked,
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_AdminMenuCheckboxEmpty_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                        checkedIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_AdminMenuCheckbox_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ButtonWrapperMUI, {
                        children: buttons.map((button, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ButtonMUI, {
                                onClick: ()=>button.onClick(false)
                                ,
                                children: button.name
                            }, `${button.name}${index}`)
                        )
                    }),
                    buttons.map((button, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_OrderItem_OrderDeleteModal_OrderDeleteModal__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            dialogProps: {
                                open: !!button.isModalOpen,
                                onClose: ()=>button.onClick(false)
                            },
                            // title='Вы точно хотите удлать заказы?'
                            title: button.message,
                            onClickNo: ()=>button.onClick(false)
                            ,
                            onClickYes: ()=>button.onClick(true)
                        }, index)
                    )
                ]
            })
        ]
    }) : null;
};
const { TextMUI , ButtonMUI , WrapperMUI , TextIconMUI , animationSx , ContainerMUI , TextWrapperMUI , ButtonWrapperMUI ,  } = (0,_components_Account_AdminBottomMenu_style__WEBPACK_IMPORTED_MODULE_2__/* .useAdminBottomMenuStyles */ .v)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(AdminBottomMenu));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7577:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ useAdminBottomMenuStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useAdminBottomMenuStyles = ()=>{
    const visible = _mui_material__WEBPACK_IMPORTED_MODULE_0__.keyframes`
      from {
		bottom: -50px;
      }
      to {
		bottom: 10px;
      }
	`;
    const firstVisible = _mui_material__WEBPACK_IMPORTED_MODULE_0__.keyframes`
      from {
		bottom: 50px;
      }
      to {
		bottom: 0px;
      }
	`;
    const animationSx = {
        animation: `${visible} .1s linear`,
        bottom: '10px'
    };
    const ContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            maxWidth: '1103px',
            position: 'sticky',
            bottom: '0px',
            marginLeft: '23px',
            marginBottom: '51px',
            animation: `${firstVisible} .2s linear`,
            [theme.breakpoints.down(1025)]: {
                marginLeft: 0
            }
        })
    );
    const TextWrapperMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            textAlign: 'center',
            padding: '10px',
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            backgroundColor: '#DFE4EC',
            marginBottom: '15px',
            borderRadius: '5px',
            [theme.breakpoints.down(769)]: {
                textAlign: 'left',
                position: 'relative'
            }
        })
    );
    const TextMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('p')(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '23px',
            fontWeight: 300,
            width: '100%',
            [theme.breakpoints.down(769)]: {
                fontSize: '14px',
                lineHeight: '16px'
            }
        })
    );
    const TextIconMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button)(({ theme  })=>({
            width: '30px',
            height: '24px',
            minWidth: 'auto',
            padding: 0,
            '&:hover': {
                backgroundColor: '#DFE4EC'
            },
            [theme.breakpoints.down(769)]: {
                width: '22px',
                height: '22px',
                position: 'absolute',
                top: 3,
                right: 5
            }
        })
    );
    const WrapperMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            margin: '0 auto',
            height: '54px',
            borderRadius: '5px',
            backgroundColor: '#274D82',
            padding: '11px 15px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            [theme.breakpoints.down(1025)]: {
                padding: '14px 5px 14px 0',
                height: '45px'
            }
        })
    );
    const ButtonWrapperMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            '& > *:last-child': {
                marginRight: 0
            }
        })
    );
    const ButtonMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button)(({ theme  })=>({
            backgroundColor: 'rgba(223, 228, 236, 0.8)',
            minWidth: '180px',
            height: '32px',
            color: '#FFFFFF',
            marginRight: '20px',
            textTransform: 'none',
            fontSize: '14px',
            lineHeight: '16px',
            fontWeight: 500,
            '&:hover': {
                backgroundColor: 'rgba(223, 228, 236, 0.6)'
            },
            [theme.breakpoints.down(1025)]: {
                minWidth: 'auto',
                width: 'auto',
                padding: '5px 8px',
                marginRight: '10px'
            }
        })
    );
    return {
        TextMUI,
        ButtonMUI,
        WrapperMUI,
        animationSx,
        TextIconMUI,
        ContainerMUI,
        TextWrapperMUI,
        ButtonWrapperMUI
    };
};


/***/ }),

/***/ 4201:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ useAdminBottomMenu)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5641);
/* harmony import */ var _hooks_useLocalStorage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3644);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const useAdminBottomMenu = ()=>{
    const { reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFormContext)();
    const { getData , setData  } = (0,_hooks_useLocalStorage__WEBPACK_IMPORTED_MODULE_2__/* .useLocalStorage */ ._)();
    const { 0: isChecked , 1: setIsChecked  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: isHideText , 1: setIsHideText  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const handleToggleChecked = ()=>{
        if (isChecked) {
            setIsChecked(false);
            reset({});
        } else {
            setIsChecked(true);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (true) {
            if (getData('hideAccountSuggestion')) {
                setIsHideText(true);
            }
        }
    }, []);
    const handleClickText = ()=>{
        setIsHideText(true);
        setData('hideAccountSuggestion', true);
    };
    return {
        isChecked,
        isHideText,
        handleClickText,
        handleToggleChecked
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3644:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ useLocalStorage)
/* harmony export */ });
const useLocalStorage = ()=>{
    /*
	* return data || null
	* */ const getData = (key)=>{
        const lSData = localStorage.getItem(key);
        const parsesData = JSON.parse(lSData);
        return parsesData || null;
    };
    const setData = (key, data)=>{
        localStorage.setItem(key, JSON.stringify(data));
    };
    const removeData = (key)=>{
        localStorage.removeItem(key);
    };
    return {
        getData,
        setData,
        removeData
    };
};


/***/ })

};
;