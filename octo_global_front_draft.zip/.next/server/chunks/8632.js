"use strict";
exports.id = 8632;
exports.ids = [8632];
exports.modules = {

/***/ 8632:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgWhatsAppLarge = function SvgWhatsAppLarge(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 36,
    height: 36,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M35.121 17.56c0 9.7-7.862 17.561-17.56 17.561C7.862 35.121 0 27.26 0 17.561 0 7.862 7.862 0 17.56 0c9.7 0 17.561 7.862 17.561 17.56ZM8.655 23.01l-.113.41-1.209 4.368 4.369-1.209.41-.113.365.216a11.407 11.407 0 0 0 5.814 1.586c6.306 0 11.44-5.133 11.44-11.44 0-6.307-5.134-11.438-11.438-11.438-6.307 0-11.44 5.131-11.44 11.439 0 2.056.549 4.057 1.586 5.815l.216.366Zm-1.633 5.902-1.123.31.31-1.123 1.37-4.947a12.42 12.42 0 0 1-1.725-6.323c0-6.86 5.58-12.439 12.44-12.439 6.855 0 12.437 5.579 12.437 12.439 0 6.858-5.582 12.439-12.44 12.439-2.237 0-4.412-.596-6.323-1.725l-4.946 1.369Zm8.844-9.657c3.293 3.292 6.902 4.179 6.932 4.159a5.384 5.384 0 0 0 1.387-1.386c.38-.57.693-1.387.693-1.387l-3.466-2.08-1.733 1.04s-.883-.536-2.08-1.732c-1.04-1.04-2.08-2.426-2.08-2.426l1.04-1.733-2.079-3.466c-.231 0-.693 0-1.733 1.04-.707.706-1.04 1.386-1.04 1.386s.968 3.393 4.16 6.585Z",
    fill: "#23D16A"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgWhatsAppLarge);

/***/ })

};
;