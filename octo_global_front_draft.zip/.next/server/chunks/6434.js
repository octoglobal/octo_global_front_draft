"use strict";
exports.id = 6434;
exports.ids = [6434];
exports.modules = {

/***/ 6434:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _forms_LoginForm_LoginForm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6231);
/* harmony import */ var _layout_AuthFormLayout_AuthFormLayout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4963);
/* harmony import */ var _components_AnyPage_FormComponent_FormComponent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1839);
/* harmony import */ var _components_AnyPage_AuthFormPromt_LoginPromt_LoginPromt__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6139);
/* harmony import */ var _hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4763);
/* harmony import */ var _hooks_useSwipeableDrawerStore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2655);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(668);
/* harmony import */ var _src_UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2907);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_forms_LoginForm_LoginForm__WEBPACK_IMPORTED_MODULE_3__]);
_forms_LoginForm_LoginForm__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const Login = ()=>{
    const { pushTo  } = (0,_hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_7__/* .useCustomRouter */ .c)();
    const { LoginFormWrapperBox , MarginBoxMUI ,  } = (0,_style__WEBPACK_IMPORTED_MODULE_9__/* .useLoginFormStyle */ .$)();
    const handlerClickRefreshPass = ()=>{
        pushTo('/reset');
    };
    const handlerClickRegistr = ()=>{
        pushTo('/signup');
    };
    const isMobile = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)('(max-width: 499px)');
    const { toggleDrawer , toggleTab ,  } = (0,_hooks_useSwipeableDrawerStore__WEBPACK_IMPORTED_MODULE_8__/* .useSwipeableDrawerStore */ .h)();
    const onToggleMenu = ()=>{
        toggleDrawer();
        toggleTab('login');
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isMobile) {
            onToggleMenu();
        }
    }, [
        isMobile
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: !isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_AuthFormLayout_AuthFormLayout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_AnyPage_FormComponent_FormComponent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    title: "Вход",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LoginFormWrapperBox, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_forms_LoginForm_LoginForm__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_AuthFormPromt_LoginPromt_LoginPromt__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            onClickRefreshPassword: handlerClickRefreshPass,
                            onClickRegistr: handlerClickRegistr
                        })
                    ]
                })
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MarginBoxMUI, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                onClick: onToggleMenu,
                children: "Открыть форму входа"
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Login);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 668:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ useLoginFormStyle)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useLoginFormStyle = ()=>{
    const LoginFormWrapperBox = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            width: '326px'
        })
    );
    const LoginFormFooterInfoBox = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'column',
            marginBottom: '15px',
            fontStyle: 'normal',
            fontWeight: '300',
            fontSize: '12px',
            lineHeight: '14px',
            color: '#000000'
        })
    );
    const LoginFormLink = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            fontWeight: '300',
            fontSize: '12px',
            lineHeight: '14px',
            color: '#234A82',
            display: 'inline-block'
        })
    );
    const LoginFormInput = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            width: '100%',
            marginBottom: '20px',
            height: '40px',
            background: '#FFFFFF',
            border: '1px solid #DFE4EC',
            boxSizing: 'border-box',
            boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.03)',
            '& .MuiOutlinedInput-root, .MuiFormControl-root': {
                width: '100%',
                height: '40px',
                borderRadius: '0px'
            },
            '& .MuiInputLabel-root': {
                top: '-8px'
            },
            '& input': {
                width: '100%'
            }
        })
    );
    const LoginFormButton = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            background: '#234A82',
            opacity: '0.8',
            borderRadius: '3px',
            marginBottom: '15px',
            height: '40px',
            display: 'flex',
            '& button': {
                width: '100%',
                fontStyle: 'normal',
                fontWeight: '300',
                fontSize: '14px',
                lineHeight: '16px',
                color: '#FFFFFF',
                textAlign: 'center'
            }
        })
    );
    const MarginBoxMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            marginTop: '150px'
        })
    );
    return {
        LoginFormWrapperBox,
        LoginFormFooterInfoBox,
        LoginFormLink,
        LoginFormInput,
        LoginFormButton,
        MarginBoxMUI
    };
};


/***/ }),

/***/ 4963:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AuthFormLayout_AuthFormLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/layout/AuthFormLayout/style.ts

const useAuthFormLayoutStyle = ()=>{
    const AuthFormLayoutBoxUI = (0,material_.styled)('div')(({ theme  })=>({
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            width: '100%',
            height: 'auto',
            padding: '130px 0 100px'
        })
    );
    return {
        AuthFormLayoutBoxUI
    };
};

;// CONCATENATED MODULE: ./src/layout/AuthFormLayout/AuthFormLayout.tsx



const AuthFormLayout = ({ children  })=>{
    const { AuthFormLayoutBoxUI  } = useAuthFormLayoutStyle();
    return(/*#__PURE__*/ jsx_runtime_.jsx(AuthFormLayoutBoxUI, {
        children: children
    }));
};
/* harmony default export */ const AuthFormLayout_AuthFormLayout = (/*#__PURE__*/external_react_default().memo(AuthFormLayout));


/***/ })

};
;