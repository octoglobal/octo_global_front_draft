"use strict";
exports.id = 2969;
exports.ids = [2969];
exports.modules = {

/***/ 2907:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ButtonUI_ButtonUI)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/hooks/useMedia.ts
var useMedia = __webpack_require__(2447);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/UI/UIComponents/ButtonUI/style.ts

const useButtonUIStyle = ()=>{
    const CustonButtonUI = (0,material_.styled)(material_.Button)(()=>({
            color: '#FFFFFF',
            '&: hover': {
                background: '#274D82'
            },
            '& .Mui-disabled': {
                color: '#FFFFFF',
                background: '#274D82',
                opacity: '0.8'
            }
        })
    );
    const ButtonStyle = {
        background: '#274D82',
        opacity: '1',
        borderRadius: '5px',
        marginBottom: '15px',
        height: '40px',
        display: 'flex',
        width: '100%',
        fontStyle: 'normal',
        fontWeight: '300',
        fontSize: '14px',
        lineHeight: '16px',
        color: '#FFFFFF',
        textAlign: 'center',
        textTransform: 'none'
    };
    const ButtonMobileStyle = {
        ...ButtonStyle,
        height: '32px'
    };
    return {
        CustonButtonUI,
        ButtonStyle,
        ButtonMobileStyle
    };
};

;// CONCATENATED MODULE: ./src/UI/UIComponents/ButtonUI/ButtonUI.tsx




const ButtonUI = (props)=>{
    const { isMobile  } = (0,useMedia/* useMobile */.XA)();
    const buttonStyle = (0,external_react_.useMemo)(()=>{
        const propsStyles = (props === null || props === void 0 ? void 0 : props.sx) ? props.sx : {};
        const adaptiveStyles = isMobile ? ButtonMobileStyle : ButtonStyle;
        return {
            ...adaptiveStyles,
            ...propsStyles
        };
    }, [
        isMobile
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(CustonButtonUI, {
        ...props,
        sx: buttonStyle,
        children: props.children
    }));
};
const { CustonButtonUI , ButtonStyle , ButtonMobileStyle  } = useButtonUIStyle();
/* harmony default export */ const ButtonUI_ButtonUI = (ButtonUI);


/***/ }),

/***/ 2447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y4": () => (/* binding */ useTouchDevice),
/* harmony export */   "FJ": () => (/* binding */ useTablet),
/* harmony export */   "Ap": () => (/* binding */ useCustom800),
/* harmony export */   "XA": () => (/* binding */ useMobile),
/* harmony export */   "ZB": () => (/* binding */ useCustomSize)
/* harmony export */ });
/* unused harmony exports useDesktop, useCustom960 */
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useDesktop = ()=>{
    const isDesktop = useMediaQuery('(max-width: 1400px) and (min-width: 1200px)');
    return {
        isDesktop
    };
};
const useTouchDevice = ()=>{
    const isTouchDevice = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)('(max-width: 1024px)');
    return {
        isTouchDevice
    };
};
const useTablet = ()=>{
    const isTablet = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)('(max-width: 1024px) and (min-width: 500px)');
    return {
        isTablet
    };
};
const useCustom800 = ()=>{
    const isCustom800 = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)('(max-width: 800px)');
    return {
        isCustom800
    };
};
const useCustom960 = ()=>{
    const isCustom960 = useMediaQuery('(max-width: 960px)');
    return {
        isCustom960
    };
};
const useMobile = ()=>{
    const isMobile = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)('(max-width: 600px)');
    return {
        isMobile
    };
};
const useCustomSize = (maxWidth = 0, minWidth = 0)=>{
    if (!minWidth) return {
        isCustomSize: (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)(`(max-width: ${maxWidth}px)`)
    };
    if (!maxWidth) return {
        isCustomSize: (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)(`(min-width: ${minWidth}px)`)
    };
    const isCustomSize = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.useMediaQuery)(`(max-width: ${maxWidth}px) and (min-width: ${minWidth}px)`);
    return {
        isCustomSize
    };
};


/***/ }),

/***/ 990:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);



const HeaderLayout = ({ children , title ='OCTO-GLOBAL'  })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: title
                })
            }),
            children
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(HeaderLayout));


/***/ })

};
;