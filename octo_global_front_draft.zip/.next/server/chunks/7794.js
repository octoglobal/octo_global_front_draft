"use strict";
exports.id = 7794;
exports.ids = [7794];
exports.modules = {

/***/ 7794:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _rect, _rect2, _rect3, _rect4, _rect5, _rect6, _rect7;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgBasket = function SvgBasket(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _rect || (_rect = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    x: 5.625,
    y: 5.688,
    width: 11.75,
    height: 16,
    rx: 1.5,
    stroke: "#274D82"
  })), _rect2 || (_rect2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    x: 3,
    y: 6,
    width: 17,
    height: 1,
    rx: 0.5,
    fill: "#274D82"
  })), _rect3 || (_rect3 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 15,
    height: 2,
    rx: 1,
    transform: "matrix(1 0 0 -1 4 7)",
    fill: "#274D82"
  })), _rect4 || (_rect4 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    x: 7.75,
    y: 2.5,
    width: 7.5,
    height: 3.25,
    rx: 0.5,
    stroke: "#274D82"
  })), _rect5 || (_rect5 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    x: 8,
    y: 8,
    width: 1,
    height: 11,
    rx: 0.5,
    fill: "#274D82"
  })), _rect6 || (_rect6 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    x: 11,
    y: 8,
    width: 1,
    height: 11,
    rx: 0.5,
    fill: "#274D82"
  })), _rect7 || (_rect7 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    x: 14,
    y: 8,
    width: 1,
    height: 11,
    rx: 0.5,
    fill: "#274D82"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgBasket);

/***/ })

};
;