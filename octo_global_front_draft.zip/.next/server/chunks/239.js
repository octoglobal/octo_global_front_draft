"use strict";
exports.id = 239;
exports.ids = [239];
exports.modules = {

/***/ 2319:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path, _path2;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgInfo = function SvgInfo(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    viewBox: "0 0 34 34",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M34 17c0 9.389-7.611 17-17 17S0 26.389 0 17 7.611 0 17 0s17 7.611 17 17Z",
    fill: "#C4C4C4"
  })), _path2 || (_path2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M19.074 12.32V25h-3.668V12.32h3.668Zm-3.89-3.28c0-.532.187-.966.562-1.302.375-.343.867-.515 1.477-.515.609 0 1.101.172 1.476.515.383.336.574.77.574 1.301 0 .524-.191.957-.574 1.3-.375.337-.867.505-1.476.505-.61 0-1.102-.168-1.477-.504a1.689 1.689 0 0 1-.562-1.3Z",
    fill: "#fff"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgInfo);

/***/ }),

/***/ 239:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3210);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(257);
/* harmony import */ var _useEuroExchange__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7609);
/* harmony import */ var UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8595);
/* harmony import */ var UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2907);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5641);
/* harmony import */ var _hooks_useMedia__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2447);
/* harmony import */ var _UIIcon_EditPencil_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7282);
/* harmony import */ var _UIIcon_Info_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2319);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7229);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5371);
/* harmony import */ var _mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_5__, react_hook_form__WEBPACK_IMPORTED_MODULE_7__]);
([UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_5__, react_hook_form__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const EuroExchange = ()=>{
    const { isMobile  } = (0,_hooks_useMedia__WEBPACK_IMPORTED_MODULE_8__/* .useMobile */ .XA)();
    const { isAdmin ,  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_3__/* .useUserStore */ .L)();
    const { setEditMode , isEditMode , onSubmitEuroPrice , value , open , handleTooltipClose , handleTooltipOpen ,  } = (0,_useEuroExchange__WEBPACK_IMPORTED_MODULE_4__/* .useEuroExchange */ .X)();
    const { handleSubmit , control ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_7__.useForm)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ContainerMUI, {
        admin: isAdmin,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormMUI, {
            admin: isAdmin,
            onSubmit: handleSubmit(onSubmitEuroPrice),
            children: isAdmin ? isEditMode ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BlockWrap, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LabelMUI, {
                                admin: isAdmin,
                                onClick: ()=>{
                                    setEditMode(false);
                                },
                                children: "Курс евро: €  "
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextFieldEuroMUI, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    controller: {
                                        name: 'rate',
                                        control,
                                        defaultValue: +value
                                    },
                                    inputProps: {
                                        name: 'rate',
                                        type: 'number',
                                        autoFocus: true,
                                        inputProps: {
                                            step: 'any'
                                        }
                                    }
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        type: "submit",
                        style: FormButtonUI(isMobile),
                        children: "Сохранить"
                    })
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BlockWrap, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LabelMUI, {
                            admin: isAdmin,
                            children: "Курс евро: €  "
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ParagraphMUI, {
                            admin: isAdmin,
                            children: value
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IcoMUI, {
                            onClick: ()=>{
                                setEditMode(true);
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_EditPencil_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {})
                        })
                    ]
                })
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(InfoBlockMUI, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LabelMUI, {
                        admin: isAdmin,
                        children: "Курс евро: €  "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ParagraphMUI, {
                        admin: isAdmin,
                        children: value
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ClickAwayListener__WEBPACK_IMPORTED_MODULE_13___default()), {
                        onClickAway: handleTooltipClose,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LightTooltip, {
                                onClose: handleTooltipClose,
                                open: open,
                                disableFocusListener: true,
                                disableHoverListener: true,
                                disableTouchListener: true,
                                PopperProps: {
                                    disablePortal: true
                                },
                                title: "По данному курсу евро Вы можете зачислить валюту на свой лич\xadный счет в Octo Glob\xadal.",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IconMUI, {
                                    onClick: handleTooltipOpen,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_Info_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                                })
                            })
                        })
                    })
                ]
            })
        })
    }));
};
const { ContainerMUI , ParagraphMUI , LabelMUI , FormMUI , FormButtonUI , IcoMUI , IconMUI , TextFieldEuroMUI , BlockWrap , InfoBlockMUI ,  } = (0,_style__WEBPACK_IMPORTED_MODULE_2__/* .useEuroExchangeStyles */ .n)();
const LightTooltip = (0,_mui_material__WEBPACK_IMPORTED_MODULE_11__.styled)(({ className , ...props })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12___default()), {
        ...props,
        classes: {
            popper: className
        }
    })
)(({ theme  })=>({
        [`& .${_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_12__.tooltipClasses.tooltip}`]: {
            width: 165,
            backgroundColor: theme.palette.common.white,
            fontWeight: 300,
            boxShadow: theme.shadows[1],
            fontSize: 12,
            padding: '25px 22px 20px 24px',
            textAlign: 'center',
            color: '#3A3A3A',
            lineHeight: '14px',
            [theme.breakpoints.down(500)]: {
                width: 140,
                padding: '8px 11px 9px 11px'
            }
        }
    })
);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(EuroExchange));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3210:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ useEuroExchangeStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useEuroExchangeStyles = ()=>{
    const ContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div', {
        shouldForwardProp: (prop)=>prop !== 'admin'
    })(({ theme , admin =false  })=>({
            display: 'flex',
            [theme.breakpoints.down(600)]: {
                display: 'flex',
                justifyContent: admin ? 'flex-start' : 'center',
                marginBottom: admin ? 20 : 0,
                height: 30
            }
        })
    );
    const BlockWrap = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex',
            alignItems: 'center'
        })
    );
    const ParagraphMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('p', {
        shouldForwardProp: (prop)=>prop !== 'admin'
    })(({ theme , admin =false  })=>({
            fontSize: 20,
            fontWeight: 300,
            [theme.breakpoints.down(500)]: {
                fontSize: admin ? '16px' : '12px'
            }
        })
    );
    const LabelMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('label', {
        shouldForwardProp: (prop)=>prop !== 'admin'
    })(({ theme , admin =false  })=>({
            fontSize: 20,
            fontWeight: 300,
            marginRight: 5,
            [theme.breakpoints.down(500)]: {
                fontSize: admin ? '16px' : '12px'
            }
        })
    );
    const FormMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('form', {
        shouldForwardProp: (prop)=>prop !== 'admin'
    })(({ theme , admin =false  })=>({
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            [theme.breakpoints.down(500)]: {
                flexDirection: 'row',
                justifyContent: 'space-between',
                width: admin ? '100%' : null
            }
        })
    );
    const FormButtonUI = (isMobile)=>{
        return {
            width: '107px',
            height: '32px',
            backgroundColor: 'rgba(39, 77, 130, 0.8)',
            margin: isMobile ? '0 0' : '12px 0 0 0'
        };
    };
    const IcoMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex'
        })
    );
    const IconMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            marginLeft: 10,
            display: 'flex',
            '&>svg': {
                width: 34,
                height: 34
            },
            [theme.breakpoints.down(500)]: {
                '&>svg': {
                    width: 16,
                    height: 16
                }
            }
        })
    );
    const TextFieldEuroMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            display: 'flex',
            width: 74,
            height: 27,
            alignItems: 'cneter',
            justifyContent: 'center',
            [theme.breakpoints.down(500)]: {
                width: 50,
                '& > div': {
                    '& > div': {
                        height: 27,
                        '& > div': {
                            // height: 27,
                            '& > input[type=number]': {
                                '-moz-appearance': 'textfield'
                            },
                            '& > input::-webkit-outer-spin-button, input::-webkit-inner-spin-button': {
                                '-webkit-appearance': 'none'
                            },
                            '& > input': {
                                height: 27,
                                // height: '10px !important',
                                // margin: '0px 0px',
                                padding: '0px 3px',
                                fontWeight: 300,
                                fontSize: '16px'
                            },
                            '& > fieldset': {
                                border: 'none',
                                borderBottom: '1px solid #000000',
                                borderRadius: 0
                            }
                        }
                    }
                }
            },
            '& > div': {
                '& > div': {
                    height: 27,
                    '& > div': {
                        // height: 27,
                        '& > input[type=number]': {
                            '-moz-appearance': 'textfield'
                        },
                        '& > input::-webkit-outer-spin-button, input::-webkit-inner-spin-button': {
                            '-webkit-appearance': 'none'
                        },
                        '& > input': {
                            height: 27,
                            // height: '10px !important',
                            // margin: '0px 0px',
                            padding: '0px 3px',
                            fontWeight: 300
                        }
                    }
                }
            }
        })
    );
    const InfoBlockMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex',
            alignItems: 'center',
            '&>p': {
                paddingTop: 5
            },
            '&>label': {
                paddingTop: 5
            }
        })
    );
    return {
        ContainerMUI,
        ParagraphMUI,
        LabelMUI,
        FormMUI,
        FormButtonUI,
        IcoMUI,
        IconMUI,
        TextFieldEuroMUI,
        BlockWrap,
        InfoBlockMUI
    };
};


/***/ }),

/***/ 7609:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useEuroExchange)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4730);
/* harmony import */ var _store_reducers_euroExchangeRate_asyncThunk_euroApi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3942);



const useEuroExchange = ()=>{
    const { 0: open , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { 0: isEditMode , 1: setEditMode  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppDispatch */ .T)();
    const { value: value1  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .C)((state)=>state.euroSlice
    );
    const handleTooltipClose = ()=>{
        setOpen(false);
    };
    const handleTooltipOpen = ()=>{
        setOpen((prev)=>!prev
        );
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        dispatch((0,_store_reducers_euroExchangeRate_asyncThunk_euroApi__WEBPACK_IMPORTED_MODULE_2__/* .fetchEuroRate */ .e)());
    }, []);
    const onSubmitEuroPrice = (data)=>{
        const value = data.rate * 100;
        dispatch((0,_store_reducers_euroExchangeRate_asyncThunk_euroApi__WEBPACK_IMPORTED_MODULE_2__/* .fetchSetEuroRate */ .y)({
            currency: 'EUR',
            value: +value.toFixed(2)
        }));
        setEditMode(false);
    };
    return {
        isEditMode,
        setEditMode,
        onSubmitEuroPrice,
        value: value1,
        open,
        handleTooltipClose,
        handleTooltipOpen
    };
};


/***/ }),

/***/ 3942:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ fetchEuroRate),
/* harmony export */   "y": () => (/* binding */ fetchSetEuroRate)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7355);


const fetchEuroRate = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('eutoSlice/getRate', async (_, { rejectWithValue  })=>{
    try {
        const res = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get('/exchange_rate');
        if (res.status === 200) {
            return res;
        }
    } catch (error) {
        return rejectWithValue('ошибка получениея евро рейт');
    }
});
const fetchSetEuroRate = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('eutoSlice/setRate', async (data, { rejectWithValue  })=>{
    try {
        const res = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.post */ .N.post('/admin/exchange_rate', data);
        if (res.status === 200) {
            return data.value;
        }
    } catch (error) {
        return rejectWithValue('ошибка set евро рейт');
    }
});


/***/ })

};
;