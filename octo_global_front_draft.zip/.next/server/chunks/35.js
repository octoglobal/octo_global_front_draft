"use strict";
exports.id = 35;
exports.ids = [35];
exports.modules = {

/***/ 1211:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ DropDownUI_DropDownUI)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: ./src/UI/UIIcon/DropDownIcon.svg
var _circle, _circle2, _circle3;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgDropDownIcon = function SvgDropDownIcon(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 7,
    height: 27,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _circle || (_circle = /*#__PURE__*/external_react_.createElement("circle", {
    cx: 3.5,
    cy: 3.5,
    r: 3.5,
    fill: "#C4C4C4"
  })), _circle2 || (_circle2 = /*#__PURE__*/external_react_.createElement("circle", {
    cx: 3.5,
    cy: 13.5,
    r: 3.5,
    fill: "#C4C4C4"
  })), _circle3 || (_circle3 = /*#__PURE__*/external_react_.createElement("circle", {
    cx: 3.5,
    cy: 23.5,
    r: 3.5,
    fill: "#C4C4C4"
  })));
};

/* harmony default export */ const DropDownIcon = (SvgDropDownIcon);
;// CONCATENATED MODULE: ./src/UI/UIIcon/SmallMenuIcon.svg
var SmallMenuIcon_circle, SmallMenuIcon_circle2, SmallMenuIcon_circle3;

function SmallMenuIcon_extends() { SmallMenuIcon_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return SmallMenuIcon_extends.apply(this, arguments); }



var SvgSmallMenuIcon = function SvgSmallMenuIcon(props) {
  return /*#__PURE__*/external_react_.createElement("svg", SmallMenuIcon_extends({
    width: 5,
    height: 16,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), SmallMenuIcon_circle || (SmallMenuIcon_circle = /*#__PURE__*/external_react_.createElement("circle", {
    r: 2.074,
    transform: "matrix(-1 0 0 1 2.074 2.074)",
    fill: "#C4C4C4"
  })), SmallMenuIcon_circle2 || (SmallMenuIcon_circle2 = /*#__PURE__*/external_react_.createElement("circle", {
    r: 2.074,
    transform: "matrix(-1 0 0 1 2.074 8)",
    fill: "#C4C4C4"
  })), SmallMenuIcon_circle3 || (SmallMenuIcon_circle3 = /*#__PURE__*/external_react_.createElement("circle", {
    r: 2.074,
    transform: "matrix(-1 0 0 1 2.074 13.926)",
    fill: "#C4C4C4"
  })));
};

/* harmony default export */ const SmallMenuIcon = (SvgSmallMenuIcon);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/UI/UIComponents/DropDownUI/style.ts

const useDropDownStyles = ()=>{
    const IconButtonMUI = (0,material_.styled)(material_.Button)(()=>({
            border: 0,
            padding: '3px 5px',
            minWidth: 'auto'
        })
    );
    const OverlayModalMUI = (0,material_.styled)(material_.Dialog)(()=>({
            opacity: 0,
            zIndex: 1
        })
    );
    const ButtonContainerMUI = (0,material_.styled)('div')(({ theme  })=>({
            position: 'absolute',
            right: 0,
            top: '40px',
            zIndex: 2,
            padding: '5px 0',
            width: '176px',
            backgroundColor: '#FFFFFF',
            borderRadius: '8px',
            boxShadow: '0px -4px 4px rgba(0, 0, 0, 0.1), 0px 4px 4px rgba(0, 0, 0, 0.15)',
            [theme.breakpoints.down(769)]: {
                width: '150px'
            }
        })
    );
    const ContainerMUI = (0,material_.styled)('div')(()=>({
            position: 'relative'
        })
    );
    return {
        ContainerMUI,
        IconButtonMUI,
        OverlayModalMUI,
        ButtonContainerMUI
    };
};

;// CONCATENATED MODULE: ./src/UI/UIComponents/DropDownUI/useDropDownUI.ts


const useDropDownUI = (externalOpen, setExternalOpen)=>{
    const { 0: isOpen , 1: setIsOpen  } = (0,external_react_.useState)(false);
    const isMobile = (0,material_.useMediaQuery)('(max-width: 501px)');
    const handleToggleOpen = ()=>{
        setIsOpen((prevState)=>!prevState
        );
        if (externalOpen && setExternalOpen) {
            setExternalOpen(false);
        }
    };
    (0,external_react_.useEffect)(()=>{
        if (externalOpen === undefined) return;
        if (externalOpen) {
            setIsOpen(true);
        } else {
            setIsOpen(false);
        }
    }, [
        externalOpen
    ]);
    return {
        isOpen,
        isMobile,
        handleToggleOpen
    };
};

;// CONCATENATED MODULE: ./src/UI/UIComponents/DropDownUI/DropDownItem/style.ts

const useDropDownItemStyles = ()=>{
    const ButtonMUI = (0,material_.styled)(material_.Button)(({ theme  })=>({
            minWidth: 'auto',
            width: '100%',
            textTransform: 'none',
            fontSize: '18px',
            lineHeight: '24px',
            fontWeight: 300,
            color: '#000000',
            justifyContent: 'flex-start',
            [theme.breakpoints.down(769)]: {
                fontSize: '14px',
                lineHeight: '16px'
            }
        })
    );
    return {
        ButtonMUI
    };
};

;// CONCATENATED MODULE: ./src/UI/UIComponents/DropDownUI/DropDownItem/DropDownItem.tsx



const DropDownItem = ({ title , onClick , handleToggleOpen , itemId  })=>{
    const handleClickItem = ()=>{
        onClick(itemId);
        setTimeout(()=>{
            handleToggleOpen();
        }, 300);
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(ButtonMUI, {
        onClick: handleClickItem,
        children: title
    }));
};
const { ButtonMUI ,  } = useDropDownItemStyles();
/* harmony default export */ const DropDownItem_DropDownItem = (/*#__PURE__*/external_react_default().memo(DropDownItem));

;// CONCATENATED MODULE: ./src/UI/UIComponents/DropDownUI/DropDownUI.tsx







const DropDownUI = ({ externalOpen =undefined , setExternalOpen , dropItems , itemId , containerStyles ={}  })=>{
    const { isOpen , isMobile , handleToggleOpen  } = useDropDownUI(externalOpen, setExternalOpen);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ContainerMUI, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(IconButtonMUI, {
                color: "secondary",
                onClick: handleToggleOpen,
                disableTouchRipple: true,
                children: isMobile ? /*#__PURE__*/ jsx_runtime_.jsx(SmallMenuIcon, {}) : /*#__PURE__*/ jsx_runtime_.jsx(DropDownIcon, {})
            }),
            isOpen && /*#__PURE__*/ jsx_runtime_.jsx(ButtonContainerMUI, {
                sx: containerStyles,
                children: dropItems.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(DropDownItem_DropDownItem, {
                        title: item.title,
                        onClick: item.onClick,
                        itemId: itemId,
                        handleToggleOpen: handleToggleOpen
                    }, `${index}${item.title}`)
                )
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(OverlayModalMUI, {
                open: isOpen,
                disableScrollLock: true,
                onClick: handleToggleOpen,
                onClose: handleToggleOpen
            })
        ]
    }));
};
const { ContainerMUI , IconButtonMUI , OverlayModalMUI , ButtonContainerMUI ,  } = useDropDownStyles();
/* harmony default export */ const DropDownUI_DropDownUI = (/*#__PURE__*/external_react_default().memo(DropDownUI));


/***/ }),

/***/ 5783:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AccountSearchHint_AccountSearchHint)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/Account/AccountSearch/AccountSearchHint/style.ts

const useAccountSearchHintStyles = ()=>{
    const ContainerMUI = (0,material_.styled)('div')(({ theme  })=>({
            display: 'flex',
            justifyContent: 'space-between',
            paddingRight: '69px',
            '& > div': {
                fontSize: '20px',
                lineHeight: '24px',
                fontWeight: 300,
                [theme.breakpoints.down(770)]: {
                    fontSize: '16px'
                }
            }
        })
    );
    const HintItemMUI = (0,material_.styled)('div')(()=>({
            fontSize: '20px',
            lineHeight: '24px',
            fontWeight: 300
        })
    );
    const HintItemuserAreaIdMUI = (0,material_.styled)('div')(({ theme  })=>({
            width: '10%',
            [theme.breakpoints.down(770)]: {
                width: '100%',
                gridArea: 'a'
            }
        })
    );
    const HintItemEmailMUI = (0,material_.styled)('div')(({ theme  })=>({
            width: '28%',
            wordWrap: 'break-word',
            overflowWrap: 'break-word',
            [theme.breakpoints.down(770)]: {
                width: '100%',
                gridArea: 'd'
            }
        })
    );
    const HintItemOrderMUI = (0,material_.styled)('div')(({ theme  })=>({
            width: '8%',
            textTransform: 'uppercase',
            [theme.breakpoints.down(770)]: {
                width: '100%',
                gridArea: 'c',
                display: 'flex',
                justifyContent: 'end',
                alignItems: 'end'
            }
        })
    );
    const HintItemTrackMUI = (0,material_.styled)('div')(({ theme  })=>({
            width: '18%',
            textTransform: 'uppercase',
            overflowX: 'auto',
            [theme.breakpoints.down(770)]: {
                width: '100%',
                gridArea: 'b'
            }
        })
    );
    const HintItemNameMUI = (0,material_.styled)('div')(({ theme  })=>({
            width: '28%',
            textOverflow: 'ellipsis',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            [theme.breakpoints.down(770)]: {
                width: '100%',
                gridArea: 'e'
            }
        })
    );
    const PMUI = (0,material_.styled)('div')(({ theme  })=>({
            [theme.breakpoints.down(400)]: {
                fontSize: '15px'
            }
        })
    );
    return {
        HintItemMUI,
        ContainerMUI,
        HintItemuserAreaIdMUI,
        HintItemEmailMUI,
        HintItemOrderMUI,
        HintItemTrackMUI,
        HintItemNameMUI,
        PMUI
    };
};

;// CONCATENATED MODULE: ./src/components/Account/AccountSearch/AccountSearchHint/AccountSearchHint.tsx



const AccountSearchHint = ({ hint , markText , searchValue , isCustomSize  })=>{
    var ref, ref1, ref2;
    const trackNumber = markText((ref = hint.trackNumber) === null || ref === void 0 ? void 0 : ref.toString(), searchValue);
    const ordernumver = markText((ref1 = hint.orderNumber) === null || ref1 === void 0 ? void 0 : ref1.toString(), searchValue);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ContainerMUI, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(HintItemuserAreaIdMUI, {
                children: [
                    isCustomSize ? 'id' : null,
                    " ",
                    markText((ref2 = hint.userAreaId) === null || ref2 === void 0 ? void 0 : ref2.toString(), searchValue)
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(HintItemEmailMUI, {
                children: markText(hint.email, searchValue)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(HintItemOrderMUI, {
                children: isCustomSize ? ordernumver ? ordernumver : /*#__PURE__*/ jsx_runtime_.jsx(PMUI, {
                    children: "нет заказа"
                }) : ordernumver
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(HintItemTrackMUI, {
                children: isCustomSize ? trackNumber ? trackNumber : /*#__PURE__*/ jsx_runtime_.jsx(PMUI, {
                    children: "нет номера"
                }) : trackNumber
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(HintItemNameMUI, {
                children: markText(hint.name, searchValue)
            })
        ]
    }));
};
const { ContainerMUI , HintItemuserAreaIdMUI , HintItemEmailMUI , HintItemOrderMUI , HintItemTrackMUI , HintItemNameMUI , PMUI  } = useAccountSearchHintStyles();
/* harmony default export */ const AccountSearchHint_AccountSearchHint = (/*#__PURE__*/external_react_default().memo(AccountSearchHint));


/***/ }),

/***/ 2341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AccountSearchListTitle_AccountSearchListTitle)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/Account/AccountSearch/AccountSearchListTitle/style.ts

const useAccountSearchListTitleStyles = ()=>{
    const ContainerMUI = (0,material_.styled)('div')(({ theme  })=>({
            padding: '15px 25px 0',
            marginBottom: '13px',
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            textAlign: 'left',
            paddingRight: '69px',
            '& > div': {
                fontWeight: 400,
                fontSize: '20px',
                lineHeight: '24px',
                color: '#C4C4C4'
            },
            [theme.breakpoints.down(770)]: {
                display: 'none'
            }
        })
    );
    const ItemMUI = (0,material_.styled)('div')(()=>({
        })
    );
    const ItemIdMUI = (0,material_.styled)('div')(()=>({
            width: '10%'
        })
    );
    const ItemEmailMUI = (0,material_.styled)('div')(()=>({
            width: '28%'
        })
    );
    const ItemOrderMUI = (0,material_.styled)('div')(()=>({
            width: '8%'
        })
    );
    const ItemTrackMUI = (0,material_.styled)('div')(()=>({
            width: '18%'
        })
    );
    const ItemNameMUI = (0,material_.styled)('div')(()=>({
            width: '28%'
        })
    );
    return {
        ItemMUI,
        ContainerMUI,
        ItemIdMUI,
        ItemEmailMUI,
        ItemOrderMUI,
        ItemTrackMUI,
        ItemNameMUI
    };
};

;// CONCATENATED MODULE: ./src/components/Account/AccountSearch/AccountSearchListTitle/AccountSearchListTitle.tsx



const AccountSearchListTitle = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ContainerMUI, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ItemIdMUI, {
                children: "User ID"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ItemEmailMUI, {
                children: "E-Mail"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ItemOrderMUI, {
                children: "Order"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ItemTrackMUI, {
                children: "Track Number"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ItemNameMUI, {
                children: "Name"
            })
        ]
    }));
};
const { ContainerMUI , ItemIdMUI , ItemEmailMUI , ItemOrderMUI , ItemTrackMUI , ItemNameMUI  } = useAccountSearchListTitleStyles();
/* harmony default export */ const AccountSearchListTitle_AccountSearchListTitle = (/*#__PURE__*/external_react_default().memo(AccountSearchListTitle));


/***/ }),

/***/ 35:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_AnyPage_CategorySearch_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8802);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _components_AnyPage_CategorySearch_CategorySearchHints_CategorySearchHints__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6457);
/* harmony import */ var _components_AnyPage_CategorySearch_useCategorySearch__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9294);
/* harmony import */ var _components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(239);
/* harmony import */ var UI_UIComponents_DropDownUI_DropDownUI__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1211);
/* harmony import */ var UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2907);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _components_AnyPage_CategorySearch_CategorySearchHints_CategorySearchHints__WEBPACK_IMPORTED_MODULE_4__, _components_AnyPage_CategorySearch_useCategorySearch__WEBPACK_IMPORTED_MODULE_5__, _components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_6__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _components_AnyPage_CategorySearch_CategorySearchHints_CategorySearchHints__WEBPACK_IMPORTED_MODULE_4__, _components_AnyPage_CategorySearch_useCategorySearch__WEBPACK_IMPORTED_MODULE_5__, _components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const CategorySearch = ({ onSubmit , searchHints , handleKeyDownEnter , handleChangeSearchValue , component ='shops' ,  })=>{
    const { control , isMouseEnter , handleKeyDown , isVisibleHints , activeSuggestion , handleMouseEnter , handleMouseLeave , handleChangeFocus , handleClickHintItem , handleChangeActiveSuggestion , isAdmin , isMobile , isAccount , dropItems , dropDownOpen , setDropDownOpen , ButtonSxStyle ,  } = (0,_components_AnyPage_CategorySearch_useCategorySearch__WEBPACK_IMPORTED_MODULE_5__/* .useCategorySearch */ .Y)(onSubmit, searchHints, handleKeyDownEnter, handleChangeSearchValue, component);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(SearchContainerWrapperMUI, {
        children: [
            isAdmin && isAccount ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(EuroPositionMUI, {
                children: isMobile ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
            }) : null,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(SearchWrapperMUI, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SearchContainerMUI, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
                            name: "search",
                            control: control,
                            render: ({ field: { value , onChange  }  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextFieldSearch, {
                                    value: value,
                                    autoComplete: "off",
                                    onFocus: handleChangeFocus(true),
                                    onBlur: handleChangeFocus(false),
                                    onChange: onChange,
                                    onKeyDown: handleKeyDown,
                                    placeholder: "Поиск"
                                })
                        })
                    }),
                    isAdmin && isAccount ? isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        onClick: ()=>router.push('/account/orders/all-wait')
                        ,
                        sx: ButtonSxStyle,
                        children: "Показать все ожидаемые товары"
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DropDownWrapperMUI, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_DropDownUI_DropDownUI__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            itemId: 0,
                            externalOpen: dropDownOpen,
                            setExternalOpen: setDropDownOpen,
                            dropItems: dropItems,
                            containerStyles: {
                                width: 261
                            }
                        })
                    }) : null
                ]
            }),
            isVisibleHints && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_CategorySearch_CategorySearchHints_CategorySearchHints__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                component: component,
                hintsData: searchHints,
                isMouseEnter: isMouseEnter,
                isVisibleHints: isVisibleHints,
                activeSuggestion: activeSuggestion,
                handleMouseEnter: handleMouseEnter,
                handleMouseLeave: handleMouseLeave,
                handleClickHintItem: handleClickHintItem,
                handleChangeActiveSuggestion: handleChangeActiveSuggestion
            })
        ]
    }));
};
const { SearchContainerMUI , TextFieldSearch , SearchContainerWrapperMUI , EuroPositionMUI , DropDownWrapperMUI , SearchWrapperMUI ,  } = (0,_components_AnyPage_CategorySearch_style__WEBPACK_IMPORTED_MODULE_2__/* .useCategorySearchStyles */ .u)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(CategorySearch));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6457:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_AnyPage_CategorySearch_CategorySearchHints_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1284);
/* harmony import */ var _components_AnyPage_CategorySearch_CategorySearchHintsItem_CategorySearchHintsItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6622);
/* harmony import */ var _components_Account_AccountSearch_AccountSearchListTitle_AccountSearchListTitle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2341);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_AnyPage_CategorySearch_CategorySearchHintsItem_CategorySearchHintsItem__WEBPACK_IMPORTED_MODULE_3__]);
_components_AnyPage_CategorySearch_CategorySearchHintsItem_CategorySearchHintsItem__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const CategorySearchHints = ({ hintsData , isMouseEnter , isVisibleHints , handleMouseEnter , handleMouseLeave , activeSuggestion , handleClickHintItem , handleChangeActiveSuggestion , component ='shops'  })=>{
    const isAccount = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>component === 'account'
    , [
        component
    ]);
    return isVisibleHints ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ContainerMUI, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ListMUI, {
            onMouseEnter: handleMouseEnter,
            onMouseLeave: handleMouseLeave,
            children: [
                isAccount && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Account_AccountSearch_AccountSearchListTitle_AccountSearchListTitle__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                hintsData.map((hint, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_CategorySearch_CategorySearchHintsItem_CategorySearchHintsItem__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        url: hint.url,
                        title: hint.title,
                        hint: hint,
                        hintCount: index + 1,
                        active: index + 1 === activeSuggestion,
                        activeSuggestion: activeSuggestion,
                        isMouseEnter: isMouseEnter,
                        onMouseMove: handleMouseEnter,
                        handleClickHintItem: handleClickHintItem,
                        handleChangeActiveSuggestion: handleChangeActiveSuggestion,
                        isAccount: isAccount
                    }, hint.url)
                )
            ]
        })
    }) : null;
};
const { ListMUI , ContainerMUI  } = (0,_components_AnyPage_CategorySearch_CategorySearchHints_style__WEBPACK_IMPORTED_MODULE_2__/* .useCategorySearchHinstStyles */ .w)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(CategorySearchHints));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1284:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ useCategorySearchHinstStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useCategorySearchHinstStyles = ()=>{
    const ListMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('ul')(({ theme  })=>({
            borderRadius: '5px 5px 0px 0px',
            backgroundColor: '#FFFFFF',
            boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
            position: 'absolute',
            zIndex: 100,
            width: '100%',
            left: 0,
            top: 0,
            [theme.breakpoints.down(769)]: {
                maxHeight: 300,
                overflowY: 'auto'
            }
        })
    );
    const ContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            position: 'relative'
        })
    );
    return {
        ListMUI,
        ContainerMUI
    };
};


/***/ }),

/***/ 6622:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_AnyPage_CategorySearch_CategorySearchHintsItem_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8663);
/* harmony import */ var _components_AnyPage_CategorySearch_CategorySearchHintsItem_useCategorySearchHintsItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4902);
/* harmony import */ var _components_Account_AccountSearch_AccountSearchHint_AccountSearchHint__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5783);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5641);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_AnyPage_CategorySearch_CategorySearchHintsItem_useCategorySearchHintsItem__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_5__]);
([_components_AnyPage_CategorySearch_CategorySearchHintsItem_useCategorySearchHintsItem__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const CategorySearchHintsItem = ({ hint , title: title1 , active , hintCount , isMouseEnter , handleClickHintItem , handleChangeActiveSuggestion , isAccount =false ,  })=>{
    const { activeStyles , isCustomSize ,  } = (0,_components_AnyPage_CategorySearch_CategorySearchHintsItem_useCategorySearchHintsItem__WEBPACK_IMPORTED_MODULE_3__/* .useCategorySearchHintsItem */ .j)(active, title1, isMouseEnter);
    const searchValue1 = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_5__.useWatch)({
        name: 'search'
    });
    const editTextValue = (title, searchValue)=>{
        if (searchValue && title) {
            const indexSeparet = title.toLocaleLowerCase().indexOf(searchValue.toLocaleLowerCase());
            const BeforeMark = title.slice(0, indexSeparet);
            const result = title.toLocaleLowerCase().match(searchValue.toLocaleLowerCase());
            let markText;
            let AfterMark;
            if ((result === null || result === void 0 ? void 0 : result.index) !== null && (result === null || result === void 0 ? void 0 : result.index) !== undefined) {
                markText = title.toLocaleLowerCase().slice(result === null || result === void 0 ? void 0 : result.index, (result === null || result === void 0 ? void 0 : result.index) + searchValue.length);
                AfterMark = title.slice(indexSeparet + markText.length);
            } else {
                markText = '';
            }
            return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    BeforeMark,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextMarkMUI, {
                        children: markText
                    }),
                    AfterMark
                ]
            }));
        } else {
            return '';
        }
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ItemMUI, {
        children: isAccount ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LinkMUI, {
            type: "submit",
            sx: activeStyles,
            onMouseMove: handleChangeActiveSuggestion(hintCount),
            onMouseEnter: handleChangeActiveSuggestion(hintCount),
            onClick: handleClickHintItem(title1, hint),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Account_AccountSearch_AccountSearchHint_AccountSearchHint__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                hint: hint,
                markText: editTextValue,
                searchValue: searchValue1,
                isCustomSize: isCustomSize
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ButtonMUI, {
            type: "submit",
            sx: activeStyles,
            onMouseMove: handleChangeActiveSuggestion(hintCount),
            onMouseEnter: handleChangeActiveSuggestion(hintCount),
            onClick: handleClickHintItem(title1, hint),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ItemTextMUI, {
                children: editTextValue(title1, searchValue1)
            })
        })
    }));
};
const { ItemMUI , ButtonMUI , ItemTextMUI , TextMarkMUI , LinkMUI  } = (0,_components_AnyPage_CategorySearch_CategorySearchHintsItem_style__WEBPACK_IMPORTED_MODULE_2__/* .useCategorySearchHintsItemStyles */ .X)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(CategorySearchHintsItem));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8663:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useCategorySearchHintsItemStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useCategorySearchHintsItemStyles = ()=>{
    const ItemMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('li')(()=>({
            listStyle: 'none',
            width: '100%',
            textAlign: 'left'
        })
    );
    const ButtonMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('button')(({ theme  })=>({
            width: '100%',
            padding: '11px 0px 11px 25px',
            cursor: 'pointer',
            backgroundColor: 'transparent',
            border: 0,
            textAlign: 'left',
            [theme.breakpoints.down(770)]: {
                paddingBottom: 0,
                padding: '10px 10px 10px 10px',
                position: 'relative',
                '&:before': {
                    content: '""',
                    position: 'absolute',
                    width: '96%',
                    height: '1px',
                    backgroundColor: '#C4C4C4',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    bottom: 0
                }
            },
            '&>div': {
                [theme.breakpoints.down(770)]: {
                    display: 'grid',
                    gridTemplateAreas: `
				"a a b b c c"
				"d d d e e e"	`,
                    gridTemplateColumns: '1fr 1fr 1fr 1fr 1fr 1fr',
                    gap: 10,
                    padding: '0px 5px 5px 0px',
                    marginBottom: 0,
                    fontWeight: 300
                }
            }
        })
    );
    const LinkMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('a')(({ theme  })=>({
            width: '100%',
            padding: '11px 0px 11px 25px',
            cursor: 'pointer',
            backgroundColor: 'transparent',
            border: 0,
            textAlign: 'left',
            display: 'block',
            [theme.breakpoints.down(770)]: {
                paddingBottom: 0,
                padding: '10px 10px 10px 10px',
                position: 'relative',
                '&:before': {
                    content: '""',
                    position: 'absolute',
                    width: '96%',
                    height: '1px',
                    backgroundColor: '#C4C4C4',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    bottom: 0
                }
            },
            '&>div': {
                [theme.breakpoints.down(770)]: {
                    display: 'grid',
                    gridTemplateAreas: `
				"a a b b c c"
				"d d d e e e"	`,
                    gridTemplateColumns: '1fr 1fr 1fr 1fr 1fr 1fr',
                    gap: 10,
                    padding: '0px 5px 5px 0px',
                    marginBottom: 0,
                    fontWeight: 300
                }
            }
        })
    );
    const ItemTextMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('p')(({ theme  })=>({
            fontSize: '18px',
            lineHeight: '21px',
            fontWeight: 400,
            color: '#000000',
            display: 'flex',
            [theme.breakpoints.down(500)]: {
                fontSize: '14px'
            }
        })
    );
    const TextMarkMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('span')(()=>({
            fontWeight: 'bold'
        })
    );
    return {
        ItemMUI,
        ButtonMUI,
        ItemTextMUI,
        TextMarkMUI,
        LinkMUI
    };
};


/***/ }),

/***/ 4902:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ useCategorySearchHintsItem)
/* harmony export */ });
/* harmony import */ var _hooks_useMedia__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2447);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const useCategorySearchHintsItem = (active, title, isMouseEnter)=>{
    const { setValue  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useFormContext)();
    const { isCustomSize  } = (0,_hooks_useMedia__WEBPACK_IMPORTED_MODULE_0__/* .useCustomSize */ .ZB)(769);
    const activeStyles = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return active ? {
            backgroundColor: '#DFE4EC'
        } : {};
    }, [
        active,
        isMouseEnter
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (active) {
            if (!isMouseEnter) {
                setValue('search', title);
            }
        }
    }, [
        active,
        isMouseEnter
    ]);
    return {
        activeStyles,
        isCustomSize
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8802:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "u": () => (/* binding */ useCategorySearchStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useCategorySearchStyles = ()=>{
    const SearchContainerWrapperMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            position: 'relative'
        })
    );
    const EuroPositionMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            // position: 'absolute',
            // top: 8,
            // left: -210
            marginBottom: 20
        })
    );
    const SearchContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            marginBottom: '5px',
            '& > div': {
                display: 'flex',
                justifyContent: 'center'
            },
            [theme.breakpoints.down(1025)]: {
                marginBottom: '3px'
            },
            [theme.breakpoints.down(600)]: {
                marginBottom: '15px'
            }
        })
    );
    const TextFieldSearch = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.TextField)(({ theme  })=>({
            '& > div > input': {
                padding: '15px 25px'
            },
            [theme.breakpoints.down(1025)]: {
                '& > div > input': {
                    padding: '9px 19px',
                    borderRadius: '5px',
                    fontSize: '16px'
                }
            }
        })
    );
    const DropDownWrapperMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            '& > div': {
                '& > button': {
                    padding: 0,
                    margin: '0 0 0 5px !important'
                },
                '& > div': {
                    '& > button': {
                        margin: '0 !important'
                    }
                }
            }
        })
    );
    const SearchWrapperMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            display: 'flex',
            alignItems: 'center',
            [theme.breakpoints.down(600)]: {
                flexDirection: 'column'
            },
            '&>div': {
                '&:nth-child(1)': {
                    width: '100%',
                    marginRight: 25,
                    [theme.breakpoints.down(600)]: {
                        marginRight: 0
                    }
                }
            }
        })
    );
    return {
        TextFieldSearch,
        SearchContainerMUI,
        SearchContainerWrapperMUI,
        EuroPositionMUI,
        DropDownWrapperMUI,
        SearchWrapperMUI
    };
};


/***/ }),

/***/ 9294:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ useCategorySearch)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5641);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(257);
/* harmony import */ var _hooks_useMedia__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2447);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const useCategorySearch = (onSubmit, searchHints, handleKeyDownEnter, handleChangeSearchValue, component = 'shops')=>{
    const { control , setValue  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useFormContext)();
    const searchValue = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useWatch)({
        name: 'search'
    });
    const { 0: isFocus , 1: setIsFocus  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { 0: activeSuggestion , 1: setActiveSuggestion  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { 0: isMouseEnter , 1: setIsMouseEnter  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { 0: dropDownOpen , 1: setDropDownOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const getFile = async ()=>{
        const a = document.createElement('a');
        a.href = 'https://octo.global/api/admin/users_table';
        a.click();
        a.remove();
    };
    const dropItems = [
        {
            title: 'Сформировать отчёт',
            onClick: ()=>getFile()
        },
        {
            title: 'Все ожидаемые товары',
            onClick: ()=>router.push('/account/orders/all-wait')
        }, 
    ];
    const { isMobile  } = (0,_hooks_useMedia__WEBPACK_IMPORTED_MODULE_3__/* .useMobile */ .XA)();
    const { isAdmin ,  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_2__/* .useUserStore */ .L)();
    const isAccount = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        var ref;
        return ((ref = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)().pathname) === null || ref === void 0 ? void 0 : ref.split('/')[1]) === 'account';
    }, [
        next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter
    ]);
    const isHintsData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return Array.isArray(searchHints) && (searchHints === null || searchHints === void 0 ? void 0 : searchHints.length);
    }, [
        searchHints
    ]);
    const isVisibleHints = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>!!(isHintsData && isFocus && searchValue)
    , [
        isFocus,
        isHintsData
    ]);
    const handleChangeFocus = (state)=>{
        return ()=>{
            if (!state) {
                setTimeout((function() {
                    setIsFocus(state);
                }).bind(undefined), 150);
                return;
            }
            setIsFocus(state);
        };
    };
    const handleKeyDown = (e)=>{
        setIsMouseEnter(false);
        if (e.key === 'ArrowDown') {
            if (activeSuggestion + 1 > searchHints.length) {
                setActiveSuggestion(1);
                return;
            }
            setActiveSuggestion((prevState)=>prevState + 1
            );
            return;
        }
        if (e.key === 'ArrowUp') {
            if (activeSuggestion - 1 < 1) {
                setActiveSuggestion(searchHints.length);
                return;
            }
            setActiveSuggestion((prevState)=>prevState - 1
            );
            return;
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            //?
            if (component == 'shops') {
                onSubmit({
                    search: searchValue,
                    tags: []
                }, 'search');
            } else {
                onSubmit({
                    suggestionIndex: activeSuggestion
                });
            }
            handleKeyDownEnter();
        }
        setActiveSuggestion(0);
    };
    const handleChangeActiveSuggestion = (hintCount)=>{
        return ()=>{
            setIsMouseEnter(true);
            setActiveSuggestion(hintCount);
        };
    };
    const handleMouseEnter = ()=>{
        setIsMouseEnter(true);
    };
    const handleMouseLeave = ()=>{
        setIsMouseEnter(false);
        handleChangeActiveSuggestion(0)();
    };
    const handleClickHintItem = (title, hints)=>{
        return ()=>{
            if (title && !(hints === null || hints === void 0 ? void 0 : hints.email)) {
                setValue('search', title);
            }
            if (hints === null || hints === void 0 ? void 0 : hints.email) {
                setValue('search', `${hints.email}`);
                onSubmit({
                    suggestionIndex: activeSuggestion
                });
            }
            setActiveSuggestion(0);
        };
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (!activeSuggestion && searchValue) {
            handleChangeSearchValue(searchValue);
        }
        if (!searchValue && (searchHints === null || searchHints === void 0 ? void 0 : searchHints.length)) {
            setActiveSuggestion(0);
        }
        if (!searchValue) {
            handleKeyDownEnter();
        }
    }, [
        searchValue
    ]);
    const ButtonSxStyle = {
        backgroundColor: 'rgba(39, 77, 130, 0.8)',
        width: '90%',
        margin: 0
    };
    return {
        isFocus,
        control,
        searchHints,
        isMouseEnter,
        handleKeyDown,
        isVisibleHints,
        activeSuggestion,
        handleMouseEnter,
        handleMouseLeave,
        handleChangeFocus,
        setActiveSuggestion,
        handleClickHintItem,
        handleChangeActiveSuggestion,
        isAdmin,
        isMobile,
        isAccount,
        dropItems,
        dropDownOpen,
        setDropDownOpen,
        ButtonSxStyle
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;