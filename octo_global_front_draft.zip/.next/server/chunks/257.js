"use strict";
exports.id = 257;
exports.ids = [257];
exports.modules = {

/***/ 257:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ useUserStore)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4730);
/* harmony import */ var _store_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6213);



const useUserStore = ()=>{
    const { user  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .C)((state)=>state.userReducer
    );
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppDispatch */ .T)();
    const isAuth = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return !!(user === null || user === void 0 ? void 0 : user.id);
    }, [
        user
    ]);
    const isAdmin = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        return (user === null || user === void 0 ? void 0 : user.statusId) === 9;
    }, [
        user
    ]);
    const { adminSwitchIdToUser , adminSwitchUserModel  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppSelector */ .C)((state)=>state.adminReducer
    );
    const Iuser = adminSwitchUserModel || user;
    const userPhone = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (isAdmin && adminSwitchUserModel) {
            return adminSwitchUserModel.phone;
        } else if (user) {
            return user.phone;
        }
    }, [
        adminSwitchIdToUser,
        adminSwitchUserModel
    ]);
    const userName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (isAdmin && adminSwitchUserModel) {
            return adminSwitchUserModel.name;
        } else if (user) {
            return user.name;
        } else {
            return '';
        }
    }, [
        adminSwitchIdToUser,
        adminSwitchUserModel
    ]);
    const userSurname = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (isAdmin && adminSwitchUserModel) {
            return adminSwitchUserModel.surname;
        } else if (user) {
            return user.surname;
        } else {
            return '';
        }
    }, [
        adminSwitchIdToUser,
        adminSwitchUserModel
    ]);
    const fetchUser = ()=>{
        dispatch((0,_store_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_2__/* .fetchUserAutoLogin */ .u3)()).then((response)=>{
            var ref, ref1;
            const message = (ref = response.payload) === null || ref === void 0 ? void 0 : (ref1 = ref.message) === null || ref1 === void 0 ? void 0 : ref1.payload;
            if (message) {
                const isLogout = message == '422' || message == '403' || message == '401';
                if (isLogout) {
                    const persist = window.localStorage.getItem('persist:root');
                    if (persist) {
                        window.localStorage.removeItem('persist:root');
                    }
                }
            }
        });
    };
    return {
        userPhone,
        userName,
        userSurname,
        adminSwitchIdToUser,
        user,
        Iuser,
        isAuth,
        isAdmin,
        adminSwitchUserModel,
        getUser: fetchUser
    };
};


/***/ })

};
;