"use strict";
exports.id = 5760;
exports.ids = [5760];
exports.modules = {

/***/ 5760:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2907);
/* harmony import */ var _UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8595);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8844);
/* harmony import */ var _components_forms_ResetPasswordForm_useResetPasswordForm__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8410);
/* harmony import */ var UI_UIComponents_ModalUI_ModalUI__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1705);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_5__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const ResetPasswordForm = ()=>{
    const { handleSubmit , control , setError , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)();
    const { onSubmit , openModal , changeOpenModal ,  } = (0,_components_forms_ResetPasswordForm_useResetPasswordForm__WEBPACK_IMPORTED_MODULE_7__/* .useResetPasswordForm */ .z)(setError, reset);
    const { FormsWrapperBox , FormsInput , FormsButton , FormsDescription ,  } = (0,_style__WEBPACK_IMPORTED_MODULE_6__/* .useFormsStyle */ .R)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        component: "form",
        onSubmit: handleSubmit(onSubmit),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FormsWrapperBox, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormsDescription, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                        variant: "body2",
                        style: {
                            whiteSpace: 'pre-wrap'
                        },
                        children: [
                            "Здравствуйте!",
                            '\n',
                            "Для восстановления пароля введите свой электронный адрес, указанный при регистрации, и через несколько минут на Ваш e-mail придёт письмо с Вашими регистрационными данными и контрольной строкой для ввода нового пароля. Для того, чтобы сбросить пароль, перейдите по следующей ссылке."
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormsInput, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        controller: {
                            name: 'email',
                            control,
                            defaultValue: '',
                            rules: {
                                required: true
                            }
                        },
                        inputProps: {
                            placeholder: 'Email',
                            name: 'email',
                            type: 'email',
                            required: true
                        }
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormsButton, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        type: "submit",
                        children: "Продолжить"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_ModalUI_ModalUI__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    dialogProps: {
                        open: openModal,
                        onClose: changeOpenModal
                    },
                    title: 'Письмо на востановление пароля отправленно',
                    closeTime: 3
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(ResetPasswordForm));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8410:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ useResetPasswordForm)
/* harmony export */ });
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4730);
/* harmony import */ var _reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6213);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const useResetPasswordForm = (setError, reset)=>{
    const { 0: openModal , 1: changeOpenModal  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppDispatch */ .T)();
    const setErrorFields = (fieldName, message)=>{
        setError(fieldName, {
            type: 'string',
            message
        });
    };
    const handleUserNotFound = ()=>{
        setErrorFields('email', 'Пользователь не найден');
    };
    const handleBadResponse = ()=>{
        setErrorFields('email', 'Ошибка запроса, пожалуйста попробуйте позже');
    };
    const handleMoreRequest = ()=>{
        setErrorFields('email', 'Слишком много запросов');
    };
    const onSubmit = (data)=>{
        const formData = data;
        if (formData.email) {
            dispatch((0,_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchRecoveryMessage */ .mR)(formData)).then((response)=>{
                const statusCode = response.payload;
                switch(statusCode){
                    case 403:
                        handleUserNotFound();
                        return;
                    case 500:
                        handleBadResponse();
                        return;
                    case 429:
                        handleMoreRequest();
                        return;
                    case 200:
                        changeOpenModal(true);
                        reset({});
                        return;
                    default:
                }
            }).catch(()=>{
                changeOpenModal(false);
            });
        }
    };
    return {
        onSubmit,
        openModal,
        changeOpenModal
    };
};


/***/ })

};
;