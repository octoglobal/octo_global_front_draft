"use strict";
exports.id = 2777;
exports.ids = [2777];
exports.modules = {

/***/ 6409:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgCheckBoxEmpty = function SvgCheckBoxEmpty(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 20,
    height: 20,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#fff",
    stroke: "#DFE4EC",
    d: "M.5.5h19v19H.5z"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgCheckBoxEmpty);

/***/ }),

/***/ 4974:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path, _path2;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgCheckBoxFill = function SvgCheckBoxFill(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 20,
    height: 20,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#fff",
    stroke: "#DFE4EC",
    d: "M.5.5h19v19H.5z"
  })), _path2 || (_path2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M12.917 10.548C10.967 12.73 8.542 16.5 8.542 16.5s-1.72-2.89-2.778-4.424C4.706 10.542 3.533 9.44 3 9.02c0 0 .402-.72.472-1.207.104-.737 0-1.461 0-1.461s1.624 1.37 2.567 2.346c.943.976 2.306 2.815 2.306 2.815s2.504-2.744 3.917-3.995C15.379 4.756 17 3.5 17 3.5s-.131.331-.468 1.685c-.293 1.18-.34 1.985-.34 1.985s-1.167 1.018-3.275 3.378Z",
    fill: "#274D82"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgCheckBoxFill);

/***/ }),

/***/ 7766:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _UIIcon_CheckBoxEmpty_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6409);
/* harmony import */ var _UIIcon_CheckBoxFill_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4974);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7619);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const CheckBoxUI = ({ controller , inputProps  })=>{
    const { CheckBoxStyle  } = (0,_style__WEBPACK_IMPORTED_MODULE_6__/* .useCheckBoxUIStyle */ .H)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__.Controller, {
        name: controller.name,
        control: controller.control,
        defaultValue: controller.defaultValue,
        rules: controller.rules,
        render: ({ field: { value , onChange  }  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Checkbox, {
                sx: CheckBoxStyle,
                ...inputProps,
                checked: value,
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_CheckBoxEmpty_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                checkedIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_CheckBoxFill_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                onChange: ()=>onChange(!value)
            })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(CheckBoxUI));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7619:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ useCheckBoxUIStyle)
/* harmony export */ });
const useCheckBoxUIStyle = ()=>{
    const CheckBoxStyle = {
        '& input': {
            width: '20px',
            height: '20px',
            background: '#FFFFFF',
            border: '1px solid #DFE4EC',
            boxSizing: 'border-box'
        },
        '& span': {
            padding: '0'
        }
    };
    return {
        CheckBoxStyle
    };
};


/***/ }),

/***/ 5443:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ SignUpPromt_SignUpPromt)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/AnyPage/AuthFormPromt/SignUpPromt/style.ts

const useSignUpPromtStyle = ()=>{
    const FormsWrapperBox = (0,material_.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'column',
            padding: '20px 0px 0px'
        })
    );
    const FormsFooterInfoBox = (0,material_.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'column',
            marginBottom: '15px',
            fontStyle: 'normal',
            fontWeight: '300',
            fontSize: '12px',
            lineHeight: '14px',
            color: '#000000',
            textAlign: 'center',
            '& a': {
                cursor: 'pointer'
            }
        })
    );
    const FormsLink = (0,material_.styled)('div')(()=>({
            fontWeight: '400',
            fontSize: '14px',
            lineHeight: '16px',
            color: '#274D82',
            cursor: 'pointer',
            display: 'inline-block'
        })
    );
    const FormsItemMUI = (0,material_.styled)('span')(()=>({
            fontWeight: 300,
            fontSize: '14px',
            lineHeight: '16px'
        })
    );
    const FormsInput = (0,material_.styled)('div')(()=>({
            marginBottom: '20px'
        })
    );
    const FormsButton = (0,material_.styled)('div')(()=>({
            marginBottom: '15px',
            '& .Mui-disabled': {
                opacity: '0.8'
            }
        })
    );
    const FormsDescription = (0,material_.styled)('div')(()=>({
            marginBottom: '15px',
            '& p': {
                fontStyle: 'normal',
                fontWeight: '300',
                fontSize: '14px',
                lineHeight: '16px',
                color: '#000000'
            }
        })
    );
    const FormsCheckBoxWrapper = (0,material_.styled)('div')(()=>({
            display: 'flex',
            alignItems: 'center',
            marginBottom: '21px',
            position: 'relative',
            '& p': {
                fontStyle: 'normal',
                fontWeight: '300',
                fontSize: '12px',
                lineHeight: '14px',
                color: '#C4C4C4'
            },
            '& span': {
                width: '20px',
                height: '20px',
                padding: '0',
                margin: '0 15px 0 0'
            }
        })
    );
    const FormHelperErrorUI = (0,material_.styled)(material_.FormHelperText)(()=>({
            position: 'absolute',
            top: '22px',
            right: '0',
            '& span': {
                fontFamily: 'Roboto',
                fontStyle: 'normal',
                fontWeight: '400',
                fontSize: '10px',
                lineHeight: '12px',
                color: 'red !important'
            }
        })
    );
    return {
        FormsWrapperBox,
        FormsFooterInfoBox,
        FormsLink,
        FormsInput,
        FormsButton,
        FormsCheckBoxWrapper,
        FormsDescription,
        FormsItemMUI,
        FormHelperErrorUI
    };
};

;// CONCATENATED MODULE: ./src/components/AnyPage/AuthFormPromt/SignUpPromt/SignUpPromt.tsx




const SignUpPromt = ({ onClickLogin ,  })=>{
    const { FormsFooterInfoBox , FormsLink , FormsItemMUI  } = useSignUpPromtStyle();
    const handlerToLogin = ()=>{
        onClickLogin();
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(FormsFooterInfoBox, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
            variant: "body2",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(FormsItemMUI, {
                    children: "У вас есть учетная запись?\xa0"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    component: "span",
                    onClick: handlerToLogin,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(FormsLink, {
                            children: "Войти"
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const SignUpPromt_SignUpPromt = (/*#__PURE__*/external_react_default().memo(SignUpPromt));


/***/ }),

/***/ 673:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ useSignUp)
/* harmony export */ });
/* harmony import */ var _reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6213);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4730);
/* harmony import */ var _hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4763);
/* harmony import */ var _services_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4727);




const useSignUp = (setError)=>{
    const { pushTo  } = (0,_hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_2__/* .useCustomRouter */ .c)();
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_1__/* .useAppDispatch */ .T)();
    const setErrorFields = (fieldName, message)=>{
        setError(fieldName, {
            type: 'string',
            message
        });
    };
    const handleBadResponse = (message)=>{
        setErrorFields('name', ' ');
        setErrorFields('surname', ' ');
        setErrorFields('email', ' ');
        setErrorFields('password', ' ');
        setErrorFields('confirmPassword', message);
    };
    const onSubmit = async (data)=>{
        const formData = data;
        const sendObject = {
            ...formData,
            name: (0,_services_services__WEBPACK_IMPORTED_MODULE_3__/* .ucFirst */ .zf)(formData.name),
            surname: (0,_services_services__WEBPACK_IMPORTED_MODULE_3__/* .ucFirst */ .zf)(formData.surname)
        };
        const regResponse = await (0,_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_0__/* .fetchUserRegistration */ .z3)(sendObject);
        if (regResponse === null || regResponse === void 0 ? void 0 : regResponse.status) {
            if (regResponse.status == 409) {
                handleBadResponse('Пользователь с такой почтой уже существует');
            }
            if (regResponse.status == 422) {
                handleBadResponse('Заполните все поля для регистрации');
            }
        }
        if (regResponse === 'user successfully created') {
            dispatch((0,_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_0__/* .fetchUserLogin */ .zd)({
                email: formData.email,
                password: formData.password
            })).then(()=>{
                pushTo('/welcome');
            });
        }
    };
    return {
        onSubmit
    };
};


/***/ }),

/***/ 924:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3218);
/* harmony import */ var _hookform_error_message__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_hookform_error_message__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4763);
/* harmony import */ var _components_SignUp_useSignUp__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(673);
/* harmony import */ var _UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2907);
/* harmony import */ var _UI_UIComponents_CheckBoxUI_CheckBoxUI__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7766);
/* harmony import */ var _UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8595);
/* harmony import */ var _UI_UIComponents_TextFIeldUI_TextFieldPasswordUI_TextFieldPasswordUI__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9617);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8844);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _UI_UIComponents_CheckBoxUI_CheckBoxUI__WEBPACK_IMPORTED_MODULE_8__, _UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_9__, _UI_UIComponents_TextFIeldUI_TextFieldPasswordUI_TextFieldPasswordUI__WEBPACK_IMPORTED_MODULE_10__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _UI_UIComponents_CheckBoxUI_CheckBoxUI__WEBPACK_IMPORTED_MODULE_8__, _UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_9__, _UI_UIComponents_TextFIeldUI_TextFieldPasswordUI_TextFieldPasswordUI__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const SignUpForm = ()=>{
    const { pushTo  } = (0,_hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_5__/* .useCustomRouter */ .c)();
    const { handleSubmit , control , setError , formState: { // isValid,
    errors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)();
    const { onSubmit  } = (0,_components_SignUp_useSignUp__WEBPACK_IMPORTED_MODULE_6__/* .useSignUp */ .Q)(setError);
    const { FormsWrapperBox , FormsLink , FormsInput , FormsButton , FormsCheckBoxWrapper , FormHelperErrorUI , checkboxItemModificationWrapper , FormCheckboxItemMUI  } = (0,_style__WEBPACK_IMPORTED_MODULE_11__/* .useFormsStyle */ .R)();
    const handlerPushToPolicy = ()=>{
        pushTo('/privacypolicy');
    };
    const ucFirstRegex = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>new RegExp(/^[a-zа-я]/)
    , []);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        component: "form",
        onSubmit: handleSubmit(onSubmit),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FormsWrapperBox, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormsInput, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        controller: {
                            name: 'name',
                            control,
                            defaultValue: '',
                            rules: {
                                required: true
                            }
                        },
                        inputProps: {
                            placeholder: 'Имя',
                            name: 'name',
                            type: 'text',
                            required: true
                        },
                        regexProps: {
                            regex: ucFirstRegex,
                            ucFirst: true
                        }
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormsInput, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        controller: {
                            name: 'surname',
                            control,
                            defaultValue: '',
                            rules: {
                                required: true
                            }
                        },
                        inputProps: {
                            placeholder: 'Фамилия',
                            name: 'surname',
                            type: 'text',
                            required: true
                        },
                        regexProps: {
                            regex: ucFirstRegex,
                            ucFirst: true
                        }
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormsInput, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        controller: {
                            name: 'email',
                            control,
                            defaultValue: '',
                            rules: {
                                required: true
                            }
                        },
                        inputProps: {
                            placeholder: 'Почта',
                            name: 'email',
                            type: 'email',
                            required: true
                        }
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormsInput, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_TextFIeldUI_TextFieldPasswordUI_TextFieldPasswordUI__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        controller: {
                            name: 'password',
                            control,
                            defaultValue: '',
                            rules: {
                                required: true
                            }
                        },
                        inputProps: {
                            placeholder: 'Пароль',
                            name: 'password',
                            required: true
                        }
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormsInput, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_TextFIeldUI_TextFieldPasswordUI_TextFieldPasswordUI__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        controller: {
                            name: 'confirmPassword',
                            control,
                            defaultValue: '',
                            rules: {
                                required: true
                            }
                        },
                        inputProps: {
                            placeholder: 'Повторите пароль',
                            name: 'password',
                            required: true
                        }
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FormsCheckBoxWrapper, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_CheckBoxUI_CheckBoxUI__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            controller: {
                                name: 'publicOffer',
                                control,
                                defaultValue: false,
                                rules: {
                                    required: 'Заполните все поля'
                                }
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormCheckboxItemMUI, {
                                children: "Я соглашаюсь с публичной офертой"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormHelperErrorUI, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_hookform_error_message__WEBPACK_IMPORTED_MODULE_4__.ErrorMessage, {
                                errors: errors,
                                name: "publicOffer",
                                as: "span"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FormsCheckBoxWrapper, {
                    sx: checkboxItemModificationWrapper,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_CheckBoxUI_CheckBoxUI__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            controller: {
                                name: 'privacyPolicy',
                                control,
                                defaultValue: false,
                                rules: {
                                    required: 'Заполните все поля'
                                }
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                            variant: "body2",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FormCheckboxItemMUI, {
                                children: [
                                    "Я соглашаюсь с\xa0",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormsLink, {
                                        onClick: handlerPushToPolicy,
                                        children: "политикой конфиденциальности"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormHelperErrorUI, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_hookform_error_message__WEBPACK_IMPORTED_MODULE_4__.ErrorMessage, {
                                errors: errors,
                                name: "privacyPolicy",
                                as: "span"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormsButton, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        type: "submit",
                        children: "Зарегистрироваться"
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(SignUpForm));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;