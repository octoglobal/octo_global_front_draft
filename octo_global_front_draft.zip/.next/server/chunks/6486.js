"use strict";
exports.id = 6486;
exports.ids = [6486];
exports.modules = {

/***/ 3730:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ LinkUI)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/UI/UIComponents/LinkUI/style.ts

const useLinkStyle = ()=>{
    const LinkUI = (0,material_.styled)('a')(({ theme  })=>({
            color: '#000000',
            cursor: 'pointer',
            textDecoration: 'none',
            fontStyle: 'normal',
            fontWeight: '300',
            fontSize: '20px',
            lineHeight: '23.44px',
            webkitAppearance: 'none',
            '&:link': {
                color: '#000000'
            },
            '&:visited': {
                color: '#000000'
            },
            [theme.breakpoints.down(1024)]: {
                fontSize: '14px',
                lineHeight: '16px'
            }
        })
    );
    return {
        LinkUI
    };
};

;// CONCATENATED MODULE: ./src/UI/UIComponents/LinkUI/LinkUI.tsx




const CustomLinkUI = ({ href ='' , onClick , children , type ='' ,  })=>{
    const handlerClick = ()=>{
        if (onClick) onClick();
    };
    const { LinkUI  } = useLinkStyle();
    return(/*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
        href: href,
        children: /*#__PURE__*/ jsx_runtime_.jsx(LinkUI, {
            href: href,
            type: type,
            onClick: handlerClick,
            children: children
        })
    }));
};
/* harmony default export */ const LinkUI = (/*#__PURE__*/external_react_default().memo(CustomLinkUI));


/***/ }),

/***/ 3370:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ User_User)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/AnyPage/User/style.ts

const useUserStyle = ()=>{
    const UserUI = (0,material_.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            cursor: 'pointer'
        })
    );
    const UserAvatarUI = (0,material_.styled)('span')(()=>({
            width: '39px',
            height: '39px',
            marginRight: '9px'
        })
    );
    const UserFIOUI = (0,material_.styled)('div')(({ theme  })=>({
            fontStyle: 'normal',
            fontWeight: '300',
            fontSize: '18px',
            maxWidth: '165px',
            lineHeight: '21px',
            textAlign: 'center',
            color: '#000000',
            whiteSpace: 'nowrap',
            /* Текст не переносится */ overflow: 'hidden',
            /* Обрезаем всё за пределами блока */ textOverflow: 'ellipsis',
            /* Добавляем многоточие */ [theme.breakpoints.down(600)]: {
                maxWidth: '460px',
                whiteSpace: 'wrap',
                /* Текст не переносится */ // overflow: 	  'visible',	  /* Обрезаем всё за пределами блока */
                textOverflow: 'clip'
            }
        })
    );
    return {
        UserUI,
        UserAvatarUI,
        UserFIOUI
    };
};

// EXTERNAL MODULE: ./src/hooks/useMedia.ts
var useMedia = __webpack_require__(2447);
// EXTERNAL MODULE: ./src/hooks/useUserStore.ts
var useUserStore = __webpack_require__(257);
// EXTERNAL MODULE: ./src/hooks/useReduxHooks.ts
var useReduxHooks = __webpack_require__(4730);
;// CONCATENATED MODULE: ./src/components/AnyPage/User/useUser.ts




const useUser = (isChangeToAdmin)=>{
    const { isCustomSize  } = (0,useMedia/* useCustomSize */.ZB)(680);
    const { isCustom800  } = (0,useMedia/* useCustom800 */.Ap)();
    const ellipsisScale = (0,external_react_.useMemo)(()=>isCustomSize || isCustom800 ? true : false
    , [
        isCustomSize,
        isCustom800
    ]);
    const { user: { name , surname  } , isAdmin  } = (0,useUserStore/* useUserStore */.L)();
    const { adminSwitchUserModel  } = (0,useReduxHooks/* useAppSelector */.C)((state)=>state.adminReducer
    );
    const getUserInfo = (key, value)=>{
        if (isChangeToAdmin) {
            if (isAdmin && adminSwitchUserModel) {
                return adminSwitchUserModel[key];
            }
            return value;
        } else {
            return value;
        }
    };
    const userName = (0,external_react_.useMemo)(()=>getUserInfo('name', name)
    , [
        isChangeToAdmin,
        adminSwitchUserModel
    ]);
    const userSurname = (0,external_react_.useMemo)(()=>getUserInfo('surname', surname)
    , [
        isChangeToAdmin,
        adminSwitchUserModel
    ]);
    return {
        userName,
        userSurname,
        ellipsisScale
    };
};

;// CONCATENATED MODULE: ./src/components/AnyPage/User/User.tsx





const User = ({ cutFio =true , isChangeToAdmin =false ,  })=>{
    const { userName , userSurname , ellipsisScale ,  } = useUser(isChangeToAdmin);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(UserUI, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(UserAvatarUI, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Avatar, {
                    sx: {
                        bgcolor: '#274D82'
                    }
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(UserFIOUI, {
                children: ellipsisScale && cutFio ? userName : `${userName} ${userSurname}`
            })
        ]
    }));
};
const { UserUI , UserAvatarUI , UserFIOUI  } = useUserStyle();
/* harmony default export */ const User_User = (/*#__PURE__*/external_react_default().memo(User));


/***/ }),

/***/ 2249:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ fetchSendAddress)
/* harmony export */ });
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7355);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);


const fetchSendAddress = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)('/address/fetchSendAddress', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_0__/* .octoAxios.get */ .N.get(`/user/send_message/wont_consolidation_address/${data.address}`);
        if (response.status === 200) {
            return response;
        }
    } catch (e) {
        return thunkAPI.rejectWithValue('Ошибка api /address/fetchSendAddress');
    }
});


/***/ })

};
;