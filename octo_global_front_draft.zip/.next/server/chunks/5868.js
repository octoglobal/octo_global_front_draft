"use strict";
exports.id = 5868;
exports.ids = [5868];
exports.modules = {

/***/ 7779:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Cr": () => (/* binding */ fetchAddNewsBlog),
/* harmony export */   "Q2": () => (/* binding */ fetchNewsData),
/* harmony export */   "FM": () => (/* binding */ fetchDeleteBlogItem),
/* harmony export */   "sf": () => (/* binding */ fetchUpdateBlog)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7355);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_reducers_blogSlice_blogSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6559);




const fetchAddNewsBlog = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('blogSlice/add', async (data, thunkAPI)=>{
    try {
        const formData = new FormData();
        const sendData = JSON.stringify({
            title: data.blogTitle,
            body: data.blogDescription,
            products: [
                {
                    title: '',
                    body: '',
                    url: data.postLink1
                },
                {
                    title: '',
                    body: '',
                    url: data.postLink2
                },
                {
                    title: '',
                    body: '',
                    url: data.postLink3
                }, 
            ]
        });
        formData.append('image', data.blogPhoto1.file);
        formData.append('image', data.blogPhoto2.file);
        formData.append('image', data.blogPhoto3.file);
        formData.append('json_data', sendData);
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.post */ .N.post('/admin/blog', formData).then((r)=>r.data
        );
        const response2 = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get('blog?page=1&page_limit=1');
        const newId = response2.data.posts[0].id;
        if (response.message == 'success') {
            return {
                newPost: true,
                title: data.blogTitle,
                body: data.blogDescription,
                createdTime: new Date().toString(),
                editedTime: null,
                id: newId,
                products: [
                    {
                        title: data.subtitlePhoto1,
                        body: data.miniDescPhoto1,
                        url: data.postLink1,
                        photo: data.blogPhoto1.base64
                    },
                    {
                        title: data.subtitlePhoto2,
                        body: data.miniDescPhoto2,
                        url: data.postLink2,
                        photo: data.blogPhoto2.base64
                    },
                    {
                        title: data.subtitlePhoto3,
                        body: data.miniDescPhoto3,
                        url: data.postLink3,
                        photo: data.blogPhoto3.base64
                    }, 
                ]
            };
        }
    } catch (e) {
        if (axios__WEBPACK_IMPORTED_MODULE_2___default().isAxiosError(e)) {
            // return thunkAPI.rejectWithValue(e.response?.status);
            return thunkAPI.rejectWithValue('Произошла ошибка при добавлении');
        }
    }
});
const fetchNewsData = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('blogSlice/getPosts', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get(`blog?page=${data.page}&page_limit=${data.pageLimit}`);
        return {
            posts: response.data.posts,
            blogEnd: !(response.data.posts.length === data.pageLimit)
        };
    } catch (e) {
        if (axios__WEBPACK_IMPORTED_MODULE_2___default().isAxiosError(e)) {
            var ref;
            return thunkAPI.rejectWithValue((ref = e.response) === null || ref === void 0 ? void 0 : ref.status);
        }
    }
});
const fetchDeleteBlogItem = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('blogSlice/deletePosts', async (data, { rejectWithValue , dispatch  })=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios["delete"] */ .N["delete"]('/admin/blog', {
            data: {
                blogId: data.id
            }
        });
        if (response.status === 200) {
            dispatch((0,_store_reducers_blogSlice_blogSlice__WEBPACK_IMPORTED_MODULE_3__/* .deletePostItem */ .RW)(data.id));
        }
    } catch (e) {
        return rejectWithValue('Произошла ошибка при удалении');
    }
});
const fetchUpdateBlog = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('blogSlice/update', async (data1, { dispatch , rejectWithValue  })=>{
    const imgPathType = (data)=>{
        if (data.base64.split('/image')[1]) {
            return data.base64.split('/image')[1];
        } else {
            return data.base64;
        }
    };
    try {
        const formData = new FormData();
        const sendData = JSON.stringify({
            blogId: data1.id,
            title: data1.data.blogTitle,
            body: data1.data.blogDescription,
            products: [
                {
                    title: data1.data.subtitlePhoto1 || '',
                    body: data1.data.miniDescPhoto1 || '',
                    url: data1.data.postLink1
                },
                {
                    title: data1.data.subtitlePhoto2 || '',
                    body: data1.data.miniDescPhoto2 || '',
                    url: data1.data.postLink2
                },
                {
                    title: data1.data.subtitlePhoto3 || '',
                    body: data1.data.miniDescPhoto3 || '',
                    url: data1.data.postLink3
                }, 
            ]
        });
        formData.append('json_data', sendData);
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.patch */ .N.patch('/admin/blog', formData);
        // if (response.statusText === 'OK'){
        if (response.status === 200) {
            const updateData = {
                id: data1.id,
                title: data1.data.blogTitle,
                body: data1.data.blogDescription,
                products: [
                    {
                        title: data1.data.subtitlePhoto1,
                        body: data1.data.miniDescPhoto1,
                        url: data1.data.postLink1,
                        photo: imgPathType(data1.data.blogPhoto1)
                    },
                    {
                        title: data1.data.subtitlePhoto2,
                        body: data1.data.miniDescPhoto2,
                        url: data1.data.postLink2,
                        photo: imgPathType(data1.data.blogPhoto2)
                    },
                    {
                        title: data1.data.subtitlePhoto3,
                        body: data1.data.miniDescPhoto3,
                        url: data1.data.postLink3,
                        photo: imgPathType(data1.data.blogPhoto3)
                    }, 
                ]
            };
            dispatch((0,_store_reducers_blogSlice_blogSlice__WEBPACK_IMPORTED_MODULE_3__/* .updateBlogData */ .E$)(updateData));
        }
    } catch (error) {
        return rejectWithValue('Произошла ошибка при обновлении');
    }
});


/***/ }),

/***/ 6559:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "pc": () => (/* binding */ blogSlice),
/* harmony export */   "RW": () => (/* binding */ deletePostItem),
/* harmony export */   "eY": () => (/* binding */ updateEditMode),
/* harmony export */   "E$": () => (/* binding */ updateBlogData),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_blogSlice_asyncThunk_blogApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7779);


const initialState = {
    page: 1,
    pageLimit: 50,
    updatePosts: false,
    blogData: [],
    blogEnd: false,
    EditMode: {
        id: null,
        open: false
    },
    error: {
        status: false,
        message: ''
    },
    loading: false
};
const blogSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'blogSlice',
    initialState,
    reducers: {
        updatePosts: (state)=>{
            state.updatePosts = true;
        },
        deletePostItem: (state, action)=>{
            state.blogData = state.blogData.filter((blog)=>{
                return blog.id !== action.payload;
            });
        },
        updateEditMode: (state, action)=>{
            state.EditMode.id = action.payload.id;
            state.EditMode.open = action.payload.open;
        },
        updateBlogData: (state, action)=>{
            const newData = state.blogData.map((blog)=>{
                if (blog.id === action.payload.id) {
                    return {
                        ...blog,
                        ...action.payload
                    };
                }
                return blog;
            });
            state.blogData = newData;
        }
    },
    extraReducers: {
        [_reducers_blogSlice_asyncThunk_blogApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchAddNewsBlog.pending.type */ .Cr.pending.type]: (state)=>{
            state.loading = true;
            state.error.status = false;
            state.error.message = '';
        },
        [_reducers_blogSlice_asyncThunk_blogApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchAddNewsBlog.fulfilled.type */ .Cr.fulfilled.type]: (state, action)=>{
            state.blogData = [
                action.payload,
                ...state.blogData
            ];
            state.loading = false;
        },
        [_reducers_blogSlice_asyncThunk_blogApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchAddNewsBlog.rejected.type */ .Cr.rejected.type]: (state, action)=>{
            state.error.status = true;
            state.error.message = action.payload;
            state.loading = false;
        },
        [_reducers_blogSlice_asyncThunk_blogApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchNewsData.fulfilled.type */ .Q2.fulfilled.type]: (state, action)=>{
            state.blogEnd = action.payload.blogEnd;
            state.updatePosts = false;
            state.page += 1;
            if (state.blogData.length) {
                state.blogData = [
                    ...state.blogData,
                    ...action.payload.posts
                ];
            } else {
                state.blogData = [
                    ...action.payload.posts
                ];
            }
        },
        // [fetchDeleteBlogItem.fulfilled.type]: (state, action) => {
        // 	state.blogData = state.blogData.filter((blog) => {
        // 		return blog.id !== action.payload;
        // 	});
        // },	
        [_reducers_blogSlice_asyncThunk_blogApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchUpdateBlog.pending.type */ .sf.pending.type]: (state)=>{
            state.error.status = false;
            state.error.message = '';
        },
        [_reducers_blogSlice_asyncThunk_blogApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchUpdateBlog.rejected.type */ .sf.rejected.type]: (state, action)=>{
            state.error.status = true;
            state.error.message = action.payload;
        // state.EditMode.id = null;
        // state.EditMode.open = false;
        },
        [_reducers_blogSlice_asyncThunk_blogApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchDeleteBlogItem.pending.type */ .FM.pending.type]: (state)=>{
            state.error.status = false;
            state.error.message = '';
        },
        [_reducers_blogSlice_asyncThunk_blogApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchDeleteBlogItem.rejected.type */ .FM.rejected.type]: (state, action)=>{
            state.error.status = true;
            state.error.message = action.payload;
        }
    }
});
const { deletePostItem , updateEditMode , updateBlogData  } = blogSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (blogSlice.reducer);


/***/ })

};
;