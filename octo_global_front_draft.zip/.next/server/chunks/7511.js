"use strict";
exports.id = 7511;
exports.ids = [7511];
exports.modules = {

/***/ 7511:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AccountOrders_AccountOrders)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/Account/AccountOrders/AccountOrdersTabs/AccountOrdersTabItem/style.ts

const useAccountOrdersTabItemStyles = ()=>{
    const ItemMUI = (0,material_.styled)('li')(()=>({
            listStyle: 'none',
            fontSize: '20px',
            lineHeight: '24px',
            marginBottom: '22px',
            fontWeight: 300
        })
    );
    const itemActive = {
        fontWeight: 400
    };
    return {
        ItemMUI,
        itemActive
    };
};

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./src/hooks/useCustomRouter.ts
var useCustomRouter = __webpack_require__(4763);
;// CONCATENATED MODULE: ./src/components/Account/AccountOrders/AccountOrdersTabs/AccountOrdersTabItem/AccountOrdersTabItem.tsx





const AccountOrdersTabItem = ({ title , link  })=>{
    const { router , getPathName  } = (0,useCustomRouter/* useCustomRouter */.c)();
    const dopItemStyles = (0,external_react_.useMemo)(()=>{
        if (getPathName().match(link.split('?')[0])) return itemActive;
        return {};
    }, [
        router
    ]);
    // UI
    return(/*#__PURE__*/ jsx_runtime_.jsx(ItemMUI, {
        sx: dopItemStyles,
        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
            href: link,
            children: title
        })
    }));
};
const { ItemMUI , itemActive ,  } = useAccountOrdersTabItemStyles();
/* harmony default export */ const AccountOrdersTabItem_AccountOrdersTabItem = (/*#__PURE__*/external_react_default().memo(AccountOrdersTabItem));

;// CONCATENATED MODULE: ./src/components/Account/AccountOrders/AccountOrdersTabs/style.ts

const useAccountOrdersTabStyles = ()=>{
    const ListMUI = (0,material_.styled)('ul')(({ theme  })=>({
            [theme.breakpoints.down(1025)]: {
                display: 'none'
            }
        })
    );
    return {
        ListMUI
    };
};

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./src/lib/services/services.ts
var services = __webpack_require__(4727);
// EXTERNAL MODULE: ./src/hooks/useUserStore.ts
var useUserStore = __webpack_require__(257);
;// CONCATENATED MODULE: ./src/components/Account/AccountOrders/AccountOrdersTabs/AccountOrdersTabs.tsx







const tabsData = [
    {
        title: 'Ожидаемые',
        link: '/account/orders/wait'
    },
    {
        title: 'На складе',
        link: '/account/orders/stock'
    },
    {
        title: 'Отправленные',
        link: '/account/orders/send'
    },
    {
        title: '+ Добавить',
        link: '/account/orders/add'
    }
];
const AccountOrdersTabs = ()=>{
    const router = (0,router_.useRouter)();
    const { 0: query , 1: setQuery  } = (0,external_react_.useState)('');
    const { isAdmin  } = (0,useUserStore/* useUserStore */.L)();
    (0,external_react_.useEffect)(()=>{
        const id = (0,services/* getLocationWindow */.I5)('userId=');
        const email = (0,services/* getLocationWindow */.I5)('userEmail=');
        let queryStr = '';
        if (isAdmin) {
            if (id) {
                queryStr += `?userId=${id}&`;
            }
            if (email) {
                queryStr += `userEmail=${email}`;
            }
            setQuery(queryStr);
        }
    }, [
        router,
        isAdmin
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(ListMUI, {
        children: tabsData.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(AccountOrdersTabItem_AccountOrdersTabItem, {
                title: item.title,
                link: item.link + query
            }, item.link)
        )
    }));
};
const { ListMUI  } = useAccountOrdersTabStyles();
/* harmony default export */ const AccountOrdersTabs_AccountOrdersTabs = (/*#__PURE__*/external_react_default().memo(AccountOrdersTabs));

// EXTERNAL MODULE: ./src/components/Account/AccountOrders/style.ts
var style = __webpack_require__(5958);
;// CONCATENATED MODULE: ./src/components/Account/AccountOrders/AccountOrders.tsx




const AccountOrders = ({ children , isTabs =true ,  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ContainerMUI, {
        children: [
            isTabs && /*#__PURE__*/ jsx_runtime_.jsx(AccountOrdersTabs_AccountOrdersTabs, {}),
            children
        ]
    }));
};
const { ContainerMUI  } = (0,style/* useAccountOrdersStyles */.q)();
/* harmony default export */ const AccountOrders_AccountOrders = (/*#__PURE__*/external_react_default().memo(AccountOrders));


/***/ }),

/***/ 5958:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ useAccountOrdersStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useAccountOrdersStyles = ()=>{
    const ContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('section')(({ theme  })=>({
            marginTop: '53px',
            display: 'flex',
            justifyContent: 'flex-start',
            [theme.breakpoints.down(1025)]: {
                marginTop: '15px'
            }
        })
    );
    const WrapperOrdersMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            width: '100%',
            display: 'flex',
            minHeight: '500px',
            flexDirection: 'column'
        })
    );
    const PageLabelMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('h2')(({ theme  })=>({
            fontSize: '18px',
            lineHeight: '22px',
            fontWeight: 400,
            color: '#274D82',
            marginBottom: '15px',
            [theme.breakpoints.up(1025)]: {
                display: 'none'
            },
            [theme.breakpoints.down(769)]: {
                fontSize: '14px',
                lineHeight: '16px'
            }
        })
    );
    const ListMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            marginLeft: '206px',
            minHeight: '400px',
            [theme.breakpoints.down(1200)]: {
                marginLeft: '106px'
            },
            [theme.breakpoints.down(1025)]: {
                marginLeft: '0px'
            }
        })
    );
    const PlaceholderWrapperMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            display: 'flex',
            margin: '11px 40px 51px 0',
            justifyContent: 'center',
            [theme.breakpoints.down(1100)]: {
                marginRight: '0'
            },
            [theme.breakpoints.down(710)]: {
                marginTop: '14px'
            }
        })
    );
    const PlaceholderTextMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('p')(({ theme  })=>({
            fontSize: '24px',
            lineHeight: '28px',
            fontWeight: 400,
            color: 'rgba(0, 0, 0, 0.5)',
            [theme.breakpoints.down(710)]: {
                fontSize: '16px',
                lineHeight: '19px'
            },
            [theme.breakpoints.down(350)]: {
                fontSize: '14px'
            }
        })
    );
    const PlaceholderLinkMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Link)(({ theme  })=>({
            color: '#274D82',
            fontSize: '24px',
            lineHeight: '28px',
            fontWeight: 400,
            textDecoration: 'none',
            [theme.breakpoints.down(710)]: {
                fontSize: '16px',
                lineHeight: '19px'
            },
            [theme.breakpoints.down(350)]: {
                fontSize: '14px'
            }
        })
    );
    return {
        ListMUI,
        PageLabelMUI,
        ContainerMUI,
        WrapperOrdersMUI,
        PlaceholderTextMUI,
        PlaceholderLinkMUI,
        PlaceholderWrapperMUI
    };
};


/***/ })

};
;