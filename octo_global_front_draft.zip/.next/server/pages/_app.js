"use strict";
(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 8696:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g, _defs;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgCloseModalIcon = function SvgCloseModalIcon(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 24,
    height: 24,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    clipPath: "url(#CloseModalIcon_svg__a)",
    stroke: "#817C7C",
    strokeWidth: 4,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "m5.363 5.364 12.728 12.728M5.363 18.092 18.091 5.364"
  }))), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("clipPath", {
    id: "CloseModalIcon_svg__a"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#fff",
    d: "M0 0h24v24H0z"
  })))));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgCloseModalIcon);

/***/ }),

/***/ 6542:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _rect, _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgHeaderMenu = function SvgHeaderMenu(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    width: 35,
    height: 35,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _rect || (_rect = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 35,
    height: 35,
    rx: 4,
    fill: "#274D82"
  })), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M4.375 8.75h26.25M4.375 17.5h26.25M4.375 26.25h26.25",
    stroke: "#fff",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgHeaderMenu);

/***/ }),

/***/ 5656:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _layout_MainLayout_MainLayout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7467);
/* harmony import */ var _src_store_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4097);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1127);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _layout_HeaderLayout_HeaderLayout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(990);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layout_MainLayout_MainLayout__WEBPACK_IMPORTED_MODULE_3__]);
_layout_MainLayout_MainLayout__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









function MyApp({ Component , pageProps  }) {
    const isActiveWebsite = true;
    return isActiveWebsite ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_2__.Provider, {
        store: _src_store_store__WEBPACK_IMPORTED_MODULE_4__/* .store */ .h,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_5__.PersistGate, {
            loading: null,
            persistor: _src_store_store__WEBPACK_IMPORTED_MODULE_4__/* .persistor */ .D,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_HeaderLayout_HeaderLayout__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_MainLayout_MainLayout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                        ...pageProps
                    })
                })
            })
        })
    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
        style: {
            textAlign: 'center'
        },
        children: "Работа сайта временно приостановлена"
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(MyApp));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7364:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Footer_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: ./src/UI/UIIcon/VKIconColor.svg
var _circle, _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgVkIconColor = function SvgVkIconColor(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 23,
    height: 23,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _circle || (_circle = /*#__PURE__*/external_react_.createElement("circle", {
    cx: 11,
    cy: 11,
    r: 9,
    fill: "#fff"
  })), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M11.5 23C17.851 23 23 17.851 23 11.5S17.851 0 11.5 0 0 5.149 0 11.5 5.149 23 11.5 23Zm6.89-15.6-.045-.087c-.031-.052-.11-.1-.238-.144a1.063 1.063 0 0 0-.492-.022l-2.21.017c-.036-.014-.087-.013-.154.005l-.1.026-.038.022-.03.026a.366.366 0 0 0-.085.092.623.623 0 0 0-.077.153c-.24.705-.514 1.361-.821 1.968-.19.361-.364.675-.522.94-.159.265-.292.46-.4.586a2.965 2.965 0 0 1-.29.301c-.088.076-.154.108-.2.097a4.695 4.695 0 0 1-.131-.035.561.561 0 0 1-.173-.215 1.062 1.062 0 0 1-.088-.34 4.183 4.183 0 0 1-.027-.355c-.002-.099-.001-.239.004-.42.005-.18.008-.303.008-.367 0-.221.003-.462.011-.721.008-.26.014-.465.02-.617.005-.152.007-.312.007-.48 0-.17-.009-.303-.027-.399a1.506 1.506 0 0 0-.08-.28.458.458 0 0 0-.158-.21.826.826 0 0 0-.257-.118 4.5 4.5 0 0 0-1.036-.113c-.952-.012-1.563.058-1.835.21a.94.94 0 0 0-.291.262c-.092.128-.105.198-.039.21.307.052.525.178.653.376l.046.105c.036.076.071.21.107.402.036.192.06.405.07.638.025.426.025.79 0 1.094-.026.303-.05.539-.074.708a1.569 1.569 0 0 1-.195.603.141.141 0 0 1-.039.044.512.512 0 0 1-.207.044c-.072 0-.159-.041-.26-.123a1.957 1.957 0 0 1-.32-.336 4.534 4.534 0 0 1-.372-.6c-.138-.256-.281-.559-.43-.909l-.122-.253a23.1 23.1 0 0 1-.315-.713c-.133-.312-.25-.614-.353-.905a.575.575 0 0 0-.184-.28l-.039-.026a.745.745 0 0 0-.3-.131l-2.102.017c-.215 0-.361.055-.438.166l-.03.053a.317.317 0 0 0-.024.14c0 .064.016.142.047.236.307.822.64 1.615 1.001 2.378.361.764.674 1.38.94 1.846.267.466.538.906.814 1.32.276.414.46.68.549.796.09.116.16.204.211.262l.192.21c.123.14.303.308.541.503.238.195.502.388.79.577.29.19.626.344 1.01.463.384.12.757.168 1.12.145h.883c.18-.018.315-.082.407-.193l.03-.043a.637.637 0 0 0 .059-.162c.017-.073.026-.153.026-.24-.005-.251.012-.477.05-.678.039-.201.082-.353.13-.455a1.114 1.114 0 0 1 .296-.385.463.463 0 0 1 .062-.03c.122-.047.267-.002.433.135.167.137.323.306.469.507.145.201.32.427.525.678.205.25.384.437.538.56l.153.105c.102.07.236.134.4.192a.761.761 0 0 0 .43.044l1.964-.035c.195 0 .346-.037.453-.11.108-.072.172-.153.192-.24a.768.768 0 0 0 .004-.297 1.198 1.198 0 0 0-.054-.232 1.306 1.306 0 0 0-.05-.11c-.256-.524-.744-1.168-1.466-1.932-.005-.012-.018-.023-.038-.035-.174-.18-.32-.335-.438-.463a1.254 1.254 0 0 1-.25-.377 2.151 2.151 0 0 1-.099-.301c-.018-.079.013-.201.092-.367.08-.167.157-.311.234-.433.077-.123.218-.333.422-.63.21-.309.377-.557.5-.743.885-1.341 1.268-2.198 1.15-2.571Z",
    fill: "#07F"
  })));
};

/* harmony default export */ const VKIconColor = (SvgVkIconColor);
// EXTERNAL MODULE: ./src/UI/UIIcon/WhatsappIconColor.svg
var WhatsappIconColor = __webpack_require__(1967);
;// CONCATENATED MODULE: ./src/UI/UIIcon/TelegramIconColor.svg
var TelegramIconColor_path, _path2;

function TelegramIconColor_extends() { TelegramIconColor_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return TelegramIconColor_extends.apply(this, arguments); }



var SvgTelegramIconColor = function SvgTelegramIconColor(props) {
  return /*#__PURE__*/external_react_.createElement("svg", TelegramIconColor_extends({
    width: 23,
    height: 23,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), TelegramIconColor_path || (TelegramIconColor_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M23 11.5C23 17.851 17.851 23 11.5 23S0 17.851 0 11.5 5.149 0 11.5 0 23 5.149 23 11.5Z",
    fill: "#22A0DC"
  })), _path2 || (_path2 = /*#__PURE__*/external_react_.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M17.027 7.056 6.187 11.74l2.448.974 3.158-2.345c.694-.515 1.566.338 1.102 1.077l-1.674 2.664 4.186 2.826 1.62-9.881Zm-.1-.993c.562-.242 1.163.248 1.062.866l-1.706 10.407c-.093.566-.72.848-1.187.533l-4.512-3.046a.81.81 0 0 1-.226-1.098l1.311-2.085-2.559 1.9a.755.755 0 0 1-.73.097l-2.886-1.148c-.649-.258-.662-1.198-.02-1.476l11.453-4.95Z",
    fill: "#fff"
  })));
};

/* harmony default export */ const TelegramIconColor = (SvgTelegramIconColor);
// EXTERNAL MODULE: ./src/hooks/useMedia.ts
var useMedia = __webpack_require__(2447);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/AnyPage/Footer/style.ts

const useFooterStyle = ()=>{
    const FooterWrapperUI = (0,material_.styled)('footer')(()=>({
            // height: '166px',
            background: '#274D82',
            color: '#FFFFFF',
            fontFamily: 'Roboto',
            position: 'relative',
            zIndex: '2'
        })
    );
    const FooterContentUI = (0,material_.styled)('div')(({ theme  })=>({
            // height: '166px',
            background: '#274D82',
            color: '#FFFFFF',
            fontFamily: 'Roboto',
            // padding: '25px 80px',
            maxWidth: '1440px',
            padding: '25px 80px 23px',
            margin: '0 auto',
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            [theme.breakpoints.down(1025)]: {
                padding: '15px'
            },
            [theme.breakpoints.down(801)]: {
                flexDirection: 'column',
                padding: '15px'
            }
        })
    );
    const FooterRowUI = (0,material_.styled)('div')(({ theme  })=>({
            display: 'flex',
            // flexDirection: 'row',
            gap: 20,
            [theme.breakpoints.down(801)]: {
                justifyContent: 'space-between',
                '& div:first-child': {
                    border: 'none',
                    padding: '0'
                },
                '& div:nth-child(2)': {
                    border: 'none',
                    padding: '0'
                }
            }
        })
    );
    const FooterRowIconsUI = (0,material_.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'row',
            '& svg': {
                marginRight: '13px',
                cursor: 'pointer'
            }
        })
    );
    const FooterColumnBlockUI = (0,material_.styled)('div')(({ theme  })=>({
            display: 'flex',
            flexDirection: 'column',
            [theme.breakpoints.down(801)]: {
                margin: '0 0 10px',
                padding: '0 0 10px',
                borderBottom: '1px solid rgba(223, 228, 236, 0.5)',
                '&:nth-child(1)': {
                    order: '2'
                },
                '&:nth-child(2)': {
                    order: '3'
                },
                '&:nth-child(3)': {
                    border: 'none',
                    order: '4',
                    margin: '0',
                    padding: '0'
                },
                '&:nth-child(4)': {
                    order: '1'
                }
            }
        })
    );
    const FooterColumnTitleUI = (0,material_.styled)('h6')(()=>({
            fontStyle: 'normal',
            fontWeight: '400',
            fontSize: '14px',
            lineHeight: '16px',
            marginBottom: '15px'
        })
    );
    const FooterColumnTextUI = (0,material_.styled)('a')(()=>({
            width: 'auto',
            fontStyle: 'normal',
            fontWeight: '300',
            fontSize: '14px',
            lineHeight: '16px',
            marginBottom: '15px',
            cursor: 'pointer',
            '&:last-child': {
                marginBottom: '0px'
            }
        })
    );
    const FooterColumnSocialBlockMUI = (0,material_.styled)('div')(()=>({})
    );
    const IndexTitleUI = (0,material_.styled)('a')(({ theme  })=>({
            fontStyle: 'normal',
            fontWeight: '400',
            fontSize: '14px',
            lineHeight: '16px',
            textDecorationLine: 'underline',
            color: '#FFFFFF',
            marginTop: '39px',
            display: 'block',
            [theme.breakpoints.down(801)]: {
                order: '5',
                marginTop: '10px',
                textAlign: 'center'
            }
        })
    );
    const FooterColumnTextMUI = (0,material_.styled)('a')(()=>({
            width: 'auto',
            fontStyle: 'normal',
            fontWeight: '500',
            fontSize: '14px',
            lineHeight: '16px',
            marginBottom: '15px',
            textDecoration: 'underline',
            cursor: 'pointer',
            '&:last-child': {
                marginBottom: '0px'
            }
        })
    );
    return {
        FooterWrapperUI,
        FooterContentUI,
        FooterRowUI,
        FooterColumnBlockUI,
        FooterColumnTitleUI,
        FooterColumnTextUI,
        IndexTitleUI,
        FooterRowIconsUI,
        FooterColumnTextMUI,
        FooterColumnSocialBlockMUI
    };
};

// EXTERNAL MODULE: ./src/UI/UIComponents/SvgLinkUI/SvgLinkUI.tsx + 1 modules
var SvgLinkUI = __webpack_require__(1115);
// EXTERNAL MODULE: ./src/lib/constants/constants.ts
var constants = __webpack_require__(4989);
// EXTERNAL MODULE: ./src/lib/services/services.ts
var services = __webpack_require__(4727);
;// CONCATENATED MODULE: ./src/components/AnyPage/Footer/Footer.tsx



//import InstIcon from '../../../UI/UIIcon/InstIcon.svg';
// import OdnoklasIcon from '../../../UI/UIIcon/OdnoklasIconColor.svg';







const Footer = ()=>{
    const { FooterWrapperUI , FooterContentUI , FooterRowUI , FooterColumnBlockUI , FooterColumnTitleUI , FooterColumnTextUI , IndexTitleUI , FooterRowIconsUI , FooterColumnTextMUI , FooterColumnSocialBlockMUI ,  } = useFooterStyle();
    const { isCustomSize  } = (0,useMedia/* useCustomSize */.ZB)(800);
    return(/*#__PURE__*/ jsx_runtime_.jsx(FooterWrapperUI, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FooterContentUI, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FooterColumnBlockUI, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTitleUI, {
                            children: "Полезное"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTextUI, {
                            href: "/shops",
                            children: "Список магазинов"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTextUI, {
                            href: "/questions?transfer",
                            children: "Стоимость посылки"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTextUI, {
                            href: "/questions",
                            children: "Частые вопросы"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FooterColumnBlockUI, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTitleUI, {
                            children: "Информация"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTextUI, {
                            href: "/reviews",
                            children: "Отзывы"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTextUI, {
                            href: "/blog",
                            children: "Блог"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FooterColumnBlockUI, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTitleUI, {
                            children: "Общая информация"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTextUI, {
                            href: "/aboutus",
                            children: "О нас"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTextUI, {
                            href: "/contacts",
                            children: "Контакты"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTextUI, {
                            href: "/lawinfo",
                            children: "Юридическая информация"
                        }),
                        isCustomSize ? /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTextMUI, {
                            href: "/contacts",
                            children: "Обратная связь"
                        }) : null
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnBlockUI, {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FooterRowUI, {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FooterColumnSocialBlockMUI, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTitleUI, {
                                        children: "Социальные сети"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FooterRowIconsUI, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(SvgLinkUI/* default */.Z, {
                                                href: "https://vk.com/club212299557",
                                                title: "vk",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(VKIconColor, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(SvgLinkUI/* default */.Z, {
                                                title: "telegram",
                                                href: "https://t.me/octoglobal",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(TelegramIconColor, {})
                                            })
                                        ]
                                    }),
                                    !isCustomSize && /*#__PURE__*/ jsx_runtime_.jsx(IndexTitleUI, {
                                        href: "https://www.index-studio.ru/",
                                        rel: "noopener noreferrer",
                                        target: "_blank",
                                        children: "Разработано студией INDEX"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FooterColumnSocialBlockMUI, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(FooterColumnTitleUI, {
                                        children: "Чаты поддержки"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FooterRowIconsUI, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(SvgLinkUI/* default */.Z, {
                                                title: "telegram",
                                                href: 'tg://resolve?domain=<@qwe>',
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(TelegramIconColor, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(SvgLinkUI/* default */.Z, {
                                                title: "whatsapp",
                                                // href={`https://api.whatsapp.com/send?phone=${SUPPORT_PHONE_RU}&text=Здавствуйте!`}
                                                href: (0,services/* WHATSAPP */.Q2)(constants/* SUPPORT_PHONE_RU */.ch),
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(WhatsappIconColor/* default */.Z, {})
                                            })
                                        ]
                                    }),
                                    !isCustomSize && /*#__PURE__*/ jsx_runtime_.jsx(IndexTitleUI, {
                                        href: "/contacts",
                                        children: "Обратная связь"
                                    })
                                ]
                            })
                        ]
                    })
                }),
                isCustomSize && /*#__PURE__*/ jsx_runtime_.jsx(IndexTitleUI, {
                    href: "https://www.index-studio.ru/",
                    rel: "noopener noreferrer",
                    target: "_blank",
                    children: "Разработано студией INDEX"
                })
            ]
        })
    }));
};
/* harmony default export */ const Footer_Footer = (/*#__PURE__*/external_react_default().memo(Footer));


/***/ }),

/***/ 251:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8125);
/* harmony import */ var _mui_material_Menu__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Menu__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _UI_UIIcon_HeaderMenu_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6542);
/* harmony import */ var _MobileHeader_MobileHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9103);
/* harmony import */ var _User_User__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3370);
/* harmony import */ var _AnyPage_Header_Logotip_Logotip__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7343);
/* harmony import */ var _hooks_useMedia__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2447);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(257);
/* harmony import */ var UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2907);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5498);
/* harmony import */ var _HeaderNavLink_HeaderNavLink__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6437);
/* harmony import */ var _HeaderNavLink_HeaderNavLinkData_json__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6847);
/* harmony import */ var _UI_UIIcon_WhatsAppLarge_svg__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8632);
/* harmony import */ var _components_AnyPage_Header_useHeader__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(250);
/* harmony import */ var _constants_constants__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(4989);
/* harmony import */ var UI_UIComponents_LinkUI_LinkUI__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3730);
/* harmony import */ var _components_AnyPage_Header_HeaderPayment_HeaderPayment__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8462);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4730);
/* harmony import */ var _hooks_usePayment__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(5850);
/* harmony import */ var _lib_services_services__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4727);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MobileHeader_MobileHeader__WEBPACK_IMPORTED_MODULE_5__, _components_AnyPage_Header_HeaderPayment_HeaderPayment__WEBPACK_IMPORTED_MODULE_17__]);
([_MobileHeader_MobileHeader__WEBPACK_IMPORTED_MODULE_5__, _components_AnyPage_Header_HeaderPayment_HeaderPayment__WEBPACK_IMPORTED_MODULE_17__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);























const Header = ()=>{
    const { adminSwitchIdToUser  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_18__/* .useAppSelector */ .C)((state)=>state.adminReducer
    );
    const { isMobile  } = (0,_hooks_useMedia__WEBPACK_IMPORTED_MODULE_8__/* .useMobile */ .XA)();
    const { isAuth , isAdmin  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_9__/* .useUserStore */ .L)();
    const { isCustomSize  } = (0,_hooks_useMedia__WEBPACK_IMPORTED_MODULE_8__/* .useCustomSize */ .ZB)(1240);
    const { isCustomSize: isTablet  } = (0,_hooks_useMedia__WEBPACK_IMPORTED_MODULE_8__/* .useCustomSize */ .ZB)(959);
    const navArray = _HeaderNavLink_HeaderNavLinkData_json__WEBPACK_IMPORTED_MODULE_13__;
    const { handlerPushToNav , handleClick , openBurger , handleListKeyDown , handlerPushAccount , handlerLogout , handleToggle , handleClose , handlerPushLogin , handleCloseBurger , anchorEl , anchorRef , open ,  } = (0,_components_AnyPage_Header_useHeader__WEBPACK_IMPORTED_MODULE_15__/* .useHeader */ .g)();
    const { handleOpenPaymentForm ,  } = (0,_hooks_usePayment__WEBPACK_IMPORTED_MODULE_19__/* .usePayment */ .V)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HeaderMarginMUI, {}),
            !isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HeaderWrapperUI, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(HeaderContentMUI, {
                    children: [
                        isCustomSize && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(HeaderBurgerButtonMUI, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                    onClick: handleClick,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIIcon_HeaderMenu_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Menu__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    id: "long-menu",
                                    MenuListProps: {
                                        'aria-labelledby': 'long-button'
                                    },
                                    anchorEl: anchorEl,
                                    open: openBurger,
                                    onClose: handleCloseBurger,
                                    PaperProps: {
                                        style: {
                                            maxHeight: '268px',
                                            width: '20ch'
                                        }
                                    },
                                    children: isCustomSize ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: [
                                            navArray.tablet.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                                    selected: option.title === 'Pyxis',
                                                    onClick: handlerPushToNav(option.href),
                                                    children: option.title
                                                }, option.title)
                                            ),
                                            isAuth && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: [
                                                    (!isAdmin || isAdmin && adminSwitchIdToUser) && isTablet && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                                        onClick: ()=>{
                                                            handleCloseBurger();
                                                            handleOpenPaymentForm();
                                                        },
                                                        children: "Кошелёк"
                                                    }, 'payment'),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                                        sx: {
                                                            color: '#203f69'
                                                        },
                                                        onClick: ()=>{
                                                            handlerLogout();
                                                            handleCloseBurger();
                                                        },
                                                        children: "Выход"
                                                    }, "exit")
                                                ]
                                            })
                                        ]
                                    }) : navArray.desktop.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                            selected: option.title === 'Pyxis',
                                            onClick: handlerPushToNav(option.href),
                                            children: option.title
                                        }, option.title)
                                    )
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LogoMUI, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_LinkUI_LinkUI__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                href: "/",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AnyPage_Header_Logotip_Logotip__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(HeaderNavUI, {
                            children: [
                                !isCustomSize && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HeaderNavLink_HeaderNavLink__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IconMarginRight, {
                                    // href={`https://api.whatsapp.com/send?phone=${SUPPORT_PHONE_RU}&text=Здавствуйте!`}
                                    href: (0,_lib_services_services__WEBPACK_IMPORTED_MODULE_20__/* .WHATSAPP */ .Q2)(_constants_constants__WEBPACK_IMPORTED_MODULE_21__/* .SUPPORT_PHONE_RU */ .ch),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIIcon_WhatsAppLarge_svg__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: !isAuth ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            style: ButtonLoginUI,
                                            onClick: handlerPushLogin,
                                            children: "Войти"
                                        })
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(UserWrapperUI, {
                                        ref: anchorRef,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                onClick: handlerPushAccount('/account/info'),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_User_User__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                id: "composition-button",
                                                "aria-controls": open ? 'composition-menu' : undefined,
                                                "aria-expanded": open ? 'true' : undefined,
                                                "aria-haspopup": "true",
                                                onClick: handleToggle,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ArrowUI, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Popper, {
                                                id: "popper",
                                                open: open,
                                                anchorEl: anchorRef.current,
                                                role: undefined,
                                                placement: "bottom-end",
                                                transition: true,
                                                disablePortal: true,
                                                children: ({ TransitionProps  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grow, {
                                                        ...TransitionProps,
                                                        style: {
                                                            transformOrigin: 'right bottom'
                                                        },
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Paper, {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ClickAwayListener, {
                                                                onClickAway: handleClose,
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuList, {
                                                                    autoFocusItem: open,
                                                                    id: "composition-menu",
                                                                    "aria-labelledby": "composition-button",
                                                                    onKeyDown: handleListKeyDown,
                                                                    children: [
                                                                        isAdmin ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                                                            onClick: handlerPushAccount('/account/info'),
                                                                            children: "Личные данные"
                                                                        }),
                                                                        isAdmin ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                                                            onClick: handlerPushAccount('/account/orders/wait'),
                                                                            children: "Заказы"
                                                                        }),
                                                                        isAdmin ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                                                            children: "Выкуп товара"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.MenuItem, {
                                                                            onClick: handlerLogout,
                                                                            style: {
                                                                                color: '#274D82'
                                                                            },
                                                                            children: "Выход"
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        })
                                                    })
                                            }),
                                            !isAdmin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_Header_HeaderPayment_HeaderPayment__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {}),
                                            isAdmin && adminSwitchIdToUser && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_Header_HeaderPayment_HeaderPayment__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {})
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MobileHeader_MobileHeader__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
        ]
    }));
};
const { HeaderMarginMUI , HeaderBurgerButtonMUI , HeaderWrapperUI , HeaderContentMUI , HeaderNavUI , UserWrapperUI , ButtonLoginUI , ArrowUI , LogoMUI , IconMarginRight  } = (0,_style__WEBPACK_IMPORTED_MODULE_11__/* .useHeaderStyle */ .J)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(Header));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6437:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(257);
/* harmony import */ var _hooks_useMedia__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2447);
/* harmony import */ var _UI_UIComponents_LinkUI_LinkUI__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3730);
/* harmony import */ var _HeaderNavLinkData_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6847);






const HeaderNavLink = ({ toggleOpenMenu  })=>{
    const navDataArray = _HeaderNavLinkData_json__WEBPACK_IMPORTED_MODULE_5__;
    const { isAuth , isAdmin  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_2__/* .useUserStore */ .L)();
    const { isMobile ,  } = (0,_hooks_useMedia__WEBPACK_IMPORTED_MODULE_3__/* .useMobile */ .XA)();
    const { isTablet  } = (0,_hooks_useMedia__WEBPACK_IMPORTED_MODULE_3__/* .useTablet */ .FJ)();
    const navLinksArray = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (isTablet) {
            return navDataArray.tablet;
        } else {
            return isMobile ? navDataArray.mobile : navDataArray.desktop;
        }
    }, [
        isMobile,
        isTablet
    ]);
    const linksArrAuth = navLinksArray.filter((item)=>{
        if (isMobile) {
            if (isAdmin && item.showAdmin) {
                return item;
            } else if (isAuth && !isAdmin && !item.showAdmin) {
                return item;
            } else if (!isAuth && !isAdmin && !item.showAuth) {
                {
                    return item;
                }
            }
        } else {
            return item;
        }
    });
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: linksArrAuth.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_LinkUI_LinkUI__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                href: option.href,
                onClick: toggleOpenMenu,
                children: option.title
            }, option.title)
        )
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(HeaderNavLink));


/***/ }),

/***/ 8462:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_AnyPage_Header_HeaderPayment_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6942);
/* harmony import */ var _components_AnyPage_Header_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5498);
/* harmony import */ var _components_AnyPage_Header_HeaderPayment_useHeaderPayment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4459);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(257);
/* harmony import */ var _components_AnyPage_Header_HeaderPayment_PaymentForm_PaymentForm__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1830);
/* harmony import */ var _UI_UIComponents_ModalUI_ModalUI__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1705);
/* harmony import */ var _components_AnyPage_Header_HeaderPayment_PaymentHistoryList_PaymentHistoryList__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3695);
/* harmony import */ var _components_AnyPage_Header_HeaderPayment_PaymentUserBalance_PaymentUserBalance__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7300);
/* harmony import */ var _UIIcon_CloseModalIcon_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8696);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_AnyPage_Header_HeaderPayment_PaymentForm_PaymentForm__WEBPACK_IMPORTED_MODULE_6__]);
_components_AnyPage_Header_HeaderPayment_PaymentForm_PaymentForm__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












const HeaderPayment = ()=>{
    const { isAdmin  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_5__/* .useUserStore */ .L)();
    const { isMobile , isOpenModal , isMenuOpen , statusMessage , handleToggleMenuOpen , handleSendUserEmailReq , handleResetStatusMessagePaymentReducer ,  } = (0,_components_AnyPage_Header_HeaderPayment_useHeaderPayment__WEBPACK_IMPORTED_MODULE_4__/* .useHeaderPayment */ .x)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContainerMUI, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BalanceTextButtonMUI, {
                onClick: handleToggleMenuOpen,
                disableRipple: true,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_Header_HeaderPayment_PaymentUserBalance_PaymentUserBalance__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ArrowUI, {})
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MenuListMUI, {
                open: isMenuOpen,
                id: "long-menu",
                MenuListProps: {
                    'aria-labelledby': 'long-button'
                },
                disableScrollLock: !isMobile,
                onClose: handleToggleMenuOpen,
                children: [
                    isMobile && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ContainerMobileMUI, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CloseModalButtonMUI, {
                                    onClick: handleToggleMenuOpen,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UIIcon_CloseModalIcon_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.Box, {
                                component: "div",
                                sx: {
                                    paddingLeft: '15px',
                                    marginTop: '58px',
                                    marginBottom: '23px'
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_Header_HeaderPayment_PaymentUserBalance_PaymentUserBalance__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {})
                            })
                        ]
                    }),
                    !isAdmin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ButtonSendMUI, {
                            onClick: handleSendUserEmailReq,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PayIconMUI, {}),
                                " Заявка на пополнение кошелька"
                            ]
                        })
                    }),
                    isAdmin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_Header_HeaderPayment_PaymentForm_PaymentForm__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_Header_HeaderPayment_PaymentHistoryList_PaymentHistoryList__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        isMobile: isMobile
                    })
                ]
            }),
            !isAdmin && isOpenModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_ModalUI_ModalUI__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                dialogProps: {
                    open: isOpenModal,
                    onClose: ()=>handleResetStatusMessagePaymentReducer('')
                },
                loading: !statusMessage,
                title: statusMessage,
                closeTime: 8
            })
        ]
    }));
};
const { PayIconMUI , MenuListMUI , ContainerMUI , ButtonSendMUI , CloseModalButtonMUI , ContainerMobileMUI , BalanceTextButtonMUI ,  } = (0,_components_AnyPage_Header_HeaderPayment_style__WEBPACK_IMPORTED_MODULE_2__/* .useHeaderPaymentStyles */ .Z)();
const { ArrowUI ,  } = (0,_components_AnyPage_Header_style__WEBPACK_IMPORTED_MODULE_3__/* .useHeaderStyle */ .J)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(HeaderPayment));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1830:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_AnyPage_Header_HeaderPayment_PaymentForm_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2611);
/* harmony import */ var _components_AnyPage_Header_HeaderPayment_PaymentForm_usePaymentForm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3831);
/* harmony import */ var _UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8595);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_AnyPage_Header_HeaderPayment_PaymentForm_usePaymentForm__WEBPACK_IMPORTED_MODULE_3__, _UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_4__]);
([_components_AnyPage_Header_HeaderPayment_PaymentForm_usePaymentForm__WEBPACK_IMPORTED_MODULE_3__, _UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const PaymentForm = ()=>{
    const { control , onSubmit , handleSubmit , statusMessage ,  } = (0,_components_AnyPage_Header_HeaderPayment_PaymentForm_usePaymentForm__WEBPACK_IMPORTED_MODULE_3__/* .usePaymentForm */ .H)();
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ContainerMUI, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FormContainerMUI, {
            onSubmit: handleSubmit(onSubmit),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextFieldMUI, {
                    color: "#23D16A",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        controller: {
                            name: 'plus',
                            control,
                            defaultValue: '',
                            rules: {
                                max: {
                                    message: 'error',
                                    value: 10000000000000000
                                }
                            }
                        },
                        inputProps: {
                            placeholder: '+',
                            type: 'number'
                        }
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(TextFieldCommentContainerMUI, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextFieldMUI, {
                            maxWidth: false,
                            color: '#C4C4C4',
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                controller: {
                                    name: 'comment',
                                    control
                                },
                                inputProps: {
                                    placeholder: 'Назначение платежа'
                                }
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StatusMessageMUI, {
                            children: statusMessage
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SubmitButtonMUI, {
                            type: "submit",
                            children: "Применить"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextFieldMUI, {
                    color: "#F35151",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_TextFIeldUI_TextFieldUI__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        controller: {
                            name: 'minus',
                            control,
                            rules: {
                                max: {
                                    message: 'error',
                                    value: 10000000000000000
                                }
                            }
                        },
                        inputProps: {
                            placeholder: '-',
                            type: 'number'
                        }
                    })
                })
            ]
        })
    }));
};
const { ContainerMUI , SubmitButtonMUI , FormContainerMUI , TextFieldMUI , StatusMessageMUI , TextFieldCommentContainerMUI ,  } = (0,_components_AnyPage_Header_HeaderPayment_PaymentForm_style__WEBPACK_IMPORTED_MODULE_2__/* .usePaymentFormStyles */ .E)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(PaymentForm));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2611:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ usePaymentFormStyles)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2907);


const usePaymentFormStyles = ()=>{
    const ContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            padding: '0 15px'
        })
    );
    const FormContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('form')(({ theme  })=>({
            display: 'flex',
            [theme.breakpoints.down(969)]: {
                flexWrap: 'wrap'
            }
        })
    );
    const TextFieldMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div', {
        shouldForwardProp: (prop)=>prop !== 'success'
    })(({ color , maxWidth , theme  })=>({
            maxWidth: maxWidth ? '92px' : 'none',
            width: '100%',
            '& > div': {
                '& .MuiFormControl-root': {
                    height: '39px',
                    '& .MuiOutlinedInput-root': {
                        '& > input': {
                            fontSize: '16px',
                            '&::placeholder': {
                                color: color,
                                fontSize: '16px',
                                lineHeight: '19px'
                            }
                        },
                        '& > input[type=number]': {
                            '-moz-appearance': 'textfield'
                        },
                        '& > input::-webkit-outer-spin-button, input::-webkit-inner-spin-button': {
                            '-webkit-appearance': 'none',
                            margin: 0
                        },
                        '& > fieldset': {
                            border: `1px solid ${color}`
                        }
                    }
                }
            },
            [theme.breakpoints.down(969)]: {
                order: color == '#23D16A' ? 1 : color === '#F35151' ? 2 : 3,
                width: color == '#23D16A' ? 'calc(50% - 8px)' : color === '#F35151' ? 'calc(50% - 8px)' : '100%',
                marginRight: color == '#23D16A' ? '15px' : 0,
                '& > div': {
                    '& .MuiFormControl-root': {
                        borderRadius: '10px',
                        backgroundColor: 'rgba(0, 0, 0, 0.0)'
                    }
                }
            },
            [theme.breakpoints.down(350)]: {}
        })
    );
    const TextFieldCommentContainerMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            minWidth: '275px',
            margin: '0 10px',
            display: 'flex',
            flexDirection: 'column',
            width: '100%',
            alignItems: 'flex-end',
            [theme.breakpoints.down(969)]: {
                margin: '0',
                width: ' 100%',
                order: 3,
                marginTop: '15px'
            }
        })
    );
    const StatusMessageMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('p')(({ theme  })=>({
            fontSize: '14px',
            lineHeight: '16px',
            marginTop: '3px',
            minHeight: '16px',
            [theme.breakpoints.down(969)]: {
                order: 4,
                fontSize: '12px',
                lineHeight: '12px',
                minHeight: '12px'
            }
        })
    );
    const SubmitButtonMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(({ theme  })=>({
            marginTop: '4px',
            maxWidth: '135px',
            fontWeight: 400,
            fontSize: '14px',
            lineHeight: '16px',
            height: '32px',
            marginBottom: 0,
            [theme.breakpoints.down(969)]: {
                order: 5
            }
        })
    );
    return {
        ContainerMUI,
        SubmitButtonMUI,
        TextFieldMUI,
        FormContainerMUI,
        StatusMessageMUI,
        TextFieldCommentContainerMUI
    };
};


/***/ }),

/***/ 3831:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ usePaymentForm)
/* harmony export */ });
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5641);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(257);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4730);
/* harmony import */ var _reducers_paymentSlice_asyncThunk_paymentApi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6233);
/* harmony import */ var _hooks_usePayment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5850);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_0__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const usePaymentForm = ()=>{
    const { control , watch , setValue , reset , handleSubmit ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_0__.useForm)({
        defaultValues: {
            minus: '',
            plus: '',
            comment: ''
        }
    });
    const { user  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_2__/* .useUserStore */ .L)();
    const { adminSwitchIdToUser , adminSwitchUserModel  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_3__/* .useAppSelector */ .C)((state)=>state.adminReducer
    );
    const { statusMessage , handleGetHistoryOperation , handleResetStatusMessagePaymentReducer , handleUpdateUserBalance ,  } = (0,_hooks_usePayment__WEBPACK_IMPORTED_MODULE_5__/* .usePayment */ .V)();
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_3__/* .useAppDispatch */ .T)();
    const formValues = watch();
    const minusValue = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return formValues.minus;
    }, [
        formValues.minus
    ]);
    const plusValue = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return formValues.plus;
    }, [
        formValues.plus
    ]);
    const onSubmit = (data)=>{
        if (data.minus && typeof +data.minus === 'number' && +data.minus || data.plus && typeof +data.plus === 'number' && +data.plus) {
            const userId = adminSwitchIdToUser ? adminSwitchIdToUser : user === null || user === void 0 ? void 0 : user.id;
            const sendData = {
                userId: userId,
                comment: data.comment,
                amount: +((data.minus ? -+data.minus : +data.plus) * 100).toFixed(2)
            };
            dispatch((0,_reducers_paymentSlice_asyncThunk_paymentApi__WEBPACK_IMPORTED_MODULE_4__/* .fetchAdminAddPaymentInUser */ .Q6)(sendData)).then((r)=>{
                const response = r.payload;
                const message = response === null || response === void 0 ? void 0 : response.message;
                if (message == 'Платеж успешно проведён') {
                    reset({});
                    handleGetHistoryOperation();
                    handleUpdateUserBalance(sendData.amount);
                    handleResetStatusMessagePaymentReducer('Платеж успешно проведён');
                }
            });
            return;
        // handleResetStatusMessagePaymentReducer('Недостаточно средств на балансе!');
        // return;
        }
        handleResetStatusMessagePaymentReducer('Введите корректные значения');
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (minusValue.length) {
            setValue('plus', '');
        }
    }, [
        minusValue
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (plusValue.length) {
            setValue('minus', '');
        }
    }, [
        plusValue
    ]);
    return {
        control,
        onSubmit,
        handleSubmit,
        statusMessage
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3695:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ PaymentHistoryList_PaymentHistoryList)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./src/hooks/usePayment.ts
var usePayment = __webpack_require__(5850);
;// CONCATENATED MODULE: ./src/components/AnyPage/Header/HeaderPayment/PaymentHistoryList/usePaymentHistoryList.ts


const usePaymentHistoryList = ()=>{
    const { handleGetHistoryOperation , userHistoryBalance , loadingHistoryBalance ,  } = (0,usePayment/* usePayment */.V)();
    const { 0: isListHidden , 1: setIsListHidden  } = (0,external_react_.useState)(true);
    const isHistoryBalanceArray = (0,external_react_.useMemo)(()=>!loadingHistoryBalance && Array.isArray(userHistoryBalance)
    , [
        userHistoryBalance,
        loadingHistoryBalance
    ]);
    const handleIsOpenList = ()=>{
        setIsListHidden(false);
    };
    (0,external_react_.useEffect)(()=>{
        handleGetHistoryOperation();
    }, []);
    return {
        isListHidden,
        handleIsOpenList,
        userHistoryBalance,
        isHistoryBalanceArray
    };
};

// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/UI/UIIcon/BottomArrow.svg
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgBottomArrow = function SvgBottomArrow(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 8,
    height: 13,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M3.646 12.354a.5.5 0 0 0 .708 0l3.182-3.182a.5.5 0 1 0-.708-.708L4 11.293 1.172 8.464a.5.5 0 1 0-.708.708l3.182 3.182ZM3.5.5V12h1V.5h-1Z",
    fill: "#C4C4C4"
  })));
};

/* harmony default export */ const BottomArrow = (SvgBottomArrow);
;// CONCATENATED MODULE: ./src/components/AnyPage/Header/HeaderPayment/PaymentHistoryList/style.ts


const usePaymentHistoryListStyles = ()=>{
    const ContainerMUI = (0,material_.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            padding: '0px 15px'
        })
    );
    const ListMUI = (0,material_.styled)(ContainerMUI, {
        shouldForwardProp: (prop)=>!!prop
    })(({ theme , hiddenList  })=>({
            marginTop: '25px',
            width: '100%',
            padding: 0,
            maxHeight: '45vh',
            '& > *:last-child': {},
            [theme.breakpoints.down(969)]: {
                maxHeight: 'none',
                '& > *:nth-child(3)': {
                    marginBottom: hiddenList ? '0px' : '15px'
                },
                '& > *:nth-child(1n + 4)': {
                    display: hiddenList ? 'none' : 'visible'
                }
            }
        })
    );
    const CircularProgressMUI = (0,material_.styled)(material_.CircularProgress)(()=>({
            color: '#274D82',
            marginBottom: '18px',
            marginTop: '25px'
        })
    );
    const MoreItemButtonMUI = (0,material_.styled)(material_.Button)(()=>({
            textTransform: 'none',
            fontWeight: 400,
            fontSize: '14px',
            lineHeight: '16px',
            color: '#C4C4C4',
            padding: '2px',
            marginTop: '25px'
        })
    );
    const BottomArrowMUI = (0,material_.styled)(BottomArrow)(()=>({
            marginLeft: '10px'
        })
    );
    return {
        ListMUI,
        ContainerMUI,
        BottomArrowMUI,
        MoreItemButtonMUI,
        CircularProgressMUI
    };
};

// EXTERNAL MODULE: ./src/UI/UIComponents/ButtonUI/ButtonUI.tsx + 1 modules
var ButtonUI = __webpack_require__(2907);
;// CONCATENATED MODULE: ./src/components/AnyPage/Header/HeaderPayment/PaymentHistoryItem/style.ts


const usePaymentHistoryItemStyles = ()=>{
    const CollapseContainerMUI = (0,material_.styled)(material_.Collapse)(({ theme  })=>({
            [theme.breakpoints.down(501)]: {}
        })
    );
    const ContainerMUI = (0,material_.styled)('div')(()=>({
            width: '100%',
            marginBottom: '15px'
        })
    );
    const WrapperMUI = (0,material_.styled)('a')(()=>({
            display: 'flex',
            position: 'relative',
            justifyContent: 'space-between',
            cursor: 'pointer'
        })
    );
    const MoneyTextMUI = (0,material_.styled)('div', {
        shouldForwardProp: (propName)=>propName !== ''
    })(({ color , theme  })=>({
            fontSize: '20px',
            lineHeight: '24px',
            fontWeight: 300,
            color: color,
            marginRight: '25px',
            minWidth: '70px',
            [theme.breakpoints.down(969)]: {
                fontSize: '14px',
                lineHeight: '16px',
                fontWeight: 400,
                marginRight: '5px'
            }
        })
    );
    const CommentTextMUI = (0,material_.styled)('p')(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '24px',
            fontWeight: 300,
            maxWidth: '263px',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            color: '#000000',
            flexGrow: 1,
            transition: '.2s all linear',
            [theme.breakpoints.down(969)]: {
                fontSize: '14px',
                lineHeight: '16px',
                maxWidth: '189px'
            },
            [theme.breakpoints.down(350)]: {
                maxWidth: '169px'
            }
        })
    );
    const DateTextMUI = (0,material_.styled)('div')(({ theme  })=>({
            color: '#C4C4C4',
            fontSize: '20px',
            lineHeight: '24px',
            minWidth: '77px',
            textAlign: 'right',
            fontWeight: 300,
            [theme.breakpoints.down(969)]: {
                fontSize: '14px',
                lineHeight: '16px',
                minWidth: '50px'
            }
        })
    );
    const TimeMUI = (0,material_.styled)('time')(()=>({})
    );
    const DeleteTransactionButtonSC = (0,material_.styled)(ButtonUI/* default */.Z)(({ theme  })=>({
            marginTop: '5px',
            marginBottom: '0',
            minWidth: '171px',
            fontWeight: 400,
            height: '32px',
            padding: '8px',
            [theme.breakpoints.down(501)]: {
                display: 'none'
            }
        })
    );
    const DeleteTransactionButtonTabletSC = (0,material_.styled)(ButtonUI/* default */.Z)(({ theme , isVisible  })=>({
            display: 'none',
            [theme.breakpoints.down(501)]: {
                display: isVisible ? 'block' : 'none',
                marginTop: '10px',
                backgroundColor: 'transparent',
                color: '#234A82',
                textDecoration: 'underline',
                padding: 0,
                height: '19px',
                width: '165px',
                '&:hover': {
                    backgroundColor: 'inherit',
                    textDecoration: 'underline'
                }
            }
        })
    );
    return {
        TimeMUI,
        WrapperMUI,
        DateTextMUI,
        ContainerMUI,
        MoneyTextMUI,
        CommentTextMUI,
        CollapseContainerMUI,
        DeleteTransactionButtonSC,
        DeleteTransactionButtonTabletSC
    };
};

// EXTERNAL MODULE: ./src/lib/services/services.ts
var services = __webpack_require__(4727);
// EXTERNAL MODULE: ./src/store/reducers/paymentSlice/asyncThunk/paymentApi.ts
var paymentApi = __webpack_require__(6233);
// EXTERNAL MODULE: ./src/hooks/useReduxHooks.ts
var useReduxHooks = __webpack_require__(4730);
// EXTERNAL MODULE: ./src/hooks/useUserStore.ts
var useUserStore = __webpack_require__(257);
;// CONCATENATED MODULE: ./src/components/AnyPage/Header/HeaderPayment/PaymentHistoryItem/usePaymentHistoryItem.ts




const usePaymentHistoryItem = (amount)=>{
    const dispatch = (0,useReduxHooks/* useAppDispatch */.T)();
    const { 0: isCollapseOpen , 1: seIsCollapseOpen  } = (0,external_react_.useState)(false);
    const { isAdmin  } = (0,useUserStore/* useUserStore */.L)();
    const handleToggleCollapse = ()=>{
        seIsCollapseOpen((prevState)=>!prevState
        );
    };
    const amountData = (0,external_react_.useMemo)(()=>{
        if (amount >= 0) return {
            color: '#23D16A',
            operation: '+',
            sum: (amount / 100).toFixed(2)
        };
        return {
            color: '#F35151',
            operation: '-',
            sum: ((amount - amount - amount) / 100).toFixed(2)
        };
    }, [
        amount
    ]);
    const payTextMarginStyle = (0,external_react_.useMemo)(()=>{
        let styleObj = {};
        if (amount >= 1000) {
            styleObj = {
                marginRight: '19px'
            };
        }
        if (amount >= 10000) {
            styleObj = {
                marginRight: '7px'
            };
        }
        if (amount >= 100000) {
            styleObj = {
                marginRight: '5px'
            };
        }
        return styleObj;
    }, [
        amount
    ]);
    const commentOpenStyle = (0,external_react_.useMemo)(()=>{
        if (isCollapseOpen) {
            return {
                wordWrap: 'break-word',
                overflow: 'visible',
                whiteSpace: 'break-spaces'
            };
        }
        return {};
    }, [
        isCollapseOpen
    ]);
    const handleDeleteTransaction = (operationId, operationSum)=>{
        return (e)=>{
            e.stopPropagation();
            dispatch((0,paymentApi/* fetchDeleteTransaction */.lF)({
                operationId,
                operationSum
            }));
        };
    };
    return {
        isAdmin,
        amountData,
        isCollapseOpen,
        commentOpenStyle,
        payTextMarginStyle,
        handleToggleCollapse,
        handleDeleteTransaction
    };
};

;// CONCATENATED MODULE: ./src/components/AnyPage/Header/HeaderPayment/PaymentHistoryItem/PaymentHistoryItem.tsx





const PaymentHistoryItem = ({ amount , comment , createdTime , id  })=>{
    const { isAdmin , amountData , isCollapseOpen , commentOpenStyle , payTextMarginStyle , handleToggleCollapse , handleDeleteTransaction ,  } = usePaymentHistoryItem(amount);
    return(/*#__PURE__*/ jsx_runtime_.jsx(ContainerMUI, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(WrapperMUI, {
            onClick: handleToggleCollapse,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MoneyTextMUI, {
                    color: amountData.color,
                    sx: payTextMarginStyle,
                    children: [
                        amountData.operation,
                        " ",
                        amountData.sum,
                        " €"
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CommentTextMUI, {
                    sx: commentOpenStyle,
                    children: [
                        comment,
                        isAdmin && /*#__PURE__*/ jsx_runtime_.jsx(DeleteTransactionButtonTabletSC, {
                            onClick: handleDeleteTransaction(id, amount),
                            isVisible: isCollapseOpen,
                            children: "Удалить транзакцию"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(DateTextMUI, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(TimeMUI, {
                            children: (0,services/* ToDefaultDate */.bD)(createdTime)
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CollapseContainerMUI, {
                            in: isCollapseOpen,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(DateTextMUI, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(TimeMUI, {
                                        children: (0,services/* ToDefaultTime */.z$)(createdTime)
                                    })
                                }),
                                isAdmin && /*#__PURE__*/ jsx_runtime_.jsx(DeleteTransactionButtonSC, {
                                    onClick: handleDeleteTransaction(id, amount),
                                    children: "Удалить транзакцию"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    }));
};
const { TimeMUI , DateTextMUI , ContainerMUI , WrapperMUI , MoneyTextMUI , CommentTextMUI , CollapseContainerMUI , DeleteTransactionButtonSC , DeleteTransactionButtonTabletSC ,  } = usePaymentHistoryItemStyles();
/* harmony default export */ const PaymentHistoryItem_PaymentHistoryItem = (/*#__PURE__*/external_react_default().memo(PaymentHistoryItem));

;// CONCATENATED MODULE: ./src/components/AnyPage/Header/HeaderPayment/PaymentHistoryList/PaymentHistoryList.tsx





const PaymentHistoryList = ({ isMobile =false  })=>{
    const { isListHidden , handleIsOpenList , userHistoryBalance , isHistoryBalanceArray ,  } = usePaymentHistoryList();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(PaymentHistoryList_ContainerMUI, {
        children: [
            !isHistoryBalanceArray && /*#__PURE__*/ jsx_runtime_.jsx(CircularProgressMUI, {
                color: "inherit"
            }),
            !!isHistoryBalanceArray && !!userHistoryBalance.length && /*#__PURE__*/ jsx_runtime_.jsx(ListMUI, {
                hiddenList: isListHidden,
                children: userHistoryBalance.map((balanceItem)=>/*#__PURE__*/ jsx_runtime_.jsx(PaymentHistoryItem_PaymentHistoryItem, {
                        ...balanceItem
                    }, balanceItem.id)
                )
            }),
            isListHidden && isMobile && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MoreItemButtonMUI, {
                onClick: handleIsOpenList,
                children: [
                    "Загрузить ещё ",
                    /*#__PURE__*/ jsx_runtime_.jsx(BottomArrowMUI, {})
                ]
            })
        ]
    }));
};
const { ListMUI , ContainerMUI: PaymentHistoryList_ContainerMUI , BottomArrowMUI , MoreItemButtonMUI , CircularProgressMUI ,  } = usePaymentHistoryListStyles();
/* harmony default export */ const PaymentHistoryList_PaymentHistoryList = (/*#__PURE__*/external_react_default().memo(PaymentHistoryList));


/***/ }),

/***/ 7300:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_AnyPage_Header_HeaderPayment_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6942);
/* harmony import */ var _hooks_usePayment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5850);




const PaymentUserBalance = ()=>{
    const { userBalance  } = (0,_hooks_usePayment__WEBPACK_IMPORTED_MODULE_3__/* .usePayment */ .V)();
    const currentBalance = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>userBalance ? userBalance : 0
    , [
        userBalance
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BalanceTextMUI, {
        children: [
            currentBalance,
            " €"
        ]
    }));
};
const { BalanceTextMUI  } = (0,_components_AnyPage_Header_HeaderPayment_style__WEBPACK_IMPORTED_MODULE_2__/* .useHeaderPaymentStyles */ .Z)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(PaymentUserBalance));


/***/ }),

/***/ 6942:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ useHeaderPaymentStyles)
});

// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/UI/UIIcon/AddPayIcon.svg
var _path, _circle;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgAddPayIcon = function SvgAddPayIcon(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 22,
    height: 22,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M15.43 10.487v.993H6.66v-.993h8.77ZM11.538 6.4v9.317h-1.055V6.4h1.055Z",
    fill: "#000"
  })), _circle || (_circle = /*#__PURE__*/external_react_.createElement("circle", {
    cx: 11,
    cy: 11,
    r: 10.5,
    stroke: "#000"
  })));
};

/* harmony default export */ const AddPayIcon = (SvgAddPayIcon);
;// CONCATENATED MODULE: ./src/components/AnyPage/Header/HeaderPayment/style.ts


const useHeaderPaymentStyles = ()=>{
    const ContainerMUI = (0,material_.styled)('div')(()=>({
            marginLeft: '21px',
            display: 'flex',
            alignItems: 'center',
            position: 'relative'
        })
    );
    const ContainerMobileMUI = (0,material_.styled)('div')(()=>({
            // marginTop: '58px',
            // marginBottom: '23px',
            padding: '0 15px'
        })
    );
    const BalanceTextMUI = (0,material_.styled)('div')(({ theme  })=>({
            fontSize: '18px',
            lineHeight: '21px',
            fontWeight: 400,
            color: '#000000',
            [theme.breakpoints.down(969)]: {
                fontSize: '16px',
                lineHeight: '19px',
                height: '19px',
                margin: '10px 0 17px',
                cursor: 'pointer'
            }
        })
    );
    const BalanceTextButtonMUI = (0,material_.styled)(material_.Button)(({ theme  })=>({
            minWidth: 'auto',
            width: '100% !important',
            border: 0,
            backgroundColor: 'transparent',
            [theme.breakpoints.down(969)]: {
                display: 'none'
            }
        })
    );
    const MenuListMUI = (0,material_.styled)(material_.Menu)(({ theme  })=>({
            maxWidth: '1440px',
            margin: '0 auto',
            '& .MuiPaper-root': {
                transition: 'none !important',
                width: '514px',
                borderRadius: '8px',
                boxShadow: '0px -4px 4px rgba(0, 0, 0, 0.1), 0px 4px 4px rgba(0, 0, 0, 0.15)',
                top: '61px !important',
                right: '80px !important',
                left: 'auto !important',
                [theme.breakpoints.down(1025)]: {
                    right: '15px !important'
                },
                [theme.breakpoints.down(969)]: {
                    backgroundColor: 'rgba(0, 0, 0, 0)',
                    boxShadow: 'none',
                    width: '100%',
                    maxWidth: 'none',
                    margin: 'auto',
                    top: '0px !important',
                    right: '0px !important',
                    paddingTop: '63px'
                },
                [theme.breakpoints.down(551)]: {
                    paddingTop: '0px'
                }
            },
            [theme.breakpoints.down(969)]: {
                maxWidth: '345px',
                margin: '0 auto',
                '& .MuiBackdrop-root': {
                    backgroundColor: 'rgba(255, 255, 255, 0.5)'
                }
            },
            [theme.breakpoints.down(601)]: {
                maxWidth: 'none',
                margin: 0
            }
        })
    );
    const ButtonSendMUI = (0,material_.styled)(material_.MenuItem)(({ theme  })=>({
            fontSize: '20px',
            lineHeight: '23px',
            fontWeight: 300,
            color: '#000000',
            textAlign: 'center',
            height: '30px',
            justifyContent: 'center',
            alignItems: 'center',
            [theme.breakpoints.down(969)]: {
                fontSize: '14px',
                lineHeight: '16px',
                height: '32px',
                padding: 0,
                minHeight: 'auto'
            }
        })
    );
    const PayIconMUI = (0,material_.styled)(AddPayIcon)(()=>({
            marginRight: '10px',
            width: '22px',
            height: '22px'
        })
    );
    const CloseModalButtonMUI = (0,material_.styled)(material_.Button)(()=>({
            position: 'absolute',
            cursor: 'pointer',
            right: '10px',
            top: '15px',
            minWidth: 'auto',
            padding: '5px'
        })
    );
    const ContainerAddPaymentMobileMUI = (0,material_.styled)('a')(()=>({
            display: 'flex',
            alignItems: 'center',
            cursor: 'pointer'
        })
    );
    const AddPaymentMobileMUI = (0,material_.styled)('a')(()=>({
            fontSize: '16px',
            lineHeight: '18px',
            fontWeight: 300,
            textDecoration: 'underline',
            color: '#274D82',
            margin: '10px 0 17px 10px'
        })
    );
    return {
        PayIconMUI,
        MenuListMUI,
        ContainerMUI,
        ButtonSendMUI,
        BalanceTextMUI,
        CloseModalButtonMUI,
        ContainerMobileMUI,
        AddPaymentMobileMUI,
        BalanceTextButtonMUI,
        ContainerAddPaymentMobileMUI
    };
};


/***/ }),

/***/ 4459:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "x": () => (/* binding */ useHeaderPayment)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hooks_usePayment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5850);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



const useHeaderPayment = ()=>{
    const { isOpenModal , isOpenPaymentForm , statusMessage , adminSwitchIdToUser , userBalance , handleSendUserEmailReq , handleTogglePaymentForm , handleResetHistoryBalance , handleResetStatusMessagePaymentReducer , isAdmin  } = (0,_hooks_usePayment__WEBPACK_IMPORTED_MODULE_1__/* .usePayment */ .V)();
    const isMobile = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)('(max-width: 959px)');
    const handleToggleMenuOpen = ()=>{
        handleTogglePaymentForm();
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (statusMessage && isAdmin) {
            setTimeout(()=>{
                handleResetStatusMessagePaymentReducer();
            }, 3000);
            return ()=>{
                handleResetStatusMessagePaymentReducer();
            };
        }
    }, [
        statusMessage
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (isAdmin) {
            handleResetHistoryBalance();
        }
    }, [
        adminSwitchIdToUser,
        isAdmin
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (isMobile) {
            const domNext = document.querySelector('#__next');
            const domDrawer = document.querySelector('#userDrawer');
            if (domNext) {
                domNext.style.filter = isOpenPaymentForm ? 'blur(8px)' : '';
            }
            if (domDrawer) {
                domDrawer.style.filter = isOpenPaymentForm ? 'blur(8px)' : '';
                domDrawer.style.backgroundColor = `${isOpenPaymentForm ? '#FFFFFF' : ''}`;
            }
        }
        if (!isMobile) {
            document.body.style.overflowY = isOpenPaymentForm ? 'hidden' : 'scroll';
            return ()=>{
                document.body.style.overflowY = 'scroll';
            };
        }
    }, [
        isOpenPaymentForm
    ]);
    return {
        isMobile,
        isOpenModal,
        userBalance,
        isMenuOpen: isOpenPaymentForm,
        statusMessage,
        handleToggleMenuOpen,
        handleSendUserEmailReq,
        handleResetStatusMessagePaymentReducer
    };
};


/***/ }),

/***/ 7343:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Logotip_Logotip)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./src/hooks/useCustomRouter.ts
var useCustomRouter = __webpack_require__(4763);
;// CONCATENATED MODULE: ./src/UI/UIIcon/OctoGlobal.svg
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgOctoGlobal = function SvgOctoGlobal(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 48,
    height: 34,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M32 0a15.2 15.2 0 0 0-8.002 2.281A15.179 15.179 0 0 0 16 0C7.162 0 0 7.61 0 17.002 0 26.388 7.162 34 16 34c2.916 0 5.646-.833 7.998-2.281A15.205 15.205 0 0 0 32 34c8.835 0 16-7.613 16-16.998C48 7.61 40.835 0 32 0Zm-8.942 2.907-.036.029.036-.03Zm1.877 28.189c.043-.031.084-.065.126-.097-.042.032-.083.066-.126.097Zm.903-.697.016-.014-.016.014Zm6.162-.64c-1.597 0-3.12-.332-4.514-.934A17.024 17.024 0 0 0 30 25.234c1.273-2.44 2-5.246 2-8.232 0-2.989-.727-5.794-2-8.234a7.858 7.858 0 0 0-3.492 2.056c.955 1.83 1.5 3.934 1.5 6.178 0 7.044-5.376 12.758-12.009 12.758S3.99 24.045 3.99 17.002C3.99 9.952 9.366 4.24 16 4.24c1.596 0 3.12.334 4.513.934a17.004 17.004 0 0 0-2.514 3.593c-1.272 2.44-2 5.245-2 8.234 0 2.985.728 5.79 2 8.23a7.869 7.869 0 0 0 3.49-2.056 13.323 13.323 0 0 1-1.499-6.174C19.99 9.952 25.367 4.24 32 4.24S44.008 9.952 44.008 17c0 7.045-5.376 12.758-12.01 12.758Z",
    fill: "#274D82"
  })));
};

/* harmony default export */ const OctoGlobal = (SvgOctoGlobal);
;// CONCATENATED MODULE: ./src/UI/UIIcon/OctoGlobalTextIcon.svg
var OctoGlobalTextIcon_path;

function OctoGlobalTextIcon_extends() { OctoGlobalTextIcon_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return OctoGlobalTextIcon_extends.apply(this, arguments); }



var SvgOctoGlobalTextIcon = function SvgOctoGlobalTextIcon(props) {
  return /*#__PURE__*/external_react_.createElement("svg", OctoGlobalTextIcon_extends({
    width: 90,
    height: 19,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), OctoGlobalTextIcon_path || (OctoGlobalTextIcon_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M5.04 5.442c.828 0 1.56.168 2.196.504.648.324 1.158.846 1.53 1.566.384.72.576 1.668.576 2.844S9.15 12.48 8.766 13.2c-.372.72-.882 1.242-1.53 1.566-.636.324-1.368.486-2.196.486-.828 0-1.566-.162-2.214-.486-.648-.324-1.158-.846-1.53-1.566-.372-.72-.558-1.668-.558-2.844s.186-2.124.558-2.844c.372-.72.882-1.242 1.53-1.566.648-.336 1.386-.504 2.214-.504Zm0 .36c-.564 0-1.026.36-1.386 1.08-.348.708-.522 1.866-.522 3.474s.174 2.766.522 3.474c.36.708.822 1.062 1.386 1.062.552 0 1.008-.354 1.368-1.062.36-.708.54-1.866.54-3.474s-.18-2.766-.54-3.474c-.36-.72-.816-1.08-1.368-1.08Zm10.09-.36c.445 0 .853.054 1.225.162.384.096.714.234.99.414.288.18.516.408.684.684.168.264.252.558.252.882 0 .396-.12.714-.36.954s-.54.36-.9.36c-.372 0-.678-.108-.918-.324-.228-.216-.342-.504-.342-.864 0-.348.102-.636.306-.864a1.44 1.44 0 0 1 .738-.45c-.108-.156-.276-.282-.504-.378a1.744 1.744 0 0 0-.756-.162c-.36 0-.684.096-.972.288-.288.18-.54.456-.756.828-.204.36-.366.81-.486 1.35a9.24 9.24 0 0 0-.162 1.836c0 .972.114 1.74.342 2.304.24.564.546.966.918 1.206.372.228.768.342 1.188.342.252 0 .522-.048.81-.144.288-.096.57-.258.846-.486.288-.228.546-.552.774-.972l.342.126a4.5 4.5 0 0 1-.648 1.26c-.288.42-.666.768-1.134 1.044-.468.276-1.038.414-1.71.414a4.213 4.213 0 0 1-2.088-.522c-.624-.36-1.122-.9-1.494-1.62-.36-.72-.54-1.614-.54-2.682 0-1.056.186-1.95.558-2.682.372-.744.888-1.314 1.548-1.71a4.349 4.349 0 0 1 2.25-.594Zm7.672-2.7v2.97h2.304v.36h-2.304v7.164c0 .432.078.738.234.918.156.18.378.27.666.27.276 0 .528-.102.756-.306.228-.216.432-.57.612-1.062l.324.144a3.59 3.59 0 0 1-.846 1.476c-.372.384-.9.576-1.584.576-.408 0-.756-.054-1.044-.162a1.991 1.991 0 0 1-.72-.432 2.165 2.165 0 0 1-.54-.99c-.084-.384-.126-.894-.126-1.53V6.072H18.95v-.36h1.584V3.21a7.44 7.44 0 0 0 1.206-.126 4.577 4.577 0 0 0 1.062-.342Zm7.463 2.7c.828 0 1.56.168 2.196.504.648.324 1.158.846 1.53 1.566.384.72.576 1.668.576 2.844s-.192 2.124-.576 2.844c-.372.72-.882 1.242-1.53 1.566-.636.324-1.368.486-2.196.486-.828 0-1.566-.162-2.214-.486-.648-.324-1.158-.846-1.53-1.566-.372-.72-.558-1.668-.558-2.844s.186-2.124.558-2.844c.372-.72.882-1.242 1.53-1.566.648-.336 1.386-.504 2.214-.504Zm0 .36c-.564 0-1.026.36-1.386 1.08-.348.708-.522 1.866-.522 3.474s.174 2.766.522 3.474c.36.708.822 1.062 1.386 1.062.552 0 1.008-.354 1.368-1.062.36-.708.54-1.866.54-3.474s-.18-2.766-.54-3.474c-.36-.72-.816-1.08-1.368-1.08Zm13.209 12.582c-.708 0-1.35-.066-1.926-.198-.576-.132-1.032-.33-1.368-.594-.336-.252-.504-.576-.504-.972 0-.384.168-.726.504-1.026.336-.3.828-.528 1.476-.684l.126.288a1.33 1.33 0 0 0-.522.54c-.12.228-.18.468-.18.72 0 .516.234.912.702 1.188.48.288 1.116.432 1.908.432a4.94 4.94 0 0 0 1.494-.216c.456-.144.822-.366 1.098-.666.276-.3.414-.672.414-1.116 0-.372-.138-.684-.414-.936-.264-.252-.798-.378-1.602-.378h-1.188c-.444 0-.852-.048-1.224-.144-.36-.096-.648-.252-.864-.468-.216-.216-.324-.516-.324-.9 0-.468.192-.888.576-1.26.384-.384.984-.756 1.8-1.116l.198.162c-.3.156-.57.324-.81.504a.836.836 0 0 0-.342.684c0 .384.264.576.792.576h2.034c.624 0 1.176.078 1.656.234.492.156.882.402 1.17.738.288.336.432.78.432 1.332 0 .576-.186 1.11-.558 1.602-.372.504-.936.906-1.692 1.206-.744.312-1.698.468-2.862.468Zm.162-7.218a5.132 5.132 0 0 1-1.764-.288 2.67 2.67 0 0 1-1.224-.936c-.3-.432-.45-.978-.45-1.638 0-.66.15-1.2.45-1.62.3-.42.708-.732 1.224-.936a4.86 4.86 0 0 1 1.764-.306c.66 0 1.248.102 1.764.306a2.67 2.67 0 0 1 1.224.936c.3.42.45.96.45 1.62 0 .66-.15 1.206-.45 1.638-.3.42-.708.732-1.224.936-.516.192-1.104.288-1.764.288Zm0-.324c.36 0 .642-.18.846-.54.216-.372.324-1.038.324-1.998s-.108-1.62-.324-1.98c-.204-.372-.486-.558-.846-.558s-.648.186-.864.558c-.204.36-.306 1.02-.306 1.98s.102 1.626.306 1.998c.216.36.504.54.864.54Zm2.718-3.87-.342-.126c.18-.444.474-.816.882-1.116.408-.312.84-.468 1.296-.468.348 0 .618.096.81.288.204.192.306.462.306.81 0 .36-.096.624-.288.792a.937.937 0 0 1-.63.252.882.882 0 0 1-.558-.198c-.168-.144-.264-.36-.288-.648-.024-.3.072-.672.288-1.116l.18.072c-.468.18-.816.378-1.044.594a3.064 3.064 0 0 0-.612.864ZM53.246.906v12.42c0 .504.09.846.27 1.026.193.18.51.27.955.27V15a38.31 38.31 0 0 0-.99-.036 24.02 24.02 0 0 0-1.333-.036c-.444 0-.9.012-1.367.036-.456.012-.798.024-1.026.036v-.378c.444 0 .755-.09.935-.27.193-.18.288-.522.288-1.026V3.066c0-.54-.084-.936-.252-1.188-.167-.264-.492-.396-.971-.396v-.378c.383.036.755.054 1.115.054.457 0 .883-.018 1.279-.054a9.003 9.003 0 0 0 1.097-.198Zm6.462 4.536c.828 0 1.56.168 2.196.504.648.324 1.158.846 1.53 1.566.384.72.576 1.668.576 2.844s-.192 2.124-.576 2.844c-.372.72-.882 1.242-1.53 1.566-.636.324-1.368.486-2.196.486-.828 0-1.566-.162-2.214-.486-.648-.324-1.158-.846-1.53-1.566-.372-.72-.558-1.668-.558-2.844s.186-2.124.558-2.844c.372-.72.882-1.242 1.53-1.566.648-.336 1.386-.504 2.214-.504Zm0 .36c-.564 0-1.026.36-1.386 1.08-.348.708-.522 1.866-.522 3.474s.174 2.766.522 3.474c.36.708.822 1.062 1.386 1.062.552 0 1.008-.354 1.368-1.062.36-.708.54-1.866.54-3.474s-.18-2.766-.54-3.474c-.36-.72-.816-1.08-1.368-1.08Zm11.387-.36c.936 0 1.716.396 2.34 1.188.636.78.954 1.968.954 3.564 0 1.188-.186 2.16-.558 2.916-.372.744-.87 1.29-1.494 1.638a4.223 4.223 0 0 1-2.034.504 3.603 3.603 0 0 1-1.494-.324 2.678 2.678 0 0 1-1.134-1.062h.306c.24.336.528.588.864.756.348.156.696.234 1.044.234.708 0 1.236-.366 1.584-1.098.348-.744.522-1.878.522-3.402 0-1.008-.072-1.818-.216-2.43-.132-.624-.33-1.074-.594-1.35a1.287 1.287 0 0 0-.99-.432c-.468 0-.9.198-1.296.594-.384.396-.606.96-.666 1.692l-.126-.504c.192-.792.552-1.404 1.08-1.836.54-.432 1.176-.648 1.908-.648ZM68.305.906V14.46c-.252.012-.51.06-.774.144a3.63 3.63 0 0 0-.738.288c-.228.108-.426.24-.594.396l-.288-.144c.06-.168.096-.336.108-.504a7.33 7.33 0 0 0 .018-.522V3.066c0-.54-.09-.936-.27-1.188-.168-.264-.486-.396-.954-.396v-.378c.384.036.756.054 1.116.054.456 0 .882-.018 1.278-.054a9.003 9.003 0 0 0 1.098-.198Zm9.794 14.22c-.516 0-.954-.096-1.314-.288a2.023 2.023 0 0 1-.81-.81 2.47 2.47 0 0 1-.27-1.152c0-.516.12-.936.36-1.26.24-.336.546-.6.918-.792a7.106 7.106 0 0 1 1.206-.504c.42-.144.816-.276 1.188-.396.372-.132.678-.282.918-.45.24-.168.36-.39.36-.666V7.494c0-.384-.06-.696-.18-.936A1.095 1.095 0 0 0 79.97 6c-.216-.132-.492-.198-.828-.198-.252 0-.516.036-.792.108a1.34 1.34 0 0 0-.684.414c.312.084.552.24.72.468.18.228.27.504.27.828 0 .372-.126.666-.378.882-.24.204-.546.306-.918.306-.396 0-.696-.126-.9-.378a1.36 1.36 0 0 1-.306-.882c0-.336.084-.612.252-.828.168-.228.402-.432.702-.612.3-.204.684-.366 1.152-.486a6.15 6.15 0 0 1 1.53-.18c.528 0 .996.06 1.404.18.408.108.756.306 1.044.594.288.276.474.618.558 1.026.084.408.126.906.126 1.494v4.932c0 .3.036.516.108.648.072.12.186.18.342.18.12 0 .234-.03.342-.09.108-.06.228-.144.36-.252l.198.306c-.264.204-.54.366-.828.486-.288.12-.636.18-1.044.18-.42 0-.756-.06-1.008-.18-.24-.12-.42-.294-.54-.522a2.065 2.065 0 0 1-.18-.81c-.288.48-.642.852-1.062 1.116-.42.264-.924.396-1.512.396Zm1.08-1.008c.288 0 .552-.078.792-.234.252-.156.48-.39.684-.702V9.546a1.71 1.71 0 0 1-.522.486c-.216.144-.45.288-.702.432a4.86 4.86 0 0 0-.72.504c-.216.18-.402.408-.558.684-.144.264-.216.606-.216 1.026 0 .468.114.828.342 1.08.228.24.528.36.9.36ZM88.174.906v12.42c0 .504.09.846.27 1.026.192.18.51.27.954.27V15a38.31 38.31 0 0 0-.99-.036 24.02 24.02 0 0 0-1.332-.036c-.444 0-.9.012-1.368.036-.456.012-.798.024-1.026.036v-.378c.444 0 .756-.09.936-.27.192-.18.288-.522.288-1.026V3.066c0-.54-.084-.936-.252-1.188-.168-.264-.492-.396-.972-.396v-.378c.384.036.756.054 1.116.054.456 0 .882-.018 1.278-.054a9.003 9.003 0 0 0 1.098-.198Z",
    fill: "#274D82"
  })));
};

/* harmony default export */ const OctoGlobalTextIcon = (SvgOctoGlobalTextIcon);
// EXTERNAL MODULE: external "gsap"
var external_gsap_ = __webpack_require__(4287);
;// CONCATENATED MODULE: ./src/components/AnyPage/Header/Logotip/Logotip.tsx








const OctoIconsUI = (0,material_.styled)('span')(()=>({
        width: 'auto',
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        visibility: 'hidden',
        '& svg': {
            cursor: 'pointer'
        },
        '& svg:first-child': {
            marginRight: '6px'
        }
    })
);
const Logotip = ()=>{
    const { router , pushTo  } = (0,useCustomRouter/* useCustomRouter */.c)();
    const logoRef = (0,external_react_.useRef)(null);
    const handlerPushHome = ()=>{
        pushTo('/');
    };
    const isLanding = (0,external_react_.useMemo)(()=>{
        if (router) {
            return router.pathname === '/';
        }
    }, [
        router
    ]);
    (0,external_react_.useEffect)(()=>{
        if (false) {}
    }, [
        router.pathname
    ]);
    return isLanding ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(OctoIconsUI, {
        onClick: handlerPushHome,
        ref: logoRef,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(OctoGlobal, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(OctoGlobalTextIcon, {})
        ]
    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(OctoIconsUI, {
        onClick: handlerPushHome,
        sx: {
            visibility: 'visible'
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(OctoGlobal, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(OctoGlobalTextIcon, {})
        ]
    });
};
/* harmony default export */ const Logotip_Logotip = (/*#__PURE__*/external_react_default().memo(Logotip));


/***/ }),

/***/ 8128:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _HeaderNavLink_HeaderNavLink__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6437);
/* harmony import */ var _layout_ContentLayout_ContentLayout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2755);
/* harmony import */ var _UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2907);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5346);
/* harmony import */ var _components_forms_SignUpForm_SignUpForm__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(924);
/* harmony import */ var _components_forms_LoginForm_LoginForm__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6231);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(257);
/* harmony import */ var _components_AnyPage_User_User__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3370);
/* harmony import */ var _components_AnyPage_FormComponent_FormComponent__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1839);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4730);
/* harmony import */ var _reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6213);
/* harmony import */ var _hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4763);
/* harmony import */ var _components_forms_ResetPasswordForm_ResetPasswordForm__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5760);
/* harmony import */ var _components_AnyPage_AuthFormPromt_LoginPromt_LoginPromt__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6139);
/* harmony import */ var _components_AnyPage_AuthFormPromt_SignUpPromt_SignUpPromt__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5443);
/* harmony import */ var _hooks_useSwipeableDrawerStore__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2655);
/* harmony import */ var _hooks_usePayment__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5850);
/* harmony import */ var _components_AnyPage_Header_HeaderPayment_style__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(6942);
/* harmony import */ var _components_AnyPage_Header_HeaderPayment_HeaderPayment__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(8462);
/* harmony import */ var _components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(239);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_forms_SignUpForm_SignUpForm__WEBPACK_IMPORTED_MODULE_6__, _components_forms_LoginForm_LoginForm__WEBPACK_IMPORTED_MODULE_7__, _components_forms_ResetPasswordForm_ResetPasswordForm__WEBPACK_IMPORTED_MODULE_14__, _components_AnyPage_Header_HeaderPayment_HeaderPayment__WEBPACK_IMPORTED_MODULE_20__, _components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_21__]);
([_components_forms_SignUpForm_SignUpForm__WEBPACK_IMPORTED_MODULE_6__, _components_forms_LoginForm_LoginForm__WEBPACK_IMPORTED_MODULE_7__, _components_forms_ResetPasswordForm_ResetPasswordForm__WEBPACK_IMPORTED_MODULE_14__, _components_AnyPage_Header_HeaderPayment_HeaderPayment__WEBPACK_IMPORTED_MODULE_20__, _components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_21__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






















const MenuAuthContent = ()=>{
    const { isAuth , isAdmin  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_8__/* .useUserStore */ .L)();
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_11__/* .useAppDispatch */ .T)();
    const { MenuLinksUI , ButtonsAuthUI , ButtonLogin , ButtonSignUp , UserUI , ExitLinkUI ,  } = (0,_style__WEBPACK_IMPORTED_MODULE_5__/* .useMenuAuthContentStyle */ .E)();
    const { userBalance , adminSwitchIdToUser , handleTogglePaymentForm ,  } = (0,_hooks_usePayment__WEBPACK_IMPORTED_MODULE_18__/* .usePayment */ .V)();
    const { toggleDrawer , openTab , toggleTab  } = (0,_hooks_useSwipeableDrawerStore__WEBPACK_IMPORTED_MODULE_17__/* .useSwipeableDrawerStore */ .h)();
    const { pushTo  } = (0,_hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_13__/* .useCustomRouter */ .c)();
    const toggleAuthForm = (trigger)=>{
        return ()=>{
            toggleTab(trigger);
        };
    };
    const handlerLogout = ()=>{
        dispatch((0,_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_12__/* .fetchUserLogout */ .rZ)()).then(()=>{
            pushTo('/');
            toggleTab('');
        });
    };
    const handlerPushToAccount = ()=>{
        toggleDrawer();
        pushTo('/account/info');
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_layout_ContentLayout_ContentLayout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        disabledPadding: true,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: isAuth ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UserUI, {
                            onClick: handlerPushToAccount,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_User_User__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                cutFio: false,
                                isChangeToAdmin: true
                            })
                        }),
                        isAdmin ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_EuroExchange_EuroExchange__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {}) : null,
                        isAuth && (!isAdmin || isAdmin && adminSwitchIdToUser) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContainerAddPaymentMobileMUI, {
                            onClick: handleTogglePaymentForm,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(BalanceTextMUI, {
                                    children: [
                                        userBalance ? userBalance : 0,
                                        " €"
                                    ]
                                }),
                                isAdmin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AddPaymentMobileMUI, {
                                    children: "пополнить"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MenuLinksUI, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HeaderNavLink_HeaderNavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    toggleOpenMenu: toggleDrawer
                                }),
                                isAuth && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ExitLinkUI, {
                                    onClick: handlerLogout,
                                    children: "Выйти"
                                })
                            ]
                        })
                    ]
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        openTab === 'login' && !isAuth && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_AnyPage_FormComponent_FormComponent__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            title: "Вход",
                            background: false,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_forms_LoginForm_LoginForm__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_AuthFormPromt_LoginPromt_LoginPromt__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                    onClickRegistr: toggleAuthForm('signup'),
                                    onClickRefreshPassword: toggleAuthForm('reset')
                                })
                            ]
                        }),
                        openTab === 'signup' && !isAuth && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_AnyPage_FormComponent_FormComponent__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            title: "Регистрация",
                            background: false,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_forms_SignUpForm_SignUpForm__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_AuthFormPromt_SignUpPromt_SignUpPromt__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                    onClickLogin: toggleAuthForm('login')
                                })
                            ]
                        }),
                        openTab === 'reset' && !isAuth && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_FormComponent_FormComponent__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            title: "Восстановление пароля",
                            background: false,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_forms_ResetPasswordForm_ResetPasswordForm__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {})
                        }),
                        openTab === '' && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                isAuth && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(UserUI, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_User_User__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                        cutFio: false
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MenuLinksUI, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HeaderNavLink_HeaderNavLink__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            toggleOpenMenu: toggleDrawer
                                        }),
                                        isAuth && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ExitLinkUI, {
                                            onClick: handlerLogout,
                                            children: "Выйти"
                                        })
                                    ]
                                }),
                                !isAuth && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ButtonsAuthUI, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            style: ButtonLogin,
                                            onClick: toggleAuthForm('login'),
                                            children: "Войти"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIComponents_ButtonUI_ButtonUI__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            style: ButtonSignUp,
                                            onClick: toggleAuthForm('signup'),
                                            children: "Регистрация"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_Header_HeaderPayment_HeaderPayment__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {})
        ]
    }));
};
const { BalanceTextMUI , AddPaymentMobileMUI , ContainerAddPaymentMobileMUI ,  } = (0,_components_AnyPage_Header_HeaderPayment_style__WEBPACK_IMPORTED_MODULE_19__/* .useHeaderPaymentStyles */ .Z)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(MenuAuthContent));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5346:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ useMenuAuthContentStyle)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useMenuAuthContentStyle = ()=>{
    const MenuLinksUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'flex-start',
            marginTop: '10px',
            '& a': {
                fontFamily: 'Roboto',
                fontStyle: 'normal',
                fontWeight: '300',
                fontSize: '16px',
                lineHeight: '19px',
                color: '#000000',
                textAlign: 'start',
                marginBottom: '25px'
            },
            '& a:last-child': {
                marginBottom: '25px'
            }
        })
    );
    const UserUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            marginBottom: '16px'
        })
    );
    const ExitLinkUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            fontFamily: 'Roboto',
            fontStyle: 'normal',
            fontWeight: '400',
            fontSize: '16px',
            lineHeight: '19px',
            color: '#274D82',
            cursor: 'pointer'
        })
    );
    const ButtonsAuthUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'row',
            // justifyContent: 'space-between',
            alignItems: 'center'
        })
    );
    const ButtonLogin = {
        width: '111px',
        height: '32px',
        background: '#274D82',
        opacity: '0.8',
        borderRadius: '3px',
        marginRight: '35px'
    };
    const ButtonSignUp = {
        width: '96px',
        height: '19px',
        fontStyle: 'normal',
        fontWeight: '400',
        fontSize: '16px',
        lineHeight: '19px',
        color: '#274D82',
        background: 'inherit'
    };
    return {
        MenuLinksUI,
        ButtonsAuthUI,
        ButtonLogin,
        ButtonSignUp,
        UserUI,
        ExitLinkUI
    };
};


/***/ }),

/***/ 9103:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Logotip_Logotip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7343);
/* harmony import */ var _MenuAuthContent_MenuAuthContent__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8128);
/* harmony import */ var _UI_UIIcon_HeaderMenu_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6542);
/* harmony import */ var _UI_UIIcon_WhatsAppLarge_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8632);
/* harmony import */ var _style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2794);
/* harmony import */ var _hooks_useSwipeableDrawerStore__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2655);
/* harmony import */ var _constants_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4989);
/* harmony import */ var _lib_services_services__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4727);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MenuAuthContent_MenuAuthContent__WEBPACK_IMPORTED_MODULE_3__]);
_MenuAuthContent_MenuAuthContent__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const MobileHeader = ()=>{
    // const {isHomePage} = useHeader();
    const { open , toggleDrawer , toggleTab  } = (0,_hooks_useSwipeableDrawerStore__WEBPACK_IMPORTED_MODULE_7__/* .useSwipeableDrawerStore */ .h)();
    const handlerNav = ()=>{
        toggleDrawer();
    };
    const handlerClearDrawer = ()=>{
        toggleDrawer(false);
        toggleTab('');
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HeaderMobileWrapperUI, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(NavMenuUI, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavItemUI, {
                            onClick: handlerNav,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIIcon_HeaderMenu_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavItemUI, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logotip_Logotip__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NavItemUI, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: (0,_lib_services_services__WEBPACK_IMPORTED_MODULE_8__/* .WHATSAPP */ .Q2)(_constants_constants__WEBPACK_IMPORTED_MODULE_9__/* .SUPPORT_PHONE_RU */ .ch),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UI_UIIcon_WhatsAppLarge_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SwipeableDrawerUI, {
                anchor: "left",
                open: open,
                id: "userDrawer",
                // onOpen={() => setOpenMenu(true)}
                // onClose={() => setOpenMenu(false)}
                onOpen: ()=>toggleDrawer(true)
                ,
                onClose: handlerClearDrawer,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MenuAuthContent_MenuAuthContent__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(MobileHeader));
const { HeaderMobileWrapperUI , NavMenuUI , NavItemUI , SwipeableDrawerUI ,  } = (0,_style__WEBPACK_IMPORTED_MODULE_6__/* .useHeaderMobileStyle */ .D)();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2794:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ useHeaderMobileStyle)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useHeaderMobileStyle = ()=>{
    const HeaderMobileWrapperUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('header')(()=>({
            padding: '15px',
            position: 'fixed',
            width: '100%',
            zIndex: 3,
            backgroundColor: '#FFFFFF'
        })
    );
    const NavMenuUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('nav')(()=>({
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            '& div:last-child': {
                marginRight: '0px'
            }
        })
    );
    const NavItemUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            cursor: 'pointer',
            marginRight: '35px',
            '& span': {
                width: 'auto'
            }
        })
    );
    const SwipeableDrawerUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.SwipeableDrawer)(()=>({
            '& .MuiPaper-root': {
                width: '90%',
                height: '93%',
                // padding: '1.5em 1em',
                marginTop: '15%',
                background: '#FFFFFF',
                // boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.15)',
                borderRadius: '0px 8px'
            },
            '& .MuiBackdrop-root': {
            }
        })
    );
    const MenuLinksUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'column',
            '& a': {
                fontFamily: 'Roboto',
                fontStyle: 'normal',
                fontWeight: '500',
                fontSize: '16px',
                lineHeight: '19px',
                color: '#000000',
                marginBottom: '25px'
            },
            '& a:last-child': {
                marginBottom: '30px'
            }
        })
    );
    const ButtonsAuthUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center'
        })
    );
    const ButtonLogin = {
        width: '111px',
        height: '32px',
        background: '#274D82',
        opacity: '0.8',
        borderRadius: '3px'
    };
    const ButtonSignUp = {
        width: '96px',
        height: '19px',
        fontStyle: 'normal',
        fontWeight: '400',
        fontSize: '16px',
        lineHeight: '19px',
        color: '#274D82',
        background: 'inherit'
    };
    return {
        HeaderMobileWrapperUI,
        NavMenuUI,
        NavItemUI,
        SwipeableDrawerUI,
        MenuLinksUI,
        ButtonsAuthUI,
        ButtonLogin,
        ButtonSignUp
    };
};


/***/ }),

/***/ 5498:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ useHeaderStyle)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);

const useHeaderStyle = ()=>{
    const HeaderMarginMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(()=>({
        })
    );
    const HeaderWrapperUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('header')(({ theme  })=>({
            height: '61px',
            width: '100%',
            position: 'fixed',
            zIndex: 999,
            background: '#FFFFFF',
            // opacity: '0.1',
            boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.1)',
            //
            // [theme.breakpoints.down(1181)]: {
            // 	height: '71px',
            // },
            [theme.breakpoints.down(1025)]: {
                height: '65px'
            },
            [theme.breakpoints.down(1023)]: {
                height: '65px'
            },
            [theme.breakpoints.down(501)]: {
                height: '69px'
            },
            [theme.breakpoints.down(800)]: {
            }
        })
    );
    const HeaderContentMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('nav')(({ theme  })=>({
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '12px 80px 12px 80px',
            margin: '0 auto',
            maxWidth: '1440px',
            position: 'relative',
            [theme.breakpoints.down(1025)]: {
                padding: '15px'
            }
        })
    );
    const HeaderBurgerButtonMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('span')(()=>({
            '& button': {
                display: 'flex',
                justifyContent: 'flex-start',
                margin: '0px',
                padding: '0px',
                minWidth: '35px',
                '&:hover': {
                    backgroundColor: 'inherit'
                }
            }
        })
    );
    const HeaderNavUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('ul')(({ theme  })=>({
            width: '100%',
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            '& #long-menu .MuiPaper-root ': {
                transform: 'none !important',
                top: '35px !important',
                left: '0px !important',
                width: '239px !important'
            },
            [theme.breakpoints.down(1241)]: {
                width: 'auto',
                justifyContent: 'flex-end'
            },
            [theme.breakpoints.down(1024)]: {
            }
        })
    );
    const LogoMUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('a')(({ theme  })=>({
            marginRight: '180px',
            // marginTop: '-12px',
            [theme.breakpoints.down(1441)]: {
                marginRight: '50px'
            },
            [theme.breakpoints.down(1241)]: {
                position: 'absolute',
                marginLeft: 'auto',
                marginRight: 'auto',
                left: '0',
                right: '0',
                textAlign: 'center',
                width: 'fit-content'
            }
        })
    );
    const OctoIconsUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('span')(()=>({
            width: '20%',
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            '& svg': {
                cursor: 'pointer'
            },
            '& svg:first-child': {
                marginRight: '6px'
            }
        })
    );
    const IconMarginRight = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('a')(({ theme  })=>({
            [theme.breakpoints.between(960, 1241)]: {
                marginRight: '10px'
            }
        })
    );
    const UserWrapperUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('div')(({ theme  })=>({
            // height: '28px',
            // width: '28px',
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            position: 'relative',
            '& button': {
                width: '20px',
                minWidth: '20px',
                height: '28px',
                padding: '0',
                '& span': {
                    width: '20px',
                    height: '20px'
                },
                '&:hover': {
                    backgroundColor: 'inherit'
                }
            },
            '& #popper': {
                transform: 'none !important',
                top: '35px !important',
                width: '239px !important'
            },
            '& div:first-child': {
                marginRight: '10px'
            },
            '& span, .MuiAvatar-root': {
                height: '28px',
                width: '28px'
            },
            [theme.breakpoints.down(960)]: {
                '& ': {
                    marginRight: '10px',
                    display: 'none'
                }
            }
        })
    );
    const ArrowUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)('span')(()=>({
            width: '24px',
            height: '10px',
            position: 'relative',
            transition: '.2s all linear',
            '&::after': {
                content: '""',
                borderRadius: '10px',
                position: 'absolute',
                left: '0',
                top: '45%',
                width: '12px',
                height: '2px',
                backgroundColor: '#C7C7C7',
                transform: 'rotate(48deg) translateY(-45%)'
            },
            '&::before': {
                content: '""',
                borderRadius: '10px',
                position: 'absolute',
                left: '8px',
                top: '45%',
                width: '12px',
                height: '2px',
                backgroundColor: '#C7C7C7',
                transform: 'rotate(-48deg) translateY(-45%)'
            },
            '&:focus': {
                '&::after': {
                    transform: 'rotate(130deg) translateY(-45%)'
                },
                '&::before': {
                    transform: 'rotate(-130deg) translateY(-45%)'
                }
            }
        })
    );
    const ButtonLoginUI = {
        width: '95px',
        height: '38px',
        padding: '0',
        margin: '0'
    };
    return {
        HeaderMarginMUI,
        HeaderBurgerButtonMUI,
        HeaderWrapperUI,
        HeaderContentMUI,
        HeaderNavUI,
        OctoIconsUI,
        UserWrapperUI,
        ButtonLoginUI,
        ArrowUI,
        LogoMUI,
        IconMarginRight
    };
};


/***/ }),

/***/ 250:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ useHeader)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6213);
/* harmony import */ var _hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4763);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4730);




const useHeader = ()=>{
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_3__/* .useAppDispatch */ .T)();
    const { router , pushTo  } = (0,_hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_2__/* .useCustomRouter */ .c)();
    // Пункты пользователя
    const { 0: open , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const anchorRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const handleToggle = ()=>{
        setOpen((prevOpen)=>!prevOpen
        );
    };
    const handleClose = (event)=>{
        if (anchorRef.current && anchorRef.current.contains(event.target)) {
            return;
        }
        setOpen(false);
    };
    const handlerPushLogin = ()=>{
        pushTo('/login');
    };
    const handlerLogout = ()=>{
        dispatch((0,_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchUserLogout */ .rZ)()).then(()=>{
            pushTo('/');
            setOpen(false);
        });
    };
    const handlerPushAccount = (url, query = {})=>{
        return ()=>{
            pushTo(url, query);
            setOpen(false);
        };
    };
    const handleListKeyDown = (event)=>{
        if (event.key === 'Tab') {
            event.preventDefault();
            setOpen(false);
        } else if (event.key === 'Escape') {
            setOpen(false);
        }
    };
    // Пункты навигации
    const { 0: anchorEl , 1: setAnchorEl  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const openBurger = Boolean(anchorEl);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleCloseBurger = ()=>{
        setAnchorEl(null);
    };
    const handlerPushToNav = (url)=>{
        return ()=>{
            pushTo(url);
            handleCloseBurger();
        };
    };
    const isHomePage = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>router.pathname === '/'
    , [
        router.pathname
    ]);
    return {
        handlerPushToNav,
        handleClick,
        openBurger,
        handleListKeyDown,
        handlerPushAccount,
        handlerLogout,
        handleToggle,
        handleClose,
        handlerPushLogin,
        handleCloseBurger,
        anchorEl,
        anchorRef,
        open,
        isHomePage
    };
};


/***/ }),

/***/ 7438:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ScrollTop_ScrollTop)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/components/AnyPage/ScrollTop/style.ts


const useScrollTopStyles = ()=>{
    const animTrueDesc = material_.keyframes`
      from {
        opacity: 0;
		transform: translateX(-100px);
      }
      to {
        opacity: 1;
        transform: translateX(0px);
      }
	`;
    const animTrueMobile = material_.keyframes`
		from {
			opacity: 0;
			transform: translateX(100px);
		}
		to {
			opacity: 1;
			transform: translateX(0px);
		}
	`;
    const animFalseDesc = material_.keyframes`
      from {
        opacity: 1;
		transform: translateX(0px);
      }
      to {
        opacity: 0;
        transform: translateX(-100px);
      }
	`;
    const animFalseMobile = material_.keyframes`
		from {
			opacity: 1;
			transform: translateX(0px);
		}
		to {
			opacity: 0;
			transform: translateX(100px);
		}
	`;
    const animUndefined = material_.keyframes`
      from {
        opacity: 1;
        transform: translateX(0px);
      } 
	  to {
		opacity: 0;
		transform: translateX(-100px);
	  }
	`;
    const animationVisible = (direction, render, isMobile)=>{
        if (render === 1) return {
            opacity: 0
        };
        const animFalse = isMobile ? animFalseMobile : animFalseDesc;
        const animTrue = isMobile ? animTrueMobile : animTrueDesc;
        const animationName = direction == 'top' && render >= 1 ? animFalse : direction === 'bottom' && render > 1 ? animTrue : animUndefined;
        const animationTime = direction == undefined && render === 1 ? '.0s' : '.5s';
        return {
            animation: `${animationName} ${animationTime} ease`,
            animationFillMode: 'forwards'
        };
    };
    const WrapperMUI = (0,material_.styled)('div')(({ theme  })=>({
            position: 'fixed',
            left: 0,
            top: 0,
            height: '100%',
            width: '100px',
            zIndex: 1,
            backgroundColor: 'rgba(223, 228, 236, 0.4)',
            transition: '.2s all ease',
            '&:hover': {
                backgroundColor: 'rgba(223, 228, 236, 1)'
            },
            [theme.breakpoints.down(1025)]: {
                right: '15px',
                bottom: '145px',
                left: 'auto',
                top: 'auto',
                zIndex: '10',
                backgroundColor: '#C4C4C4',
                width: '38px',
                height: '38px',
                boxShadow: '0px 3px 4px rgba(0, 0, 0, 0.2)',
                borderRadius: '50%'
            }
        })
    );
    const ScrollButtonMUI = (0,material_.styled)('button')(({ theme  })=>({
            border: 0,
            width: '100%',
            height: '100%',
            display: 'flex',
            justifyContent: 'center',
            cursor: 'pointer',
            backgroundColor: 'transparent',
            [theme.breakpoints.down(1025)]: {
                alignItems: 'center'
            }
        })
    );
    const TextMUI = (0,material_.styled)('div')(()=>({
            textAlign: 'center',
            marginTop: '16px',
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'center'
        })
    );
    const TittleMUI = (0,material_.styled)('span')(()=>({
            fontSize: '14px',
            lineHeight: '16px',
            fontWeight: 400,
            color: 'rgba(39, 77, 130, 0.6)',
            marginRight: '5px'
        })
    );
    return {
        TextMUI,
        TittleMUI,
        WrapperMUI,
        ScrollButtonMUI,
        animationVisible
    };
};

// EXTERNAL MODULE: ./src/components/AnyPage/Header/HeaderMargin/HeaderMargin.tsx
var HeaderMargin = __webpack_require__(2656);
;// CONCATENATED MODULE: ./src/UI/UIIcon/ScrollArrowTop.svg
var _path;

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }



var SvgScrollArrowTop = function SvgScrollArrowTop(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    width: 8,
    height: 17,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    d: "M4.354.646a.5.5 0 0 0-.708 0L.464 3.828a.5.5 0 1 0 .708.708L4 1.707l2.828 2.829a.5.5 0 1 0 .708-.708L4.354.646ZM4.5 17V1h-1v16h1Z",
    fill: "#274D82",
    fillOpacity: 0.6
  })));
};

/* harmony default export */ const ScrollArrowTop = (SvgScrollArrowTop);
;// CONCATENATED MODULE: ./src/UI/UIIcon/ScrollTopMobile.svg
var _g, _defs;

function ScrollTopMobile_extends() { ScrollTopMobile_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return ScrollTopMobile_extends.apply(this, arguments); }



var SvgScrollTopMobile = function SvgScrollTopMobile(props) {
  return /*#__PURE__*/external_react_.createElement("svg", ScrollTopMobile_extends({
    width: 34,
    height: 23,
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, props), _g || (_g = /*#__PURE__*/external_react_.createElement("g", {
    filter: "url(#ScrollTopMobile_svg__a)"
  }, /*#__PURE__*/external_react_.createElement("path", {
    d: "M28.167 13.38 17.156 2 6.186 13.341",
    stroke: "#fff",
    strokeWidth: 3,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), _defs || (_defs = /*#__PURE__*/external_react_.createElement("defs", null, /*#__PURE__*/external_react_.createElement("filter", {
    id: "ScrollTopMobile_svg__a",
    x: 0.686,
    y: 0.5,
    width: 32.981,
    height: 22.381,
    filterUnits: "userSpaceOnUse",
    colorInterpolationFilters: "sRGB"
  }, /*#__PURE__*/external_react_.createElement("feFlood", {
    floodOpacity: 0,
    result: "BackgroundImageFix"
  }), /*#__PURE__*/external_react_.createElement("feColorMatrix", {
    "in": "SourceAlpha",
    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
    result: "hardAlpha"
  }), /*#__PURE__*/external_react_.createElement("feOffset", {
    dy: 4
  }), /*#__PURE__*/external_react_.createElement("feGaussianBlur", {
    stdDeviation: 2
  }), /*#__PURE__*/external_react_.createElement("feComposite", {
    in2: "hardAlpha",
    operator: "out"
  }), /*#__PURE__*/external_react_.createElement("feColorMatrix", {
    values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.2 0"
  }), /*#__PURE__*/external_react_.createElement("feBlend", {
    in2: "BackgroundImageFix",
    result: "effect1_dropShadow_812_1029"
  }), /*#__PURE__*/external_react_.createElement("feBlend", {
    "in": "SourceGraphic",
    in2: "effect1_dropShadow_812_1029",
    result: "shape"
  })))));
};

/* harmony default export */ const ScrollTopMobile = (SvgScrollTopMobile);
// EXTERNAL MODULE: ./src/hooks/useCustomRouter.ts
var useCustomRouter = __webpack_require__(4763);
;// CONCATENATED MODULE: ./src/components/AnyPage/ScrollTop/useScrollTop.ts



const useScrollTop = ()=>{
    const scrollRoutes = [
        '/shops',
        '/blog'
    ];
    const { getPathName , router  } = (0,useCustomRouter/* useCustomRouter */.c)();
    const isMobile = (0,material_.useMediaQuery)('(max-width: 1024px)');
    const { 0: isTop , 1: setIsTop  } = (0,external_react_.useState)({
        direction: undefined,
        isTop: false,
        render: 1
    });
    const isMountingScroll = (0,external_react_.useMemo)(()=>{
        return !!scrollRoutes.find((route)=>route === getPathName()
        );
    }, [
        router,
        isMobile
    ]);
    const isVisible = (0,external_react_.useMemo)(()=>isTop && isMountingScroll
    , [
        isTop,
        isMountingScroll
    ]);
    const handleClickButton = ()=>{
        if (false) {}
    };
    const onScroll = (event)=>{
        if (false) {}
    };
    (0,external_react_.useEffect)(()=>{
        if (isMountingScroll) {
            window.addEventListener('scroll', onScroll);
        }
        return ()=>{
            try {
                window.removeEventListener('scroll', onScroll);
            } catch (e) {
                throw new Error('ScrollArrow Error');
            }
        };
    }, [
        isMountingScroll
    ]);
    return {
        isTop,
        isMobile,
        isVisible,
        isMountingScroll,
        handleClickButton
    };
};

;// CONCATENATED MODULE: ./src/components/AnyPage/ScrollTop/ScrollTop.tsx







const ScrollTop = ()=>{
    const { isTop , isMobile , isMountingScroll , handleClickButton  } = useScrollTop();
    return isMountingScroll ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(WrapperMUI, {
        sx: animationVisible(isTop.direction, isTop.render, isMobile),
        children: [
            !isMobile && /*#__PURE__*/ jsx_runtime_.jsx(HeaderMargin/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(ScrollButtonMUI, {
                onClick: handleClickButton,
                children: !isMobile ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(TextMUI, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(TittleMUI, {
                            children: "Наверх"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(ScrollArrowTop, {})
                    ]
                }) : /*#__PURE__*/ jsx_runtime_.jsx(ScrollTopMobile, {})
            })
        ]
    }) : null;
};
const { TextMUI , TittleMUI , WrapperMUI , ScrollButtonMUI , animationVisible ,  } = useScrollTopStyles();
/* harmony default export */ const ScrollTop_ScrollTop = (/*#__PURE__*/external_react_default().memo(ScrollTop));


/***/ }),

/***/ 5850:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ usePayment)
/* harmony export */ });
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4730);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _reducers_paymentSlice_paymentSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9951);
/* harmony import */ var _reducers_paymentSlice_asyncThunk_paymentApi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6233);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(257);
/* harmony import */ var _reducers_adminSlice_adminSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7496);
/* harmony import */ var _reducers_userSlice_userSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5734);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_7__);








const usePayment = ()=>{
    const { currentCourseEuro , historyBalance , loadingHistoryBalance , statusMessage , isOpenPaymentForm ,  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppSelector */ .C)((state)=>state.paymentReducer
    );
    const { adminSwitchIdToUser , adminSwitchUserModel  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppSelector */ .C)((state)=>state.adminReducer
    );
    const { isAdmin , user  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_4__/* .useUserStore */ .L)();
    const { 0: isOpenModal , 1: setIsOpenModal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const isTablet = (0,_mui_material__WEBPACK_IMPORTED_MODULE_7__.useMediaQuery)('(max-width: 768px)');
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_0__/* .useAppDispatch */ .T)();
    const normalCourseEuro = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (currentCourseEuro) {
            return currentCourseEuro / 100;
        }
    }, [
        currentCourseEuro
    ]);
    const normalBalance = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if ((user === null || user === void 0 ? void 0 : user.balance) || (adminSwitchUserModel === null || adminSwitchUserModel === void 0 ? void 0 : adminSwitchUserModel.balance)) {
            if (isAdmin && adminSwitchUserModel) {
                return (adminSwitchUserModel.balance / 100).toFixed(2);
            }
            if (!isAdmin) {
                return ((user === null || user === void 0 ? void 0 : user.balance) / 100).toFixed(2);
            }
            return 0;
        }
    }, [
        user === null || user === void 0 ? void 0 : user.balance,
        adminSwitchUserModel
    ]);
    const handleUpdateUserBalance = (sum)=>{
        if (isAdmin && adminSwitchUserModel) {
            dispatch(_reducers_adminSlice_adminSlice__WEBPACK_IMPORTED_MODULE_5__/* .adminSlice.actions.changeUserBalance */ .X9.actions.changeUserBalance(sum));
        }
        dispatch(_reducers_userSlice_userSlice__WEBPACK_IMPORTED_MODULE_6__/* .userSlice.actions.updateBalance */ .s.actions.updateBalance(sum));
    };
    const handleResetHistoryBalance = ()=>{
        dispatch(_reducers_paymentSlice_paymentSlice__WEBPACK_IMPORTED_MODULE_2__/* .paymentSlice.actions.resetHistoryBalance */ .Y.actions.resetHistoryBalance());
    };
    const handleOpenPaymentForm = ()=>{
        dispatch(_reducers_paymentSlice_paymentSlice__WEBPACK_IMPORTED_MODULE_2__/* .paymentSlice.actions.openPaymentForm */ .Y.actions.openPaymentForm());
    };
    const handleTogglePaymentForm = ()=>{
        dispatch(_reducers_paymentSlice_paymentSlice__WEBPACK_IMPORTED_MODULE_2__/* .paymentSlice.actions.togglePaymentForm */ .Y.actions.togglePaymentForm());
    };
    const handleSendUserEmailReq = ()=>{
        dispatch((0,_reducers_paymentSlice_asyncThunk_paymentApi__WEBPACK_IMPORTED_MODULE_3__/* .fetchSendPaymentMessageInEmail */ .ZS)({
            isTablet
        }));
        setIsOpenModal(true);
    };
    const handleResetStatusMessagePaymentReducer = (status = '')=>{
        dispatch(_reducers_paymentSlice_paymentSlice__WEBPACK_IMPORTED_MODULE_2__/* .paymentSlice.actions.resetStatusMessage */ .Y.actions.resetStatusMessage(status));
        if (isOpenModal) {
            setIsOpenModal(false);
        }
    };
    const handleGetHistoryOperation = ()=>{
        const innerId = adminSwitchIdToUser ? adminSwitchIdToUser : user === null || user === void 0 ? void 0 : user.id;
        const url = isAdmin ? `/admin/user/${innerId}/balance_history` : 'user/balance_history';
        dispatch((0,_reducers_paymentSlice_asyncThunk_paymentApi__WEBPACK_IMPORTED_MODULE_3__/* .fetchHistoryBalanceOperation */ .kE)({
            url: url
        }));
    };
    return {
        isAdmin,
        isOpenModal,
        isOpenPaymentForm,
        statusMessage,
        adminSwitchIdToUser,
        handleGetHistoryOperation,
        euroCourse: normalCourseEuro,
        userBalance: normalBalance,
        userHistoryBalance: historyBalance,
        loadingHistoryBalance,
        handleSendUserEmailReq,
        handleTogglePaymentForm,
        handleOpenPaymentForm,
        handleUpdateUserBalance,
        handleResetHistoryBalance,
        handleResetStatusMessagePaymentReducer
    };
};


/***/ }),

/***/ 7247:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ useUpdateRefresh)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6213);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(257);



const useUpdateRefresh = ()=>{
    const { isAuth , user  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_2__/* .useUserStore */ .L)();
    const { 0: newToken , 1: setNewToken  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const updateToken = ()=>{
        (0,_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchUserRefresh */ .o_)().then((response)=>{
            if (response.message === 'success') {
                setNewToken(true);
            }
            if (typeof response === 'number') {
                setNewToken(false);
            }
        }).catch(()=>{
        // console.log('updateToken, fetchUserRefresh: ', e);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        updateToken();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (isAuth && (user === null || user === void 0 ? void 0 : user.id)) {
            const interval = setInterval(()=>{
                updateToken();
            }, 1500000);
            if (!isAuth) {
                clearInterval(interval);
            }
        }
    }, [
        isAuth
    ]);
    return {
        newToken
    };
};


/***/ }),

/***/ 2755:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



const ContentLayoutUI = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)('div', {
    shouldForwardProp: (prop)=>prop !== 'disabledPadding' && prop !== 'disabledMargin'
})(({ disabledPadding , disabledMargin , theme  })=>({
        padding: !disabledPadding ? '0 80px' : '0',
        maxWidth: '1440px',
        // padding: '0 80px',
        margin: '0 auto',
        [theme.breakpoints.down(1025)]: {
            padding: !disabledPadding ? '15px' : '0'
        },
        [theme.breakpoints.down(500)]: {
            padding: '0',
            margin: disabledMargin ? '0' : '15px'
        }
    })
);
const ContentLayout = ({ disabledPadding =false , disabledMargin , children  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ContentLayoutUI, {
        disabledPadding: disabledPadding,
        disabledMargin: disabledMargin,
        children: children
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(ContentLayout));


/***/ }),

/***/ 7467:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_AnyPage_Header_Header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(251);
/* harmony import */ var _components_AnyPage_Footer_Footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7364);
/* harmony import */ var _ContentLayout_ContentLayout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2755);
/* harmony import */ var _hooks_useUpdateRefresh__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7247);
/* harmony import */ var _hooks_useUserStore__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(257);
/* harmony import */ var _theme_theme__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5832);
/* harmony import */ var _hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4763);
/* harmony import */ var _components_AnyPage_ScrollTop_ScrollTop__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7438);
/* harmony import */ var _hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4730);
/* harmony import */ var _reducers_adminSlice_adminSlice__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7496);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_AnyPage_Header_Header__WEBPACK_IMPORTED_MODULE_3__]);
_components_AnyPage_Header_Header__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













const MainLayout = ({ children  })=>{
    (0,_hooks_useUpdateRefresh__WEBPACK_IMPORTED_MODULE_6__/* .useUpdateRefresh */ .d)();
    const { getUser , isAdmin  } = (0,_hooks_useUserStore__WEBPACK_IMPORTED_MODULE_7__/* .useUserStore */ .L)();
    const { router  } = (0,_hooks_useCustomRouter__WEBPACK_IMPORTED_MODULE_9__/* .useCustomRouter */ .c)();
    const { adminSwitchIdToUser  } = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_11__/* .useAppSelector */ .C)((state)=>state.adminReducer
    );
    const dispatch = (0,_hooks_useReduxHooks__WEBPACK_IMPORTED_MODULE_11__/* .useAppDispatch */ .T)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getUser();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isAdmin && router) {
            const isAccountLocation = router.pathname.match('account');
            if (!isAccountLocation && adminSwitchIdToUser) {
                dispatch(_reducers_adminSlice_adminSlice__WEBPACK_IMPORTED_MODULE_12__/* .adminSlice.actions.resetData */ .X9.actions.resetData());
            }
        }
    }, [
        router
    ]);
    const disabledPadding = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>router.route === '/'
    , [
        router.route
    ]);
    const disabledMargin = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>router.route === '/'
    , [
        router.route
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_theme_theme__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_Header_Header__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                component: "main",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ContentLayout_ContentLayout__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        disabledPadding: disabledPadding,
                        disabledMargin: disabledMargin,
                        children: children
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_ScrollTop_ScrollTop__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_AnyPage_Footer_Footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(MainLayout));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6233:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q6": () => (/* binding */ fetchAdminAddPaymentInUser),
/* harmony export */   "ZS": () => (/* binding */ fetchSendPaymentMessageInEmail),
/* harmony export */   "kE": () => (/* binding */ fetchHistoryBalanceOperation),
/* harmony export */   "lF": () => (/* binding */ fetchDeleteTransaction)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7355);
/* harmony import */ var _reducers_adminSlice_adminSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7496);



const fetchAdminAddPaymentInUser = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('paymentSlice/add', async (data, thunkAPI)=>{
    try {
        var ref;
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.post */ .N.post('/admin/user/balance', data);
        return {
            message: ((ref = response.data) === null || ref === void 0 ? void 0 : ref.message) == 'success' ? 'Платеж успешно проведён' : ''
        };
    } catch (e) {
        thunkAPI.rejectWithValue('error paymentSlice/add');
    }
});
const fetchSendPaymentMessageInEmail = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('paymentSlice/email', async (data, thunkAPI)=>{
    try {
        var ref;
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get('/user/send_message/add_balance');
        return ((ref = response.data) === null || ref === void 0 ? void 0 : ref.message) === 'success' ? `Заявка на пополнение успешно отправлена. ${!data.isTablet ? '\n' : ''}` + 'Наш менеджер свяжется с вами в ближайшее время.' : '';
    } catch (e) {
        return thunkAPI.rejectWithValue('Ошибка при отправке запроса, повторите позже.');
    }
});
const fetchHistoryBalanceOperation = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('paymentSlice/history', async (data, thunkAPI)=>{
    try {
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios.get */ .N.get(data.url);
        return response.data.balance_history;
    } catch (e) {
        return thunkAPI.rejectWithValue('Ошибка при получении баланса');
    }
});
const fetchDeleteTransaction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)('paymentSlice/delete', async (data, thunkAPI)=>{
    try {
        var ref;
        const { operationId , operationSum  } = data;
        const { adminReducer: { adminSwitchIdToUser  } , paymentReducer: { historyBalance  }  } = thunkAPI.getState();
        const response = await _lib_http__WEBPACK_IMPORTED_MODULE_1__/* .octoAxios["delete"] */ .N["delete"](`/admin/user/${adminSwitchIdToUser}/balance_history/${operationId}`);
        if (((ref = response.data) === null || ref === void 0 ? void 0 : ref.message) === 'success') {
            thunkAPI.dispatch((0,_reducers_adminSlice_adminSlice__WEBPACK_IMPORTED_MODULE_2__/* .changeUserBalance */ .Wb)(operationSum > 0 ? operationSum - operationSum * 2 : Math.abs(operationSum)));
            return historyBalance.filter((item)=>item.id !== operationId
            );
        }
        return historyBalance;
    } catch (e) {
        return thunkAPI.rejectWithValue('Ошибка удаления баланса');
    }
});


/***/ }),

/***/ 9951:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ paymentSlice),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_paymentSlice_asyncThunk_paymentApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6233);


const initialState = {
    currentCourseEuro: 7532,
    balance: 15100,
    historyBalance: [],
    statusMessage: '',
    loadingHistoryBalance: true,
    isOpenPaymentForm: false
};
const paymentSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'paymentSlice',
    initialState,
    reducers: {
        resetStatusMessage (state, action) {
            state.statusMessage = action.payload;
        },
        openPaymentForm (state) {
            state.isOpenPaymentForm = true;
        },
        togglePaymentForm (state) {
            state.isOpenPaymentForm = !state.isOpenPaymentForm;
        },
        resetHistoryBalance (state) {
            state.historyBalance = [];
            state.loadingHistoryBalance = true;
        }
    },
    extraReducers: {
        [_reducers_paymentSlice_asyncThunk_paymentApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchSendPaymentMessageInEmail.fulfilled.type */ .ZS.fulfilled.type]: (state, action)=>{
            state.statusMessage = action.payload;
        },
        [_reducers_paymentSlice_asyncThunk_paymentApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchSendPaymentMessageInEmail.rejected.type */ .ZS.rejected.type]: (state, action)=>{
            state.statusMessage = action.payload;
        },
        [_reducers_paymentSlice_asyncThunk_paymentApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchHistoryBalanceOperation.fulfilled.type */ .kE.fulfilled.type]: (state, action)=>{
            state.historyBalance = action.payload;
            state.loadingHistoryBalance = false;
        },
        [_reducers_paymentSlice_asyncThunk_paymentApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchDeleteTransaction.fulfilled.type */ .lF.fulfilled.type]: (state, action)=>{
            state.historyBalance = action.payload;
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (paymentSlice.reducer);


/***/ }),

/***/ 5734:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ userSlice),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6213);


const initialState = {
    user: {
        id: 0,
        email: '',
        addresses: [],
        lastLoginTime: '',
        personalAreaId: 0,
        statusId: 0,
        name: '',
        photo: '',
        phone: '',
        registrationTime: '',
        surname: '',
        username: '',
        verifiedEmail: false,
        balance: 0
    }
};
const userSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'user/info',
    initialState,
    reducers: {
        updateBalance (state, action) {
            state.user.balance += action.payload;
        }
    },
    extraReducers: {
        [_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchUserLogin.fulfilled.type */ .zd.fulfilled.type]: (state, data)=>{
            state.user = data.payload.user;
        },
        [_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchUserAutoLogin.fulfilled.type */ .u3.fulfilled.type]: (state, data)=>{
            state.user = data.payload.user;
        },
        [_reducers_userSlice_asyncActions_userApi__WEBPACK_IMPORTED_MODULE_1__/* .fetchUserLogout.fulfilled.type */ .rZ.fulfilled.type]: (state)=>{
            state.user = initialState.user;
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (userSlice.reducer);


/***/ }),

/***/ 4097:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "D": () => (/* binding */ persistor),
  "h": () => (/* binding */ store)
});

;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
;// CONCATENATED MODULE: external "redux-persist/lib/storage"
const storage_namespaceObject = require("redux-persist/lib/storage");
var storage_default = /*#__PURE__*/__webpack_require__.n(storage_namespaceObject);
;// CONCATENATED MODULE: external "redux-persist"
const external_redux_persist_namespaceObject = require("redux-persist");
// EXTERNAL MODULE: ./src/store/reducers/sendAdress/asyncActions/sendAdressApi.ts
var sendAdressApi = __webpack_require__(2249);
;// CONCATENATED MODULE: ./src/store/reducers/sendAdress/sendAdressSlice.ts


const initialState = {
    sending: 'done'
};
const sendAdressSlice = (0,toolkit_.createSlice)({
    name: 'user/SendAdressSlice',
    initialState,
    reducers: {},
    extraReducers: {
        [sendAdressApi/* fetchSendAddress.fulfilled.type */.h.fulfilled.type]: (state)=>{
            state.sending = 'done';
        },
        [sendAdressApi/* fetchSendAddress.rejected.type */.h.rejected.type]: (state)=>{
            state.sending = 'error';
        },
        [sendAdressApi/* fetchSendAddress.pending.type */.h.pending.type]: (state)=>{
            state.sending = 'loading';
        }
    }
});
/* harmony default export */ const sendAdress_sendAdressSlice = (sendAdressSlice.reducer);

;// CONCATENATED MODULE: ./src/store/reducers/translateSlice/translateSlice.ts

const translateSlice_initialState = {
    language: 'RUS'
};
const translateSlice = (0,toolkit_.createSlice)({
    name: 'language/slice',
    initialState: translateSlice_initialState,
    reducers: {
        changeWebsiteLanguage (state, action) {
            state.language = action.payload;
        }
    }
});
/* harmony default export */ const translateSlice_translateSlice = (translateSlice.reducer);

// EXTERNAL MODULE: ./src/store/reducers/userSlice/userSlice.ts
var userSlice = __webpack_require__(5734);
// EXTERNAL MODULE: ./src/store/reducers/reviewsSlice/reviewsSlice.ts
var reviewsSlice = __webpack_require__(7541);
// EXTERNAL MODULE: ./src/store/reducers/shopsSlice/shopsSlice.ts
var shopsSlice = __webpack_require__(5236);
// EXTERNAL MODULE: ./src/store/reducers/swipeableDrawerSlice/swipeableDrawerSlice.ts
var swipeableDrawerSlice = __webpack_require__(4359);
// EXTERNAL MODULE: ./src/store/reducers/blogSlice/blogSlice.ts
var blogSlice = __webpack_require__(6559);
// EXTERNAL MODULE: ./src/store/reducers/orderWaitSlice/orderWaitSlice.ts
var orderWaitSlice = __webpack_require__(9238);
// EXTERNAL MODULE: ./src/store/reducers/adminSlice/adminSlice.ts
var adminSlice = __webpack_require__(7496);
// EXTERNAL MODULE: ./src/store/reducers/orderStockSlice/orderStockSlice.ts
var orderStockSlice = __webpack_require__(6448);
// EXTERNAL MODULE: ./src/store/reducers/orderSendSlice/orderSendSlice.ts
var orderSendSlice = __webpack_require__(4216);
// EXTERNAL MODULE: ./src/store/reducers/paymentSlice/paymentSlice.ts
var paymentSlice = __webpack_require__(9951);
// EXTERNAL MODULE: ./src/store/reducers/euroExchangeRate/asyncThunk/euroApi.ts
var euroApi = __webpack_require__(3942);
;// CONCATENATED MODULE: ./src/store/reducers/euroExchangeRate/eutoSlice.ts


const eutoSlice_initialState = {
    currency: 'EUR',
    value: 0
};
const euroSlice = (0,toolkit_.createSlice)({
    name: 'euroSlice',
    initialState: eutoSlice_initialState,
    reducers: {
        updateRate: (state, action)=>{
            state.value = action.payload / 100;
        }
    },
    extraReducers: {
        [euroApi/* fetchEuroRate.fulfilled.type */.e.fulfilled.type]: (state, action)=>{
            state.value = action.payload.data.exchange_rate[0].value / 100;
        },
        [euroApi/* fetchSetEuroRate.fulfilled.type */.y.fulfilled.type]: (state, action)=>{
            state.value = action.payload / 100;
        }
    }
});
const { updateRate  } = euroSlice.actions;
/* harmony default export */ const eutoSlice = (euroSlice.reducer);

;// CONCATENATED MODULE: ./src/store/allReducers.ts













const allReducers = {
    userReducer: userSlice/* default */.Z,
    shopReducer: shopsSlice/* default */.Z,
    blogReducer: blogSlice/* default */.ZP,
    adminReducer: adminSlice/* default */.ZP,
    reviewsReducer: reviewsSlice/* default */.ZP,
    translateReducer: translateSlice_translateSlice,
    orderSendReducer: orderSendSlice/* default */.Z,
    orderWaitReducer: orderWaitSlice/* default */.Z,
    orderStockReducer: orderStockSlice/* default */.Z,
    paymentReducer: paymentSlice/* default */.Z,
    swipeableDrawerSliceReducer: swipeableDrawerSlice/* default */.ZP,
    euroSlice: eutoSlice,
    sendAdressSlice: sendAdress_sendAdressSlice
};

;// CONCATENATED MODULE: ./src/store/store.ts





const appReducer = (0,external_redux_namespaceObject.combineReducers)({
    ...allReducers
});
const persistConfig = {
    key: 'root',
    storage: (storage_default()),
    blacklist: [
        'blogReducer',
        'shopReducer',
        'reviewsReducer',
        'adminReducer',
        'orderWaitReducer',
        'paymentReducer',
        'orderSendReducer',
        'orderStockReducer',
        'swipeableDrawerSliceReducer', 
    ]
};
const persistedReducer = (0,external_redux_persist_namespaceObject.persistReducer)(persistConfig, appReducer);
const store = (0,toolkit_.configureStore)({
    reducer: persistedReducer,
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware({
            serializableCheck: {
                ignoredActions: [
                    external_redux_persist_namespaceObject.FLUSH,
                    external_redux_persist_namespaceObject.PERSIST,
                    external_redux_persist_namespaceObject.REHYDRATE,
                    external_redux_persist_namespaceObject.PAUSE,
                    external_redux_persist_namespaceObject.PURGE,
                    external_redux_persist_namespaceObject.REGISTER
                ]
            }
        })
});
const persistor = (0,external_redux_persist_namespaceObject.persistStore)(store);


/***/ }),

/***/ 5832:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



const Theme = ({ children  })=>{
    const lightTheme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.createTheme)({
        palette: {
            mode: 'light',
            primary: {
                main: '#234A82',
                dark: '#000000'
            }
        },
        components: {
            MuiTextField: {
                styleOverrides: {
                    root: {
                        '& > .MuiFormHelperText-root': {
                            color: 'red',
                            fontSize: '14px',
                            marginLeft: 0
                        }
                    }
                }
            }
        },
        status: {
            danger: 'red'
        }
    });
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ThemeProvider, {
        theme: lightTheme,
        children: children
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(Theme));


/***/ }),

/***/ 3218:
/***/ ((module) => {

module.exports = require("@hookform/error-message");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 5371:
/***/ ((module) => {

module.exports = require("@mui/material/ClickAwayListener");

/***/ }),

/***/ 8125:
/***/ ((module) => {

module.exports = require("@mui/material/Menu");

/***/ }),

/***/ 7229:
/***/ ((module) => {

module.exports = require("@mui/material/Tooltip");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 4287:
/***/ ((module) => {

module.exports = require("gsap");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 1127:
/***/ ((module) => {

module.exports = require("redux-persist/integration/react");

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 6847:
/***/ ((module) => {

module.exports = JSON.parse('{"desktop":[{"title":"Магазины","showAuth":false,"href":"/shops"},{"title":"Стоимость услуг","showAuth":false,"href":"/questions?transfer"},{"title":"Блог","showAuth":false,"href":"/blog"},{"title":"Частые вопросы","showAuth":false,"href":"/questions"}],"tablet":[{"title":"Магазины","showAuth":false,"href":"/shops"},{"title":"Стоимость услуг","showAuth":false,"href":"/questions?transfer"},{"title":"Блог","showAuth":false,"href":"/blog"},{"title":"Частые вопросы","showAuth":false,"href":"/questions"},{"title":"Личный кабинет","showAuth":true,"href":"/account/info"}],"mobile":[{"title":"Заказы","showAuth":true,"showAdmin":false,"href":"/account/orders/wait"},{"title":"Магазины","showAuth":false,"showAdmin":false,"href":"/shops"},{"title":"Стоимость услуг","showAuth":false,"showAdmin":false,"href":"/questions?transfer"},{"title":"Блог","showAuth":false,"showAdmin":true,"href":"/blog"},{"title":"Сформировать отчёт","showAuth":true,"showAdmin":true,"href":"https://octo.global/api/admin/users_table"},{"title":"Частые вопросы","showAuth":false,"showAdmin":false,"href":"/questions"}]}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7730,1664,2969,8595,3658,4727,257,5936,239,1799,2655,1961,1705,4042,5868,528,8632,2777,9601,6486,5760,4219], () => (__webpack_exec__(5656)));
module.exports = __webpack_exports__;

})();